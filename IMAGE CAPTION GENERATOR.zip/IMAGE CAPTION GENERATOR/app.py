from flask import Flask, render_template, request, jsonify
from transformers import VisionEncoderDecoderModel, ViTFeatureExtractor, AutoTokenizer
from PIL import Image
import torch
import os
from gtts import gTTS
import base64
from googletrans import Translator
from werkzeug.utils import secure_filename
from io import BytesIO

# Initialize Flask app
app = Flask(__name__)

# Configuration
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB file size limit

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Initialize translator
translator = Translator()

# Language settings with proper language codes for translation and TTS
LANGUAGES = {
    'english': {
        'code': 'en',
        'name': 'English',
        'tts_code': 'en'
    },
    'hindi': {
        'code': 'hi',
        'name': 'Hindi',
        'tts_code': 'hi'
    },
    'kannada': {
        'code': 'kn', 
        'name': 'Kannada',
        'tts_code': 'kn'
    },
    'telugu': {
        'code': 'te',
        'name': 'Telugu',
        'tts_code': 'te'
    }
}

# Load AI models
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"🚀 Loading AI models on {device}...")

try:
    model = VisionEncoderDecoderModel.from_pretrained("nlpconnect/vit-gpt2-image-captioning").to(device)
    feature_extractor = ViTFeatureExtractor.from_pretrained("nlpconnect/vit-gpt2-image-captioning")
    tokenizer = AutoTokenizer.from_pretrained("nlpconnect/vit-gpt2-image-captioning")
    print("Models loaded successfully!")
except Exception as e:
    print(f"Error loading models: {str(e)}")
    exit(1)

def allowed_file(filename):
    """Check if the file has an allowed extension"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def generate_caption(image_path):
    """Generate English caption from image using the AI model"""
    try:
        image = Image.open(image_path)
        if image.mode != 'RGB':
            image = image.convert('RGB')
            
        pixel_values = feature_extractor(images=image, return_tensors="pt").pixel_values.to(device)
        output_ids = model.generate(
            pixel_values,
            max_length=50,
            num_beams=5,
            early_stopping=True
        )
        return tokenizer.decode(output_ids[0], skip_special_tokens=True)
    except Exception as e:
        print(f"Caption generation error: {str(e)}")
        raise

def translate_text(text, target_lang):
    """Translate text to target language"""
    try:
        translation = translator.translate(text, dest=target_lang)
        return translation.text
    except Exception as e:
        print(f"Translation error: {str(e)}")
        return text  # Return original text if translation fails

def text_to_speech(text, lang_code):
    """Generate speech audio from text in the specified language"""
    try:
        tts = gTTS(text=text, lang=lang_code, slow=False)
        audio_bytes = BytesIO()
        tts.write_to_fp(audio_bytes)
        audio_bytes.seek(0)
        return base64.b64encode(audio_bytes.read()).decode('utf-8')
    except Exception as e:
        print(f"TTS error: {str(e)}")
        return None

@app.route('/')
def home():
    """Render the main page with language options"""
    return render_template('index.html', languages=LANGUAGES.keys())

@app.route('/generate', methods=['POST'])
def process_image():
    """Handle image upload and caption generation"""
    try:
        # Check if image was uploaded
        if 'image' not in request.files:
            return jsonify({'error': 'No image uploaded'}), 400
        
        file = request.files['image']
        
        # Check if file was selected
        if file.filename == '':
            return jsonify({'error': 'No image selected'}), 400
        
        # Check file extension
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Please upload JPG, PNG, or WEBP.'}), 400
        
        # Get selected language
        language = request.form.get('language', 'english')
        if language not in LANGUAGES:
            return jsonify({'error': 'Invalid language selected'}), 400

        # Secure filename and save
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Generate English caption
        english_caption = generate_caption(filepath)
        
        # Translate to selected language if not English
        if language != 'english':
            translated_caption = translate_text(english_caption, LANGUAGES[language]['code'])
        else:
            translated_caption = english_caption
        
        # Generate audio in the selected language
        audio_base64 = text_to_speech(translated_caption, LANGUAGES[language]['tts_code'])
        
        # Prepare response
        response = {
            'success': True,
            'image_url': f"/static/uploads/{filename}",
            'english_caption': english_caption,
            'translated_caption': translated_caption,
            'language': LANGUAGES[language]['name'],
            'audio': audio_base64
        }
        
        return jsonify(response)
        
    except Exception as e:
        print(f"Processing error: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
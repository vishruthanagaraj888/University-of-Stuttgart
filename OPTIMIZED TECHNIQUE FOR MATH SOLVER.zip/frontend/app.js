const api = '';
const state = {
  auth: null,
  currentView: 'login',
  topics: [],
  formulas: [],
  selectedFormulaTopic: '',
  solverMode: 'text',
  calcExpr: '',
  calcHistory: [],
  calcMemory: 0,
  calcMode: 'DEG',
  lastHistoryId: null,
  lastPromptStyle: 'detailed',
};

const q = (id) => document.getElementById(id);
const qa = (sel) => Array.from(document.querySelectorAll(sel));
const pageTitles = {
  login: 'Login', register: 'Register', solver: 'Math Solver', formulas: 'Formulas',
  calculator: 'Calculator', history: 'History', practice: 'Practice', listening: 'Listening', profile: 'Profile'
};
const exampleQuestions = [
  'Solve 3x + 5 = 20',
  'Differentiate x^3 + 2x',
  'Integrate x^2 from 0 to 3',
  'Find determinant of [[1,2],[3,4]]',
  'What is 25% of 320?'
];

function toast(msg, type='success') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  q('toastZone').appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

function setMessage(id, msg='', type='') {
  const el = q(id);
  el.textContent = msg || '';
  el.className = `inline-message ${type}`;
}

function saveAuth() {
  if (state.auth) localStorage.setItem('mathsolver_auth', JSON.stringify(state.auth));
  else localStorage.removeItem('mathsolver_auth');
}

function loadAuth() {
  try { state.auth = JSON.parse(localStorage.getItem('mathsolver_auth') || 'null'); } catch { state.auth = null; }
}

function authHeaders() {
  return state.auth?.access_token ? { Authorization: `Bearer ${state.auth.access_token}` } : {};
}

function formBody(obj) {
  const fd = new FormData();
  Object.entries(obj).forEach(([k, v]) => fd.append(k, v));
  return fd;
}

function setActiveView(view) {
  state.currentView = view;
  qa('.view').forEach(el => el.classList.remove('active'));
  q(`view-${view}`)?.classList.add('active');
  qa('.nav-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.view === view));
  if (view === 'formulas') loadFormulas();
  if (view === 'history') loadHistory();
  if (view === 'listening') loadVideos();
  if (view === 'profile') loadProfile();
}

function requireAuth(view) {
  if (!state.auth?.access_token) {
    toast('Please log in to open this section.', 'error');
    setActiveView('login');
    return false;
  }
  setActiveView(view);
  return true;
}

function refreshAuthUI() {
  const user = state.auth?.user;
  document.body.classList.toggle('logged-in', !!user);
  if (q('logoutBtn')) q('logoutBtn').style.display = user ? 'inline-flex' : 'none';
  qa('.nav-btn.protected').forEach(btn => {
    btn.classList.toggle('locked', !user);
    btn.style.display = user ? 'inline-flex' : 'none';
  });
  qa('.nav-btn[data-view="login"], .nav-btn[data-view="register"]').forEach(btn => {
    btn.style.display = user ? 'none' : 'inline-flex';
  });
}


function passwordValidation(pass, confirm='') {
  return {
    length: pass.length >= 8,
    upper: /[A-Z]/.test(pass),
    lower: /[a-z]/.test(pass),
    number: /\d/.test(pass),
    special: /[^A-Za-z0-9\s]/.test(pass),
    spaces: !/\s/.test(pass),
    match: pass.length > 0 && pass === confirm,
  };
}

function renderPasswordRules() {
  const pass = q('registerPassword').value || '';
  const confirm = q('registerPasswordConfirm').value || '';
  const rules = passwordValidation(pass, confirm);
  const rows = [
    ['Use 8 or more characters.', rules.length],
    ['Add one uppercase letter.', rules.upper],
    ['Add one lowercase letter.', rules.lower],
    ['Add one number.', rules.number],
    ['Add one special character.', rules.special],
    ['Do not use spaces.', rules.spaces],
    ['Both passwords match.', rules.match],
  ];
  q('passwordRules').innerHTML = rows.map(([t, ok]) => `<div class="${ok ? 'rule-ok' : 'rule-bad'}">${ok ? '✓' : '✗'} ${t}</div>`).join('');
  const score = Object.values(rules).filter(Boolean).length;
  q('passwordMeterFill').style.width = `${Math.max(10, (score / 7) * 100)}%`;
  q('passwordMeterText').textContent = score <= 2 ? 'Weak' : score <= 5 ? 'Medium' : 'Strong';
  q('registerBtn').disabled = !Object.values(rules).every(Boolean) || !window.__otpVerified;
}

async function apiFetch(url, options={}) {
  const res = await fetch(api + url, {
    ...options,
    headers: { ...(options.headers || {}), ...authHeaders() },
  });
  let data;
  const ct = res.headers.get('content-type') || '';
  data = ct.includes('application/json') ? await res.json() : await res.text();
  if (!res.ok) {
    const detail = typeof data === 'object' ? (data.detail || data.message || JSON.stringify(data)) : data;
    throw new Error(detail || 'Request failed');
  }
  return data;
}

async function handleLogin() {
  setMessage('loginMsg', '');
  const email = q('loginEmail').value.trim();
  const password = q('loginPassword').value;
  if (!email || !password) return setMessage('loginMsg', 'Enter email and password.', 'error');
  const btn = q('loginBtn'); btn.disabled = true; btn.textContent = 'Logging in...';
  try {
    const data = await apiFetch('/api/auth/login', { method: 'POST', body: formBody({ email, password }) });
    state.auth = data;
    saveAuth();
    refreshAuthUI();
    toast('Logged in successfully.');
    q('loginPassword').value = '';
    setActiveView('solver');
  } catch (e) {
    setMessage('loginMsg', e.message, 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Login';
  }
}

function resetRegisterFlow() {
  window.__otpSent = false; window.__otpVerified = false;
  q('otpSection').classList.add('hidden');
  q('passwordSection').classList.add('hidden');
  q('registerOtp').disabled = true;
  q('verifyOtpBtn').disabled = true;
  q('registerPassword').disabled = true;
  q('registerPasswordConfirm').disabled = true;
  q('stepMail').classList.add('active'); q('stepOtp').classList.remove('active'); q('stepPassword').classList.remove('active');
}

function enableOtpStep() {
  window.__otpSent = true;
  q('otpSection').classList.remove('hidden');
  q('registerOtp').disabled = false;
  q('verifyOtpBtn').disabled = false;
  q('stepOtp').classList.add('active');
}

function enablePasswordStep() {
  window.__otpVerified = true;
  q('passwordSection').classList.remove('hidden');
  q('registerPassword').disabled = false;
  q('registerPasswordConfirm').disabled = false;
  q('stepPassword').classList.add('active');
  renderPasswordRules();
}

async function handleSendOtp() {
  setMessage('registerMsg', '');
  const email = q('registerEmail').value.trim();
  if (!email) return setMessage('registerMsg', 'Enter your email first.', 'error');
  const btn = q('sendOtpBtn'); btn.disabled = true; btn.textContent = 'Sending...'; q('registerMsg').textContent='';
  try {
    const data = await apiFetch('/api/auth/send-otp', { method: 'POST', body: formBody({ email }) });
    const msg = data.demo_otp ? `OTP sent. Demo OTP: ${data.demo_otp}` : 'OTP sent to your email.';
    enableOtpStep();
    setMessage('registerMsg', msg, 'success');
    toast('OTP sent.', 'success');
  } catch (e) {
    setMessage('registerMsg', e.message, 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Send OTP';
  }
}

async function handleVerifyOtp() {
  if (!window.__otpSent) return setMessage('registerMsg', 'Send OTP first.', 'error');
  const email = q('registerEmail').value.trim();
  const otp = q('registerOtp').value.trim();
  if (!email || !otp) return setMessage('registerMsg', 'Enter email and OTP.', 'error');
  const btn = q('verifyOtpBtn'); btn.disabled = true; btn.textContent = 'Verifying...';
  try {
    await apiFetch('/api/auth/verify-otp', { method: 'POST', body: formBody({ email, otp }) });
    enablePasswordStep();
    setMessage('registerMsg', 'OTP verified. Set your password and create the account.', 'success');
    toast('OTP verified.', 'success');
  } catch (e) {
    window.__otpVerified = false;
    setMessage('registerMsg', e.message, 'error');
    renderPasswordRules();
  } finally {
    btn.disabled = false; btn.textContent = 'Verify OTP';
  }
}

async function handleRegister() {
  const name = q('registerName').value.trim();
  const email = q('registerEmail').value.trim();
  const password = q('registerPassword').value;
  if (!window.__otpVerified) return setMessage('registerMsg', 'Verify OTP first.', 'error');
  const btn = q('registerBtn'); btn.disabled = true; btn.textContent = 'Creating...';
  try {
    const data = await apiFetch('/api/auth/register', { method: 'POST', body: formBody({ name, email, password }) });
    state.auth = data;
    saveAuth();
    refreshAuthUI();
    toast('Account created successfully.', 'success');
    setActiveView('solver');
  } catch (e) {
    setMessage('registerMsg', e.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Create Account';
    renderPasswordRules();
  }
}


async function loadTopics() {
  const data = await apiFetch('/api/topics');
  state.topics = data;
  const opts = ['<option value="">Auto-detect</option>'].concat(data.map(t => `<option value="${t.key}">${t.label}</option>`)).join('');
  q('solverTopicHint').innerHTML = opts;
  q('practiceTopic').innerHTML = data.map(t => `<option value="${t.key}">${t.label}</option>`).join('');
  if (q('exampleChips')) q('exampleChips').innerHTML = '';
}


async function loadFormulas() {
  const data = await apiFetch('/api/formulas');
  state.formulas = data.topics || [];
  renderFormulaSidebar();
  if (!state.selectedFormulaTopic && state.formulas[0]) state.selectedFormulaTopic = state.formulas[0].key;
  if (state.selectedFormulaTopic) renderFormulaContent(state.selectedFormulaTopic);
}

function renderFormulaSidebar() {
  const term = q('formulaSearch').value.trim().toLowerCase();
  const list = state.formulas.filter(t => !term || `${t.label} ${t.key}`.toLowerCase().includes(term));
  q('formulaTopicList').innerHTML = list.map(t => `<button class="topic-btn ${state.selectedFormulaTopic === t.key ? 'active' : ''}" data-topic="${t.key}"><strong>${t.label}</strong><div class="small-muted">${t.count} items</div></button>`).join('');
  q('formulaTopicList').querySelectorAll('[data-topic]').forEach(btn => btn.addEventListener('click', () => {
    state.selectedFormulaTopic = btn.dataset.topic;
    renderFormulaSidebar();
    renderFormulaContent(btn.dataset.topic);
  }));
}

async function renderFormulaContent(topicKey) {
  const data = await apiFetch(`/api/formulas/${topicKey}`);
  const topic = data.data || {};
  const sections = topic.sections || [];
  q('formulaContent').innerHTML = `
    <div class="stack">
      <div>
        <h3>${data.label}</h3>
        <div class="small-muted">${topic.intro || ''}</div>
      </div>
      ${sections.map(sec => `<div class="card"><h4>${sec.name}</h4>${(sec.formulas || []).map(f => `<div class="card"><strong>${f.name}</strong><div class="formula-block">${f.formula}</div><div class="small-muted">${f.desc || f.meaning || ''}</div></div>`).join('')}</div>`).join('')}
    </div>`;
}

function renderTimeline(items) {
  const el = q('pipelineStatus');
  if (!el) return;
  el.innerHTML = items.map(x => `<div class="timeline-item ${x.state || ''}"><strong>${x.title}</strong><div class="small-muted">${x.text || ''}</div></div>`).join('');
}

function appendStep(step) {
  const wrap = document.createElement('div');
  wrap.className = 'step-card';
  wrap.innerHTML = `
    <div class="step-head"><div><strong>Step ${step.step_number || ''} — ${step.title || 'Untitled'}</strong></div><div>${step.result || ''}</div></div>
    <div class="step-body hidden">
      <div class="info-box"><strong>Why</strong><div>${step.why || '—'}</div></div>
      <div class="formula-block">${step.working || ''}</div>
      <div class="result-box"><strong>Result</strong><div>${step.result || ''}</div></div>
      ${step.note ? `<div class="note-box"><strong>Note</strong><div>${step.note}</div></div>` : ''}
    </div>`;
  wrap.querySelector('.step-head').addEventListener('click', () => wrap.querySelector('.step-body').classList.toggle('hidden'));
  q('stepsContainer').appendChild(wrap);
}

function clearSolveOutput() {
  q('predictionBox').innerHTML = '';
  q('formulaMatchBox').innerHTML = '';
  q('similarBox').innerHTML = '';
  q('stepsContainer').innerHTML = '';
  q('solutionHeader').innerHTML = '';
  q('solutionFooter').innerHTML = '';
  q('solutionMeta').textContent = '';
  q('feedbackRow').classList.add('hidden');
  q('ocrPanel').classList.add('hidden');
  renderTimeline([]);
}

async function handleClassify() {
  const question = q('solverQuestion').value.trim();
  if (!question) return toast('Enter a question first.', 'error');
  const data = await apiFetch('/api/classify', { method: 'POST', body: formBody({ question }) });
  renderMetaBoxes(data.meta, data.similar_examples, data.doc_chunks, data.retrieval_similarity);
  renderTimeline([
    { title: 'Classify', text: `${data.meta.topic_label || data.meta.topic} • ${Math.round((data.meta.topic_confidence || 0) * 100)}%`, state: 'done' },
    { title: 'Retrieve', text: `${(data.similar_examples || []).length} similar examples`, state: 'done' },
  ]);
}

function renderMetaBoxes(meta={}, similar=[], docs=[], retrieval=0) {
  q('predictionBox').innerHTML = `
    <div class="card"><strong>Topic</strong><div>${meta.topic_label || meta.topic || '—'}</div><div class="small-muted">Confidence: ${Math.round((meta.topic_confidence || 0) * 100)}%</div></div>
    <div class="card"><strong>Difficulty</strong><div>${meta.difficulty || '—'}</div></div>
    <div class="card"><strong>Question type</strong><div>${meta.question_type || '—'}</div></div>
`; 
  q('formulaMatchBox').innerHTML = (docs || []).length ? docs.map(x => `<div class="card"><strong>${x.topic || 'Reference'}</strong><div class="small-muted">${x.text || x.chunk || ''}</div></div>`).join('') : '<div class="small-muted">Formulas and documents will appear here.</div>';
  q('similarBox').innerHTML = (similar || []).length ? similar.map(x => `<div class="card"><div>${x.question || ''}</div><div class="small-muted">${x.topic || ''} • similarity ${Math.round((x.score || 0) * 100)}%</div></div>`).join('') : '<div class="small-muted">Similar examples will appear here.</div>';
  if (q('solutionMeta')) q('solutionMeta').textContent = ''; 
}

async function handleSolve() {
  clearSolveOutput();
  if (state.solverMode === 'image') return handleSolveImage();
  const question = q('solverQuestion').value.trim();
  if (!question) return toast('Enter a question first.', 'error');

  const fd = formBody({ question, topic_hint: q('solverTopicHint').value, username: state.auth?.user?.username || 'guest' });
  const res = await fetch('/api/solve-stream', { method: 'POST', body: fd, headers: authHeaders() });
  if (!res.ok) {
    const err = await res.text();
    toast(err || 'Could not solve.', 'error');
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  const timeline = [];
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let lines = buffer.split('\n');
    buffer = lines.pop();
    for (const line of lines) {
      if (!line.trim()) continue;
      let item;
      try { item = JSON.parse(line); } catch { continue; }
      if (item.type === 'stage') {
        if (item.stage === 'classify') {
          state.lastPromptStyle = item.prompt_style || state.lastPromptStyle;
          renderMetaBoxes(item.meta || {}, [], [], 0);
          timeline.push({ title: 'Classify', text: `${item.meta.topic_label || item.meta.topic}`, state: 'done' });
        } else if (item.stage === 'retrieve') {
          q('formulaMatchBox').innerHTML = (item.formula_matches || []).map(f => `<div class="card"><strong>${f.name || ''}</strong><div class="formula-block">${f.formula || ''}</div><div class="small-muted">${f.meaning || f.desc || ''}</div></div>`).join('') || '<div class="small-muted">No direct formula matches.</div>';
          q('similarBox').innerHTML = (item.similar_examples || []).map(s => `<div class="card"><div>${s.question || ''}</div><div class="small-muted">${s.topic || ''} • score ${Math.round((s.score || 0) * 100)}%</div></div>`).join('') || '<div class="small-muted">No similar examples.</div>';
          timeline.push({ title: 'Retrieve', text: 'Retrieved formulas and examples', state: 'done' });
        } else if (item.stage === 'validate_pre') {
          timeline.push({ title: 'Pre-validation', text: 'Checked parser availability and input.', state: 'done' });
        } else if (item.stage === 'validate_post') {
          timeline.push({ title: 'Post-validation', text: `Consistency: ${item.validation.consistency || '—'}`, state: 'done' });
        }
        renderTimeline(timeline);
      }
      if (item.type === 'step') {
        appendStep(item.step);
      }
      if (item.type === 'done') {
        state.lastHistoryId = item.history_id;
        const final = item.final || {};
        q('solutionHeader').innerHTML = `
          <div class="card"><strong>Problem</strong><div>${final.problem_restatement || question}</div></div>
          <div class="card"><strong>Approach</strong><div>${final.approach || '—'}</div></div>`;
        q('solutionFooter').innerHTML = `
          <div class="card"><strong>Final answer</strong><div class="formula-block">${final.final_answer || '—'}</div></div>
          <div class="card"><strong>Verification</strong><div>${final.verification || '—'}</div></div>
          `;
        if (q('solutionMeta')) q('solutionMeta').textContent = ''; 
        q('feedbackRow').classList.remove('hidden');
      }
    }
  }
}

async function handleSolveImage() {
  const file = q('solverImage').files[0];
  if (!file) return toast('Choose an image first.', 'error');
  const fd = new FormData();
  fd.append('image', file);
  fd.append('topic_hint', q('solverTopicHint').value);
  fd.append('username', state.auth?.user?.username || 'guest');

  const res = await fetch('/api/solve-image-stream', { method: 'POST', body: fd, headers: authHeaders() });
  if (!res.ok) {
    const err = await res.text();
    toast(err || 'Could not solve image.', 'error');
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  const timeline = [];
  let extracted = '';

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop();
    for (const line of lines) {
      if (!line.trim()) continue;
      let item;
      try { item = JSON.parse(line); } catch { continue; }
      if (item.type === 'stage') {
        if (item.stage === 'ocr') {
          extracted = item.ocr_text || '';
          q('ocrPanel').classList.remove('hidden');
          q('ocrExtractedText').textContent = extracted || 'No OCR text returned';
          q('ocrMeta').textContent = `Confidence: ${item.ocr_details?.average_confidence ?? 'n/a'} • Source: ${item.ocr_details?.source || 'ocr'}`;
          q('solverQuestion').value = extracted || q('solverQuestion').value;
          timeline.push({ title: 'OCR', text: 'Question extracted from image', state: 'done' });
        } else if (item.stage === 'classify') {
          state.lastPromptStyle = item.prompt_style || state.lastPromptStyle;
          renderMetaBoxes(item.meta || {}, [], [], 0);
          timeline.push({ title: 'Classify', text: `${item.meta.topic_label || item.meta.topic}`, state: 'done' });
        } else if (item.stage === 'retrieve') {
          q('formulaMatchBox').innerHTML = (item.formula_matches || []).map(f => `<div class="card"><strong>${f.name || ''}</strong><div class="formula-block">${f.formula || ''}</div><div class="small-muted">${f.meaning || f.desc || ''}</div></div>`).join('') || '<div class="small-muted">No direct formula matches.</div>';
          q('similarBox').innerHTML = (item.similar_examples || []).map(s => `<div class="card"><div>${s.question || ''}</div><div class="small-muted">${s.topic || ''} • score ${Math.round((s.score || 0) * 100)}%</div></div>`).join('') || '<div class="small-muted">No similar examples.</div>';
          timeline.push({ title: 'Retrieve', text: 'RAG brought formulas, examples, and concept notes', state: 'done' });
        } else if (item.stage === 'validate_pre') {
          timeline.push({ title: 'Prepare explanation', text: 'Building guided steps from OCR text', state: 'done' });
        } else if (item.stage === 'validate_post') {
          timeline.push({ title: 'Validate', text: `Consistency: ${item.validation.consistency || '—'}`, state: 'done' });
        }
        renderTimeline(timeline);
      }
      if (item.type === 'step') appendStep(item.step);
      if (item.type === 'done') {
        state.lastHistoryId = item.history_id;
        const final = item.final || {};
        q('solutionHeader').innerHTML = `
          <div class="card"><strong>OCR problem</strong><div>${final.problem_restatement || extracted || '—'}</div></div>
          <div class="card"><strong>Approach</strong><div>${final.approach || 'RAG-supported OCR solution path'}</div></div>`;
        q('solutionFooter').innerHTML = `
          <div class="card"><strong>Final answer</strong><div class="formula-block">${final.final_answer || '—'}</div></div>
          <div class="card"><strong>Verification</strong><div>${final.verification || '—'}</div></div>`;
        q('feedbackRow').classList.remove('hidden');
      }
    }
  }
}

async function sendFeedback(reward) {
  if (!state.auth?.access_token || !state.lastHistoryId) return toast('Log in and solve a question first.', 'error');
  try {
    await apiFetch('/api/feedback', { method: 'POST', body: formBody({ history_id: state.lastHistoryId, reward, prompt_style: state.lastPromptStyle }) });
    toast('Feedback saved.', 'success');
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function loadDashboard() {
  if (!state.auth?.access_token) return;
  try {
    const [stats, admin] = await Promise.all([
      apiFetch('/api/stats'),
      apiFetch('/api/admin/model-stats')
    ]);
    q('statSolved').textContent = stats.total_solved ?? 0;
    q('statMistral').textContent = `${stats.mistral_percent ?? 0}%`;
    q('statLocal').textContent = `${stats.local_percent ?? 0}%`;
    q('statWeakTopic').textContent = stats.weak_topic || '—';
    q('modelStatus').textContent = `Topic acc: ${admin.training_report?.topic_accuracy || 'n/a'} | Difficulty acc: ${admin.training_report?.difficulty_accuracy || 'n/a'} | Pseudo-labels: ${admin.pseudo_labels_count || 0}`;
    q('policyStatus').textContent = `Best style: ${admin.policy?.best_style || 'detailed'} | ε-greedy active`;
    if (admin.admin_badge) {
      q('adminBadge').classList.remove('hidden');
      q('adminBadge').textContent = admin.admin_badge;
    }
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function loadHistory() {
  if (!state.auth?.access_token) return;
  try {
    const params = new URLSearchParams({ page: '1', per_page: '20' });
    const data = await apiFetch(`/api/history?${params}`);
    q('historyList').innerHTML = (data.items || []).map(item => `
      <div class="card">
        <div class="button-row">
          <span class="pill">${item.solver_topic || ''}</span>
          <span class="pill">${item.predicted_meta?.difficulty || ''}</span>
          <span class="pill">${item.solved_by || ''}</span>
        </div>
        <div><strong>${item.question || ''}</strong></div>
        <div class="formula-block">${item.final_answer || ''}</div>
        <details>
          <summary>Show steps</summary>
          <div class="stack">${(item.solution_json?.steps || []).map(s => `<div class="card"><strong>${s.title || ''}</strong><div class="small-muted">${s.why || ''}</div><div class="formula-block">${s.working || ''}</div></div>`).join('')}</div>
        </details>
      </div>`).join('') || '<div class="small-muted">No history yet.</div>';
  } catch (e) {
    toast(e.message, 'error');
  }
}


async function generatePractice() {
  const topic = q('practiceTopic').value;
  const count = Math.max(1, Math.min(20, Number(q('practiceCount').value || 1)));
  const data = await apiFetch('/practice/generate', { method: 'POST', body: formBody({ topic, count }) });
  const questions = data.questions || (data.question ? [data.question] : []);
  q('practiceSet').innerHTML = questions.map((item, idx) => `<button type="button" class="topic-btn" data-practice-question="${encodeURIComponent(item)}"><strong>Question ${idx + 1}</strong><div class="small-muted">${item}</div></button>`).join('') || '<div class="small-muted">No questions generated.</div>';
  q('practiceResult').innerHTML = '';
  q('practiceAnswer').value = '';
  if (questions[0]) q('practiceQuestion').value = questions[0];
  q('practiceSet').querySelectorAll('[data-practice-question]').forEach(btn => btn.addEventListener('click', () => {
    q('practiceQuestion').value = decodeURIComponent(btn.dataset.practiceQuestion);
    q('practiceAnswer').value = '';
    q('practiceResult').innerHTML = '';
  }));
}

async function checkPractice() {
  const body = formBody({
    question: q('practiceQuestion').value,
    topic: q('practiceTopic').value,
    user_answer: q('practiceAnswer').value,
    username: state.auth?.user?.username || 'guest',
  });
  const data = await apiFetch('/practice/check', { method: 'POST', body });
  q('practiceResult').innerHTML = `
    <div class="card"><strong>${data.message || ''}</strong><div class="formula-block">Correct answer: ${data.correct_answer || ''}</div></div>
    ${((data.steps || []).map(s => `<div class="card">${s}</div>`).join(''))}`;
}

async function loadVideos() {
  const data = await apiFetch('/listening');
  const items = data.items || [];
  const select = q('videoTopicSelect');
  select.innerHTML = `<option value="">Choose a topic</option>` + items.map((v, idx) => `<option value="${idx}">${v.topic}</option>`).join('');
  q('videoTopicCards').innerHTML = items.map((v, idx) => `
    <button type="button" class="topic-btn video-topic-btn" data-video-index="${idx}">
      <strong>${v.topic}</strong>
      <div class="small-muted">Tap to select this lesson</div>
    </button>`).join('') || '<div class="small-muted">No lesson videos are available yet.</div>';

  qa('.video-topic-btn').forEach(btn => btn.addEventListener('click', () => {
    select.value = btn.dataset.videoIndex;
    playSelectedVideo(items[Number(btn.dataset.videoIndex)]);
  }));

  q('playSelectedVideoBtn').onclick = () => {
    const idx = select.value;
    if (idx === '') return toast('Choose a topic first.', 'error');
    playSelectedVideo(items[Number(idx)]);
  };
}

function playSelectedVideo(video) {
  if (!video) return;
  q('videoPlayerArea').innerHTML = `
    <div class="card playing-card">
      <strong>${video.topic}</strong>
      <div class="small-muted">Selected lesson video</div>
      <video controls autoplay src="${video.url}" style="margin-top:10px;width:100%;border-radius:18px"></video>
    </div>`;
}


async function loadProfile() {
  if (!state.auth?.user?.username) return;
  const data = await apiFetch(`/profile?username=${encodeURIComponent(state.auth.user.username)}`);
  q('profileUsername').value = data.username || '';
  q('profileEmail').value = data.email || '';
  if (q('passwordChangeMsg')) q('passwordChangeMsg').textContent = '';
}

async function saveProfile() {
  try {
    const data = await apiFetch('/profile/update', { method: 'POST', body: formBody({ username: state.auth.user.username, email: q('profileEmail').value, new_username: q('profileUsername').value }) });
    state.auth.user = data.user;
    saveAuth();
    refreshAuthUI();
    setMessage('profileMsg', 'Profile updated.', 'success');
  } catch (e) { setMessage('profileMsg', e.message, 'error'); }
}

async function sendProfileOtp() {
  try {
    const data = await apiFetch('/profile/send-otp', { method: 'POST', body: formBody({ username: state.auth.user.username }) });
    setMessage('passwordChangeMsg', data.detail || 'OTP sent. Check your email and type the 6-digit code here.', 'success');
  } catch (e) { setMessage('passwordChangeMsg', e.message, 'error'); }
}

async function changePassword() {
  try {
    await apiFetch('/profile/change-password', { method: 'POST', body: formBody({ username: state.auth.user.username, otp: q('profileOtp').value, new_password: q('profileNewPassword').value }) });
    setMessage('passwordChangeMsg', 'Password changed successfully.', 'success');
    q('profileOtp').value = ''; q('profileNewPassword').value = '';
  } catch (e) { setMessage('passwordChangeMsg', e.message, 'error'); }
}

async function deleteAllHistory() {
  if (!confirm('Delete all history?')) return;
  try { const d = await apiFetch('/api/profile/history', { method: 'DELETE' }); toast(`Deleted ${d.deleted || 0} items.`); loadHistory(); } catch (e) { toast(e.message, 'error'); }
}

async function deleteAccount() {
  if (!confirm('Delete account permanently?')) return;
  try { await apiFetch('/api/profile/account', { method: 'DELETE' }); state.auth = null; saveAuth(); refreshAuthUI(); setActiveView('login'); toast('Account deleted.'); } catch (e) { toast(e.message, 'error'); }
}

function calcAppend(v) { state.calcExpr += v; renderCalc(); }
function renderCalc() { q('calcDisplay').textContent = state.calcExpr || '0'; q('calcModeLabel').textContent = state.calcMode; q('calcHistory').innerHTML = state.calcHistory.map(x => `<div class="card">${x}</div>`).join(''); }
function initCalculator() {
  const buttons = ['MC','MR','MS','M+','(',' )','7','8','9','/','sin','asin','4','5','6','*','cos','acos','1','2','3','-','tan','atan','0','.','π','e','+','log','ln','x²','xⁿ','√','∛','%','±','C','='];
  q('calcGrid').innerHTML = '';
  buttons.forEach(label => {
    const btn = document.createElement('button'); btn.textContent = label.trim();
    btn.addEventListener('click', () => calcPress(label.trim())); q('calcGrid').appendChild(btn);
  });
  renderCalc();
}
function calcPress(b) {
  if (b === 'C') { state.calcExpr = ''; return renderCalc(); }
  if (b === 'MC') { state.calcMemory = 0; return renderCalc(); }
  if (b === 'MR') { state.calcExpr += String(state.calcMemory); return renderCalc(); }
  if (b === 'MS') { try { state.calcMemory = Number(evalCalc(state.calcExpr)); } catch {} return renderCalc(); }
  if (b === 'M+') { try { state.calcMemory += Number(evalCalc(state.calcExpr)); } catch {} return renderCalc(); }
  if (b === '±') { state.calcExpr = state.calcExpr ? `(-1*(${state.calcExpr}))` : state.calcExpr; return renderCalc(); }
  if (b === 'x²') { state.calcExpr += '**2'; return renderCalc(); }
  if (b === 'xⁿ') { state.calcExpr += '^'; return renderCalc(); }
  if (['sin','cos','tan','asin','acos','atan','log','ln','√','∛'].includes(b)) {
    const token = b === '√' ? 'sqrt(' : b === '∛' ? 'cbrt(' : `${b}(`;
    state.calcExpr += token; return renderCalc();
  }
  if (b === '=') {
    try {
      const out = evalCalc(state.calcExpr);
      state.calcHistory = [`${state.calcExpr} = ${out}`, ...state.calcHistory].slice(0,10);
      state.calcExpr = String(out);
    } catch { state.calcExpr = 'Error'; }
    return renderCalc();
  }
  state.calcExpr += b;
  renderCalc();
}
function evalCalc(expr) {
  let e = expr.replaceAll('π', 'Math.PI').replace(/\be\b/g, 'Math.E').replaceAll('^', '**').replaceAll('%', '/100').replaceAll('sqrt(', 'Math.sqrt(').replaceAll('cbrt(', 'Math.cbrt(').replaceAll('log(', 'Math.log10(').replaceAll('ln(', 'Math.log(');
  for (const fn of ['sin','cos','tan']) {
    e = e.replace(new RegExp(`${fn}\\(([^)]+)\\)`, 'g'), (_, x) => `Math.${fn}(${state.calcMode === 'DEG' ? `(${x})*Math.PI/180` : x})`);
  }
  for (const fn of ['asin','acos','atan']) {
    e = e.replace(new RegExp(`${fn}\\(([^)]+)\\)`, 'g'), (_, x) => state.calcMode === 'DEG' ? `(Math.${fn}(${x})*180/Math.PI)` : `Math.${fn}(${x})`);
  }
  return Function(`return (${e})`)();
}

function bindEvents() {
  qa('.nav-btn').forEach(btn => btn.addEventListener('click', () => {
    const view = btn.dataset.view;
    if (['solver','formulas','calculator','history','practice','listening','profile','mlsystem'].includes(view) && !state.auth?.access_token) return requireAuth(view);
    setActiveView(view);
  }));
  qa('[data-goto]').forEach(btn => btn.addEventListener('click', () => { const v = btn.dataset.goto; if (['solver','history','practice','profile','formulas','calculator','listening','mlsystem'].includes(v) && !state.auth?.access_token) return setActiveView('login'); setActiveView(v); }));
  if (q('logoutBtn')) q('logoutBtn').addEventListener('click', () => { state.auth = null; saveAuth(); refreshAuthUI(); setActiveView('login'); toast('Logged out.'); });
  if (q('loginBtn')) q('loginBtn').addEventListener('click', handleLogin);
  if (q('sendOtpBtn')) q('sendOtpBtn').addEventListener('click', handleSendOtp);
  if (q('verifyOtpBtn')) q('verifyOtpBtn').addEventListener('click', handleVerifyOtp);
  if (q('registerBtn')) q('registerBtn').addEventListener('click', handleRegister);
  if (q('toggleLoginPassword')) q('toggleLoginPassword').addEventListener('click', () => { const el = q('loginPassword'); el.type = el.type === 'password' ? 'text' : 'password'; q('toggleLoginPassword').textContent = el.type === 'password' ? 'Show' : 'Hide'; });
  if (q('toggleRegisterPassword')) q('toggleRegisterPassword').addEventListener('click', () => { const el = q('registerPassword'); el.type = el.type === 'password' ? 'text' : 'password'; q('toggleRegisterPassword').textContent = el.type === 'password' ? 'Show' : 'Hide'; });
  if (q('registerPassword')) q('registerPassword').addEventListener('input', renderPasswordRules);
  if (q('registerPasswordConfirm')) q('registerPasswordConfirm').addEventListener('input', renderPasswordRules);
  if (q('formulaSearch')) q('formulaSearch').addEventListener('input', renderFormulaSidebar);
  if (q('solveBtn')) q('solveBtn').addEventListener('click', handleSolve);
  if (q('clearSolveBtn')) q('clearSolveBtn').addEventListener('click', () => { q('solverQuestion').value = ''; q('solverImage').value = ''; clearSolveOutput(); });
  qa('[data-solver-mode]').forEach(btn => btn.addEventListener('click', () => {
    state.solverMode = btn.dataset.solverMode;
    qa('[data-solver-mode]').forEach(x => x.classList.toggle('active', x === btn));
    q('textModeArea').classList.toggle('hidden', state.solverMode !== 'text');
    q('imageModeArea').classList.toggle('hidden', state.solverMode !== 'image');
  }));
  if (q('feedbackUp')) q('feedbackUp').addEventListener('click', () => sendFeedback(1));
  if (q('feedbackDown')) q('feedbackDown').addEventListener('click', () => sendFeedback(-1));
  if (q('practiceGenerateBtn')) q('practiceGenerateBtn').addEventListener('click', generatePractice);
  if (q('practiceCheckBtn')) q('practiceCheckBtn').addEventListener('click', checkPractice);
  if (q('practiceClearBtn')) q('practiceClearBtn').addEventListener('click', () => { q('practiceQuestion').value=''; q('practiceAnswer').value=''; q('practiceResult').innerHTML=''; if (q('practiceSet')) q('practiceSet').innerHTML=''; });
  if (q('profileSaveBtn')) q('profileSaveBtn').addEventListener('click', saveProfile);
  if (q('profileSendOtpBtn')) q('profileSendOtpBtn').addEventListener('click', sendProfileOtp);
  if (q('profileChangePasswordBtn')) q('profileChangePasswordBtn').addEventListener('click', changePassword);
  if (q('deleteHistoryBtn')) q('deleteHistoryBtn').addEventListener('click', deleteAllHistory);
  if (q('deleteAccountBtn')) q('deleteAccountBtn').addEventListener('click', deleteAccount);
  if (q('calcModeBtn')) q('calcModeBtn').addEventListener('click', () => { state.calcMode = state.calcMode === 'DEG' ? 'RAD' : 'DEG'; renderCalc(); });
}

async function init() {
  loadAuth();
  refreshAuthUI();
  bindEvents();
  initCalculator();
  renderPasswordRules();
  await loadTopics();
  resetRegisterFlow();
  setActiveView(state.auth?.access_token ? 'solver' : 'login');
  if (state.auth?.access_token) {
    try {
      const user = await apiFetch('/api/auth/me');
      state.auth.user = user;
      saveAuth();
      refreshAuthUI();
    } catch {
      state.auth = null; saveAuth(); refreshAuthUI();
    }
  }
}

init();

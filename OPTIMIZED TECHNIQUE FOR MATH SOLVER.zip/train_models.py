from __future__ import annotations
import sys
from backend.ml_training import train_all

if __name__ == '__main__':
    epochs = 3
    if len(sys.argv) > 1:
        try:
            epochs = int(sys.argv[1])
        except Exception:
            pass
    report = train_all(epochs=epochs)
    print(report)

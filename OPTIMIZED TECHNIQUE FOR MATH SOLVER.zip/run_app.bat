@echo off
setlocal
cd /d %~dp0

echo ======================================
echo          Starting Math Solver
 echo ======================================

where python >nul 2>nul
if errorlevel 1 (
  echo Python is not installed or not on PATH.
  echo Install Python 3.10+ and check "Add Python to PATH", then run again.
  pause
  exit /b 1
)

if not exist .venv (
  echo Creating virtual environment...
  python -m venv .venv
  if errorlevel 1 (
    echo Failed to create virtual environment.
    pause
    exit /b 1
  )
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
  echo Failed to activate virtual environment.
  pause
  exit /b 1
)

echo Upgrading pip...
python -m pip install --upgrade pip

echo Installing requirements...
pip install -r requirements.txt
if errorlevel 1 (
  echo Failed to install requirements.
  pause
  exit /b 1
)

echo Starting backend server...
start "Math Solver Backend" cmd /k ".venv\Scripts\activate.bat && python run_app.py"

echo Waiting for server to become ready...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$deadline=(Get-Date).AddSeconds(40); $ready=$false; while((Get-Date) -lt $deadline){ try { $r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:8000/health -TimeoutSec 3; if($r.StatusCode -eq 200){$ready=$true; break} } catch {}; Start-Sleep -Seconds 2 }; if(-not $ready){ exit 1 }"
if errorlevel 1 (
  echo Server did not become ready in time.
  echo You can check the backend window for errors.
  pause
  exit /b 1
)

echo Opening browser...
start "" http://127.0.0.1:8000/

echo Math Solver is ready.
exit /b 0

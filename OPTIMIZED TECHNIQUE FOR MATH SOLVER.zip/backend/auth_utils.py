from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from .db import (
    clear_otp,
    create_user,
    get_latest_otp,
    get_user_by_email,
    get_user_by_username,
    save_otp,
    update_user_password,
    update_user_profile,
)
from .smtp_utils import send_email


PENDING_PREFIX = 'pending_register:'


def _hash_password(password: str, salt: str) -> str:
    return hashlib.sha256(f'{salt}:{password}'.encode('utf-8')).hexdigest()


def ensure_default_users() -> None:
    if not get_user_by_username('admin'):
        salt = secrets.token_hex(8)
        create_user('admin', 'admin@mathsolver.local', salt, _hash_password('admin123', salt), 'admin')


def _validate_new_user(username: str, email: str, password: str) -> tuple[str, str, str]:
    uname = username.strip().lower()
    email = email.strip().lower()
    if len(uname) < 3:
        raise ValueError('Username must be at least 3 characters long.')
    if len(password) < 8:
        raise ValueError('Password must be at least 8 characters long.')
    if get_user_by_username(uname):
        raise ValueError('Username already exists.')
    if get_user_by_email(email):
        raise ValueError('Email already exists.')
    return uname, email, password


def send_registration_otp(username: str, email: str, password: str):
    uname, normalized_email, password = _validate_new_user(username, email, password)
    otp = ''.join(secrets.choice('0123456789') for _ in range(6))
    expires = (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat()
    purpose = PENDING_PREFIX + uname
    save_otp(uname, normalized_email, otp, purpose, expires)
    body = (
        f'Your Math Solver registration OTP is {otp}. It expires in 10 minutes.\n\n'
        f'Username: {uname}\n'
        'After verification, your account will be created.'
    )
    status = send_email(normalized_email, 'Math Solver Registration OTP', body)
    if not status.get('ok'):
        raise ValueError(status.get('detail', 'Failed to send OTP.'))
    # Store hashed password in a second OTP row to avoid adding a new table.
    pwd_salt = secrets.token_hex(8)
    save_otp(uname, normalized_email, pwd_salt + '::' + _hash_password(password, pwd_salt), purpose + ':secret', expires)
    return {'username': uname, 'email': normalized_email}


def verify_registration_otp(username: str, otp: str):
    uname = username.strip().lower()
    purpose = PENDING_PREFIX + uname
    otp_row = get_latest_otp(uname, purpose)
    secret_row = get_latest_otp(uname, purpose + ':secret')
    if not otp_row or not secret_row:
        raise ValueError('No OTP request found. Please send OTP again.')
    if otp_row['otp'] != otp.strip():
        raise ValueError('Invalid OTP.')
    expires_at = datetime.fromisoformat(otp_row['expires_at'])
    if expires_at < datetime.now(timezone.utc):
        clear_otp(uname, purpose)
        clear_otp(uname, purpose + ':secret')
        raise ValueError('OTP has expired.')
    if get_user_by_username(uname):
        clear_otp(uname, purpose)
        clear_otp(uname, purpose + ':secret')
        user = get_user_by_username(uname)
        return {'username': user['username'], 'email': user['email'], 'role': user.get('role', 'student')}
    salt, pwd_hash = secret_row['otp'].split('::', 1)
    create_user(uname, otp_row['email'], salt, pwd_hash, 'student')
    clear_otp(uname, purpose)
    clear_otp(uname, purpose + ':secret')
    user = get_user_by_username(uname)
    return {'username': user['username'], 'email': user['email'], 'role': user.get('role', 'student')}


def login_user(username: str, password: str):
    uname = username.strip().lower()
    user = get_user_by_username(uname)
    if user:
        expected = _hash_password(password, user['salt'])
        if expected == user['password_hash']:
            return {'username': user['username'], 'email': user['email'], 'role': user.get('role', 'student')}
    raise ValueError('Invalid username or password.')


def update_profile(username: str, email: str | None = None, new_username: str | None = None):
    existing = get_user_by_username(username)
    if not existing:
        raise ValueError('User not found.')
    target_username = (new_username or username).strip().lower()
    target_email = (email or existing['email']).strip().lower()
    if target_username != username and get_user_by_username(target_username):
        raise ValueError('New username already exists.')
    by_email = get_user_by_email(target_email)
    if by_email and by_email['username'] != username:
        raise ValueError('Email already exists.')
    row = update_user_profile(username, new_username=target_username, new_email=target_email)
    return {'username': row['username'], 'email': row['email'], 'role': row.get('role', 'student')}


def send_password_change_otp(username: str):
    user = get_user_by_username(username.strip().lower())
    if not user:
        raise ValueError('User not found.')
    otp = ''.join(secrets.choice('0123456789') for _ in range(6))
    expires = (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat()
    save_otp(user['username'], user['email'], otp, 'change_password', expires)
    body = f'Your Math Solver OTP is {otp}. It expires in 10 minutes.\n\nIf you did not request this, ignore this email.'
    status = send_email(user['email'], 'Math Solver OTP', body)
    if not status.get('ok'):
        raise ValueError(status.get('detail', 'Failed to send OTP.'))
    return {'email': user['email']}


def change_password_with_otp(username: str, otp: str, new_password: str):
    uname = username.strip().lower()
    if len(new_password) < 8:
        raise ValueError('Password must be at least 8 characters long.')
    row = get_latest_otp(uname, 'change_password')
    if not row:
        raise ValueError('No OTP request found.')
    if row['otp'] != otp.strip():
        raise ValueError('Invalid OTP.')
    expires_at = datetime.fromisoformat(row['expires_at'])
    if expires_at < datetime.now(timezone.utc):
        clear_otp(uname, 'change_password')
        raise ValueError('OTP has expired.')
    salt = secrets.token_hex(8)
    update_user_password(uname, salt, _hash_password(new_password, salt))
    clear_otp(uname, 'change_password')
    user = get_user_by_username(uname)
    return {'username': user['username'], 'email': user['email'], 'role': user.get('role', 'student')}

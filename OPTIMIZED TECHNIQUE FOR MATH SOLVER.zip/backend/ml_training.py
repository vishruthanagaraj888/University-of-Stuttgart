from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
ARTIFACTS_DIR = BASE_DIR / 'artifacts'
ARTIFACTS_DIR.mkdir(exist_ok=True)

TOPIC_MODEL = ARTIFACTS_DIR / 'topic_classifier.joblib'
DIFFICULTY_MODEL = ARTIFACTS_DIR / 'difficulty_classifier.joblib'
QUESTION_TYPE_MODEL = ARTIFACTS_DIR / 'question_type_classifier.joblib'
RETRIEVAL_INDEX = ARTIFACTS_DIR / 'retrieval_index.joblib'
DOC_RAG_INDEX = ARTIFACTS_DIR / 'doc_rag_index.joblib'
TRAIN_REPORT = ARTIFACTS_DIR / 'training_report.json'
PSEUDO_LABELS_PATH = ARTIFACTS_DIR / 'pseudo_labels.json'

DATA_FILES = [DATA_DIR / 'school_dataset.jsonl', DATA_DIR / 'intermediate_dataset.jsonl']
FORMULAS_PATH = DATA_DIR / 'formulas.json'
NOTES_PATH = DATA_DIR / 'book_intermediate_notes.json'

SEED_ROWS = [
    {'stage':'school','topic':'school_arithmetic','question':'what is 25 + 17'},
    {'stage':'school','topic':'school_arithmetic','question':'calculate 48 divided by 6'},
    {'stage':'school','topic':'school_percentage','question':'find 25 percent of 200'},
    {'stage':'school','topic':'school_linear_equations','question':'solve 3x + 5 = 17'},
    {'stage':'school','topic':'school_linear_equations_two_variables','question':'solve 2x + y = 5 and x - y = 1'},
    {'stage':'school','topic':'school_quadratic_equations','question':'solve x squared minus 5x plus 6 equals 0'},
    {'stage':'school','topic':'school_probability','question':'probability of getting a head in a coin toss'},
    {'stage':'school','topic':'school_statistics','question':'find the mean of 4 6 8 10'},
    {'stage':'school','topic':'school_trigonometry','question':'find sin 30'},
    {'stage':'school','topic':'school_coordinate_geometry','question':'find distance between points 1 2 and 4 6'},
    {'stage':'school','topic':'school_mensuration','question':'find area of circle with radius 7'},
    {'stage':'school','topic':'school_ratio_proportion','question':'solve the ratio 2 is to 3 equals x is to 9'},
    {'stage':'school','topic':'school_ap','question':'find nth term of arithmetic progression 2 5 8 11'},
    {'stage':'school','topic':'school_fractions','question':'add 2 by 3 and 1 by 6'},
    {'stage':'intermediate','topic':'intermediate_differentiation','question':'differentiate x squared plus 2x'},
    {'stage':'intermediate','topic':'intermediate_differentiation','question':'find derivative of sin x'},
    {'stage':'intermediate','topic':'intermediate_integration','question':'integrate x squared plus 3x'},
    {'stage':'intermediate','topic':'intermediate_matrices','question':'find determinant of matrix 1 2 3 4'},
    {'stage':'intermediate','topic':'intermediate_vectors','question':'find dot product of vectors 1 2 and 3 4'},
    {'stage':'intermediate','topic':'intermediate_probability','question':'find probability distribution mean'},
    {'stage':'intermediate','topic':'intermediate_inverse_trig','question':'find sin inverse 1 by 2'},
    {'stage':'intermediate','topic':'intermediate_relations_functions','question':'find domain and range of function f of x equals x squared'},
]


class MathVectorIndex:
    def __init__(self, vectorizer: TfidfVectorizer, matrix, rows: list[dict[str, Any]]):
        self.vectorizer = vectorizer
        self.matrix = matrix
        self.rows = rows

    def query(self, text: str, top_k: int = 3) -> list[dict[str, Any]]:
        if not text.strip() or not self.rows:
            return []
        q = self.vectorizer.transform([text])
        scores = (self.matrix @ q.T).toarray().ravel()
        order = np.argsort(-scores)[:top_k]
        out = []
        for idx in order:
            if scores[idx] <= 0:
                continue
            row = dict(self.rows[idx])
            row['similarity'] = float(scores[idx])
            out.append(row)
        return out


def iter_dataset(path: Path):
    if not path.exists():
        return
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def derive_difficulty(row: dict[str, Any]) -> str:
    topic = row.get('topic', '')
    q = row.get('question', '').lower()
    stage = row.get('stage', 'school')
    nums = len([x for x in q.split() if any(ch.isdigit() for ch in x)])
    advanced_keywords = [
        'differentiate', 'integrate', 'determinant', 'eigen', 'probability distribution',
        'permutation', 'combination', 'vector', '3d', 'matrix', 'inverse', 'binomial',
        'complex', 'limit', 'continuity', 'derivative', 'differential equation', 'modulus'
    ]
    medium_keywords = [
        'quadratic', 'ratio', 'percentage', 'slope', 'distance', 'statistics', 'probability',
        'trigonometry', 'surface area', 'volume', 'factor', 'multiple', 'fraction', 'decimal'
    ]
    if stage == 'intermediate' or any(k in q or k in topic for k in advanced_keywords):
        return 'advanced'
    if nums >= 4 or any(k in q or k in topic for k in medium_keywords):
        return 'intermediate'
    return 'basic'


def derive_question_type(row: dict[str, Any]) -> str:
    q = row.get('question', '').lower()
    if any(k in q for k in ['word problem', 'cost price', 'train', 'boat', 'mixture', 'together', 'remaining']):
        return 'word_problem'
    if any(k in q for k in ['prove', 'show that', 'verify', 'identity', 'true or false']):
        return 'proof_or_verification'
    if any(k in q for k in ['graph', 'plot', 'table', 'chart', 'histogram', 'bar graph', 'ogive']):
        return 'graph_or_data'
    if any(k in q for k in ['differentiate', 'derivative', 'integrate', 'limit', 'continuity']):
        return 'calculus'
    if any(k in q for k in ['matrix', 'determinant', 'vector', 'eigen']):
        return 'linear_algebra'
    if any(k in q for k in ['probability', 'permutation', 'combination', 'distribution']):
        return 'probability'
    if re.search(r'\bsolve\b', q) or '=' in q:
        return 'equation_solving'
    if any(ch.isdigit() for ch in q) and any(op in q for op in ['+', '-', '*', '/', 'percent', 'ratio', 'fraction']):
        return 'numerical_computation'
    return 'conceptual'


def load_rows(max_per_topic: int = 220) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    per_topic: dict[str, int] = defaultdict(int)
    for path in DATA_FILES:
        for row in iter_dataset(path) or []:
            topic = row.get('topic', 'unknown')
            if per_topic[topic] >= max_per_topic:
                continue
            row = dict(row)
            row['difficulty'] = derive_difficulty(row)
            row['question_type'] = row.get('question_type') or derive_question_type(row)
            rows.append(row)
            per_topic[topic] += 1
    for row in SEED_ROWS:
        row = dict(row)
        row['difficulty'] = derive_difficulty(row)
        row['question_type'] = derive_question_type(row)
        rows.append(row)
    if PSEUDO_LABELS_PATH.exists():
        try:
            pseudo = json.loads(PSEUDO_LABELS_PATH.read_text(encoding='utf-8'))
            for row in pseudo:
                r = {'stage': 'pseudo', 'topic': row.get('topic','unknown'), 'question': row.get('question','')}
                if not r['question']:
                    continue
                r['difficulty'] = row.get('difficulty') or derive_difficulty(r)
                r['question_type'] = derive_question_type(r)
                rows.append(r)
        except Exception:
            pass
    return rows


def build_pipeline() -> Pipeline:
    return Pipeline([
        ('tfidf', TfidfVectorizer(ngram_range=(1, 3), max_features=8000, sublinear_tf=True, min_df=1)),
        ('clf', LinearSVC(C=1.5, class_weight='balanced', max_iter=5000, random_state=42)),
    ])


def _decision_confidences(model: Pipeline, text: str, top_k: int = 3) -> list[dict[str, Any]]:
    clf: LinearSVC = model.named_steps['clf']
    vec = model.named_steps['tfidf'].transform([text])
    scores = clf.decision_function(vec)
    classes = clf.classes_
    if scores.ndim == 1:
        scores = scores.reshape(1, -1)
    raw = scores[0]
    exps = np.exp(raw - np.max(raw))
    probs = exps / exps.sum()
    order = np.argsort(-probs)[:top_k]
    return [{'label': str(classes[i]), 'score': float(probs[i])} for i in order]


def build_doc_chunks(max_chunks: int = 6000) -> list[dict[str, Any]]:
    chunks: list[dict[str, Any]] = []

    if FORMULAS_PATH.exists():
        formulas = json.loads(FORMULAS_PATH.read_text(encoding='utf-8'))
        for topic_key, items in formulas.items():
            for idx, item in enumerate(items[:40]):
                text = ' '.join([
                    topic_key.replace('_', ' '),
                    item.get('name', ''),
                    item.get('formula', ''),
                    item.get('meaning', ''),
                    item.get('example', ''),
                ]).strip()
                if text:
                    chunks.append({
                        'source': 'formulas.json',
                        'doc_type': 'formula_note',
                        'topic': topic_key,
                        'chunk_id': f'formula::{topic_key}::{idx}',
                        'text': text,
                    })

    if NOTES_PATH.exists():
        notes = json.loads(NOTES_PATH.read_text(encoding='utf-8'))
        for idx, note in enumerate(notes[:max_chunks]):
            headings = ' | '.join(note.get('headings', []))
            sample_text = note.get('sample_text', '')
            text = ' '.join([
                note.get('source_file', ''),
                f"page {note.get('page', '')}",
                headings,
                sample_text,
            ]).strip()
            text = re.sub(r'\s+', ' ', text)
            if text:
                chunks.append({
                    'source': note.get('source_file', 'notes'),
                    'doc_type': 'book_chunk',
                    'topic': headings or 'general_math',
                    'chunk_id': f"note::{idx}",
                    'page': note.get('page'),
                    'text': text[:1200],
                })
    return chunks[:max_chunks]


def train_all() -> dict[str, Any]:
    rows = load_rows()
    if not rows:
        raise RuntimeError('No dataset rows found in data directory.')

    texts = [r['question'] for r in rows]
    topics = [r['topic'] for r in rows]
    difficulties = [r['difficulty'] for r in rows]
    question_types = [r['question_type'] for r in rows]

    x_train, x_test, y_topic_train, y_topic_test, y_diff_train, y_diff_test, y_qt_train, y_qt_test = train_test_split(
        texts, topics, difficulties, question_types,
        test_size=0.18, random_state=42, stratify=topics
    )

    topic_model = build_pipeline()
    diff_model = build_pipeline()
    question_type_model = build_pipeline()
    topic_model.fit(x_train, y_topic_train)
    diff_model.fit(x_train, y_diff_train)
    question_type_model.fit(x_train, y_qt_train)

    topic_pred = topic_model.predict(x_test)
    diff_pred = diff_model.predict(x_test)
    qt_pred = question_type_model.predict(x_test)

    retrieval_vectorizer = TfidfVectorizer(ngram_range=(1, 3), max_features=8000, sublinear_tf=True)
    retrieval_matrix = retrieval_vectorizer.fit_transform(texts)
    retrieval_index = MathVectorIndex(retrieval_vectorizer, retrieval_matrix, rows)

    doc_chunks = build_doc_chunks()
    doc_vectorizer = TfidfVectorizer(ngram_range=(1, 3), max_features=12000, sublinear_tf=True)
    doc_matrix = doc_vectorizer.fit_transform([c['text'] for c in doc_chunks]) if doc_chunks else None
    doc_rag_index = MathVectorIndex(doc_vectorizer, doc_matrix, doc_chunks) if doc_chunks else None

    joblib.dump(topic_model, TOPIC_MODEL)
    joblib.dump(diff_model, DIFFICULTY_MODEL)
    joblib.dump(question_type_model, QUESTION_TYPE_MODEL)
    joblib.dump(retrieval_index, RETRIEVAL_INDEX)
    if doc_rag_index is not None:
        joblib.dump(doc_rag_index, DOC_RAG_INDEX)

    counts = Counter(topics)
    diff_counts = Counter(difficulties)
    qt_counts = Counter(question_types)
    per_stage = defaultdict(int)
    for row in rows:
        per_stage[row.get('stage', 'unknown')] += 1

    report = {
        'dataset_rows_total_used_for_training': len(rows),
        'topic_count': len(set(topics)),
        'difficulty_distribution': dict(diff_counts),
        'question_type_distribution': dict(qt_counts),
        'stage_distribution': dict(per_stage),
        'topic_accuracy': float(accuracy_score(y_topic_test, topic_pred)),
        'difficulty_accuracy': float(accuracy_score(y_diff_test, diff_pred)),
        'question_type_accuracy': float(accuracy_score(y_qt_test, qt_pred)),
        'topic_classification_report': classification_report(y_topic_test, topic_pred, output_dict=True, zero_division=0),
        'top_topics': counts.most_common(20),
        'doc_rag_chunk_count': len(doc_chunks),
        'ml_concepts_used': [
            'supervised learning', 'multi-class classification', 'TF-IDF feature extraction',
            'n-gram modeling', 'Linear Support Vector Machine', 'train-test split',
            'balanced class weighting', 'information retrieval', 'cosine-like sparse vector similarity',
            'classical document RAG'
        ],
        'models_trained': [
            'topic_classifier: TF-IDF + LinearSVC',
            'difficulty_classifier: TF-IDF + LinearSVC',
            'question_type_classifier: TF-IDF + LinearSVC'
        ],
        'note': 'Training uses supervised learning on a balanced sampled subset of the larger local dataset so the project trains quickly on a normal laptop. Classical doc RAG is built over chunked formula notes and textbook-note passages using TF-IDF retrieval.',
    }
    TRAIN_REPORT.write_text(json.dumps(report, indent=2), encoding='utf-8')
    return report


def ensure_models() -> None:
    if not (TOPIC_MODEL.exists() and DIFFICULTY_MODEL.exists() and RETRIEVAL_INDEX.exists() and QUESTION_TYPE_MODEL.exists() and DOC_RAG_INDEX.exists()):
        train_all()


def predict_meta(question: str) -> dict[str, Any]:
    ensure_models()
    topic_model: Pipeline = joblib.load(TOPIC_MODEL)
    diff_model: Pipeline = joblib.load(DIFFICULTY_MODEL)
    qt_model: Pipeline = joblib.load(QUESTION_TYPE_MODEL)
    topic_top = _decision_confidences(topic_model, question, top_k=3)
    diff_top = _decision_confidences(diff_model, question, top_k=3)
    qt_top = _decision_confidences(qt_model, question, top_k=3)
    return {
        'topic': topic_top[0]['label'],
        'topic_confidence': topic_top[0]['score'],
        'topic_top3': topic_top,
        'difficulty': diff_top[0]['label'],
        'difficulty_confidence': diff_top[0]['score'],
        'difficulty_top3': diff_top,
        'question_type': qt_top[0]['label'],
        'question_type_confidence': qt_top[0]['score'],
        'question_type_top3': qt_top,
    }


def retrieve_similar_examples(question: str, top_k: int = 3) -> list[dict[str, Any]]:
    ensure_models()
    index: MathVectorIndex = joblib.load(RETRIEVAL_INDEX)
    return index.query(question, top_k=top_k)


def retrieve_doc_chunks(question: str, top_k: int = 4) -> list[dict[str, Any]]:
    ensure_models()
    index: MathVectorIndex = joblib.load(DOC_RAG_INDEX)
    return index.query(question, top_k=top_k)


def retrieval_novelty(question: str) -> float:
    ensure_models()
    index: MathVectorIndex = joblib.load(RETRIEVAL_INDEX)
    hits = index.query(question, top_k=1)
    if not hits:
        return 0.0
    return float(hits[0].get('similarity', 0.0))


__all__ = [
    'ensure_models', 'train_all', 'predict_meta', 'retrieve_similar_examples', 'retrieve_doc_chunks',
    'retrieval_novelty', 'TRAIN_REPORT', 'TOPIC_MODEL', 'DIFFICULTY_MODEL', 'QUESTION_TYPE_MODEL', 'RETRIEVAL_INDEX', 'DOC_RAG_INDEX'
]

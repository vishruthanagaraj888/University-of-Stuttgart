from __future__ import annotations
import json, sqlite3
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
DB_PATH = DATA_DIR / 'math_solver.db'


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with _connect() as conn:
        cur = conn.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'student',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            question TEXT,
            ocr_text TEXT,
            predicted_meta TEXT,
            solver_topic TEXT,
            question_type TEXT,
            answer_form TEXT,
            final_answer TEXT,
            solution_json TEXT,
            solved_by TEXT DEFAULT 'mistral_plus_local_ml',
            user_rating INTEGER,
            confidence REAL,
            timestamp TEXT NOT NULL
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS practice_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            topic TEXT NOT NULL,
            question TEXT NOT NULL,
            user_answer TEXT,
            correct_answer TEXT,
            is_correct INTEGER NOT NULL,
            timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS videos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            topic TEXT NOT NULL,
            filename TEXT NOT NULL,
            url TEXT NOT NULL,
            uploaded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS otp_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            email TEXT NOT NULL,
            otp TEXT NOT NULL,
            purpose TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            history_id INTEGER,
            username TEXT NOT NULL,
            reward INTEGER NOT NULL,
            prompt_style TEXT NOT NULL,
            timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS prompt_strategy (
            style TEXT PRIMARY KEY,
            reward_sum REAL NOT NULL DEFAULT 0,
            trials INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        for style in ('detailed','concise','visual'):
            cur.execute('INSERT OR IGNORE INTO prompt_strategy(style,reward_sum,trials) VALUES(?,?,?)', (style, 0, 0))
        conn.commit()
    _ensure_history_columns()


def _ensure_history_columns() -> None:
    with _connect() as conn:
        cols = {row['name'] for row in conn.execute("PRAGMA table_info(history)").fetchall()}
        if 'solution_json' not in cols:
            conn.execute('ALTER TABLE history ADD COLUMN solution_json TEXT')
        if 'solved_by' not in cols:
            conn.execute("ALTER TABLE history ADD COLUMN solved_by TEXT DEFAULT 'mistral_plus_local_ml'")
        if 'user_rating' not in cols:
            conn.execute('ALTER TABLE history ADD COLUMN user_rating INTEGER')
        conn.commit()


def create_user(username: str, email: str, salt: str, password_hash: str, role: str='student') -> None:
    with _connect() as conn:
        conn.execute('INSERT INTO users(username,email,salt,password_hash,role) VALUES(?,?,?,?,?)', (username, email, salt, password_hash, role))
        conn.commit()


def get_user_by_username(username: str) -> dict[str, Any] | None:
    with _connect() as conn:
        row = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        return dict(row) if row else None


def get_user_by_email(email: str) -> dict[str, Any] | None:
    with _connect() as conn:
        row = conn.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
        return dict(row) if row else None


def list_history(username: str | None = None, page: int = 1, per_page: int = 10, topic: str | None = None, difficulty: str | None = None) -> dict[str, Any]:
    query = 'SELECT * FROM history WHERE 1=1'
    args: list[Any] = []
    if username and username != 'guest':
        query += ' AND username=?'
        args.append(username)
    if topic:
        query += ' AND solver_topic=?'
        args.append(topic)
    if difficulty:
        query += " AND json_extract(predicted_meta, '$.difficulty') = ?"
        args.append(difficulty)
    count_q = query.replace('SELECT *', 'SELECT COUNT(*) as c')
    query += ' ORDER BY id DESC LIMIT ? OFFSET ?'
    args2 = args + [per_page, (page-1)*per_page]
    with _connect() as conn:
        total = conn.execute(count_q, tuple(args)).fetchone()['c']
        rows = [dict(r) for r in conn.execute(query, tuple(args2)).fetchall()]
    items=[]
    for r in rows:
        try:
            r['predicted_meta'] = json.loads(r.get('predicted_meta') or '{}')
        except Exception:
            r['predicted_meta'] = {}
        try:
            r['solution_json'] = json.loads(r.get('solution_json') or '{}')
        except Exception:
            r['solution_json'] = {}
        items.append(r)
    return {'items': items, 'page': page, 'per_page': per_page, 'total': total}


def get_history_item(item_id: int, username: str | None = None) -> dict[str, Any] | None:
    query = 'SELECT * FROM history WHERE id=?'
    args = [item_id]
    if username and username != 'guest':
        query += ' AND username=?'
        args.append(username)
    with _connect() as conn:
        row = conn.execute(query, tuple(args)).fetchone()
        if not row:
            return None
        r = dict(row)
    try:
        r['predicted_meta'] = json.loads(r.get('predicted_meta') or '{}')
    except Exception:
        r['predicted_meta'] = {}
    try:
        r['solution_json'] = json.loads(r.get('solution_json') or '{}')
    except Exception:
        r['solution_json'] = {}
    return r


def add_history(payload: dict[str, Any]) -> int:
    with _connect() as conn:
        cur = conn.execute('''INSERT INTO history(username,question,ocr_text,predicted_meta,solver_topic,question_type,answer_form,final_answer,solution_json,solved_by,confidence,timestamp)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', (
            payload.get('username','guest'), payload.get('question',''), payload.get('ocr_text',''), json.dumps(payload.get('predicted_meta',{}), ensure_ascii=False), payload.get('solver_topic',''),
            payload.get('question_type',''), payload.get('answer_form',''), payload.get('final_answer',''), json.dumps(payload.get('solution_json',{}), ensure_ascii=False), payload.get('solved_by','mistral_plus_local_ml'), float(payload.get('confidence',0.0)), payload.get('timestamp','')
        ))
        conn.commit()
        return int(cur.lastrowid)


def set_history_rating(history_id: int, rating: int) -> None:
    with _connect() as conn:
        conn.execute('UPDATE history SET user_rating=? WHERE id=?', (rating, history_id))
        conn.commit()


def add_feedback(history_id: int, username: str, reward: int, prompt_style: str) -> None:
    with _connect() as conn:
        conn.execute('INSERT INTO feedback(history_id,username,reward,prompt_style) VALUES(?,?,?,?)', (history_id, username, reward, prompt_style))
        conn.execute('UPDATE prompt_strategy SET reward_sum=reward_sum+?, trials=trials+1, updated_at=CURRENT_TIMESTAMP WHERE style=?', (reward, prompt_style))
        conn.commit()


def get_prompt_strategy_rows() -> list[dict[str, Any]]:
    with _connect() as conn:
        return [dict(r) for r in conn.execute('SELECT * FROM prompt_strategy ORDER BY style').fetchall()]


def add_practice_result(username: str, topic: str, question: str, user_answer: str, correct_answer: str, is_correct: bool) -> None:
    with _connect() as conn:
        conn.execute('INSERT INTO practice_results(username,topic,question,user_answer,correct_answer,is_correct) VALUES(?,?,?,?,?,?)', (username, topic, question, user_answer, correct_answer, 1 if is_correct else 0))
        conn.commit()


def list_videos() -> list[dict[str, Any]]:
    with _connect() as conn:
        rows = conn.execute('SELECT topic, filename, url, uploaded_at FROM videos ORDER BY id DESC').fetchall()
        return [dict(r) for r in rows]


def add_video(topic: str, filename: str, url: str) -> dict[str, Any]:
    with _connect() as conn:
        conn.execute('INSERT INTO videos(topic,filename,url) VALUES(?,?,?)', (topic, filename, url))
        conn.commit()
    return {'topic': topic, 'filename': filename, 'url': url}


def update_user_profile(username: str, *, new_username: str | None = None, new_email: str | None = None) -> dict[str, Any] | None:
    with _connect() as conn:
        row = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        if not row:
            return None
        current = dict(row)
        final_username = (new_username or current['username']).strip().lower()
        final_email = (new_email or current['email']).strip().lower()
        conn.execute('UPDATE users SET username=?, email=? WHERE username=?', (final_username, final_email, username))
        conn.commit()
        row = conn.execute('SELECT * FROM users WHERE username=?', (final_username,)).fetchone()
        return dict(row) if row else None


def update_user_password(username: str, salt: str, password_hash: str) -> None:
    with _connect() as conn:
        conn.execute('UPDATE users SET salt=?, password_hash=? WHERE username=?', (salt, password_hash, username))
        conn.commit()


def save_otp(username: str, email: str, otp: str, purpose: str, expires_at: str) -> None:
    with _connect() as conn:
        conn.execute('DELETE FROM otp_codes WHERE username=? AND purpose=?', (username, purpose))
        conn.execute('INSERT INTO otp_codes(username,email,otp,purpose,expires_at) VALUES(?,?,?,?,?)', (username, email, otp, purpose, expires_at))
        conn.commit()


def get_latest_otp(username: str, purpose: str) -> dict[str, Any] | None:
    with _connect() as conn:
        row = conn.execute('SELECT * FROM otp_codes WHERE username=? AND purpose=? ORDER BY id DESC LIMIT 1', (username, purpose)).fetchone()
        return dict(row) if row else None


def clear_otp(username: str, purpose: str) -> None:
    with _connect() as conn:
        conn.execute('DELETE FROM otp_codes WHERE username=? AND purpose=?', (username, purpose))
        conn.commit()



def compute_user_stats(username: str) -> dict[str, Any]:
    with _connect() as conn:
        total = conn.execute('SELECT COUNT(*) c FROM history WHERE username=?', (username,)).fetchone()['c']
        by_solver = conn.execute('SELECT solved_by, COUNT(*) c FROM history WHERE username=? GROUP BY solved_by', (username,)).fetchall()
        history_rows = conn.execute('SELECT solver_topic, question, confidence, timestamp FROM history WHERE username=? ORDER BY id DESC', (username,)).fetchall()
        rated = conn.execute('SELECT COUNT(*) c FROM feedback WHERE username=?', (username,)).fetchone()['c']
    solver_counts = {r['solved_by']: r['c'] for r in by_solver}
    weak_topic = None
    cluster_debug = []
    if len(history_rows) >= 5:
        from collections import Counter
        from sklearn.cluster import KMeans
        from sklearn.feature_extraction.text import TfidfVectorizer
        topic_texts=[]
        raw_topics=[]
        for row in history_rows:
            t=(row['solver_topic'] or 'unknown').strip()
            q=(row['question'] or '').strip()
            topic_texts.append(f"{t} :: {q}")
            raw_topics.append(t)
        vec = TfidfVectorizer(ngram_range=(1,2), min_df=1).fit_transform(topic_texts)
        k = min(10, max(2, len(history_rows)//2))
        labels = KMeans(n_clusters=k, n_init=10, random_state=42).fit_predict(vec)
        cluster_weight = {}
        cluster_topic = {}
        for lbl, topic in zip(labels, raw_topics):
            cluster_weight[lbl] = cluster_weight.get(lbl, 0) + 1
            cluster_topic.setdefault(lbl, []).append(topic)
        target = max(cluster_weight, key=cluster_weight.get)
        weak_topic = Counter(cluster_topic[target]).most_common(1)[0][0]
        cluster_debug = [
            {
                'cluster': int(lbl),
                'size': int(cluster_weight.get(lbl, 0)),
                'top_topics': [t for t,_ in Counter(cluster_topic.get(lbl, [])).most_common(5)],
            }
            for lbl in sorted(cluster_topic)
        ]
    total_solver = sum(solver_counts.values()) or 1
    solver_mix = {k: round(v * 100 / total_solver, 2) for k, v in solver_counts.items()}
    mistral_percent = solver_mix.get('Mistral', 0)
    local_labels = {'custom_engine', 'Local ML + Parser', 'SymPy Fallback', 'mistral_plus_local_ml'}
    local_percent = round(sum(v for k, v in solver_mix.items() if k in local_labels), 2)
    return {
        'total_solved': total,
        'solver_counts': solver_counts,
        'solver_mix': solver_mix,
        'mistral_percent': mistral_percent,
        'local_percent': local_percent,
        'weak_topic': weak_topic,
        'cluster_debug': cluster_debug,
        'feedback_count': rated,
    }


def delete_history_item(item_id: int, username: str) -> bool:
    with _connect() as conn:
        cur = conn.execute('DELETE FROM history WHERE id=? AND username=?', (item_id, username))
        conn.commit()
        return cur.rowcount > 0


def delete_all_history(username: str) -> int:
    with _connect() as conn:
        cur = conn.execute('DELETE FROM history WHERE username=?', (username,))
        conn.commit()
        return cur.rowcount


def delete_user_account(username: str) -> bool:
    with _connect() as conn:
        conn.execute('DELETE FROM feedback WHERE username=?', (username,))
        conn.execute('DELETE FROM practice_results WHERE username=?', (username,))
        conn.execute('DELETE FROM history WHERE username=?', (username,))
        conn.execute('DELETE FROM otp_codes WHERE username=?', (username,))
        cur = conn.execute('DELETE FROM users WHERE username=?', (username,))
        conn.commit()
        return cur.rowcount > 0

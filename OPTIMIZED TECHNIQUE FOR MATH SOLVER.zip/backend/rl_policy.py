
from __future__ import annotations
import random
from .db import get_prompt_strategy_rows

EPSILON = 0.2
STYLES = ['detailed', 'concise', 'visual']

def choose_prompt_style() -> str:
    rows = get_prompt_strategy_rows()
    if not rows:
        return 'detailed'
    if random.random() < EPSILON:
        return random.choice(STYLES)
    def avg_reward(row):
        trials = max(1, int(row.get('trials', 0) or 0))
        return float(row.get('reward_sum', 0) or 0) / trials
    return max(rows, key=avg_reward)['style']

def policy_snapshot() -> dict:
    rows = get_prompt_strategy_rows()
    best = choose_prompt_style() if rows else 'detailed'
    return {
        'epsilon': EPSILON,
        'styles': STYLES,
        'best_style': best,
        'rows': rows,
    }

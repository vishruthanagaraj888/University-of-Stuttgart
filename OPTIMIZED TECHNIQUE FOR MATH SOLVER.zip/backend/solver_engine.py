from __future__ import annotations
import ast
import math
import operator as op
import re
from dataclasses import dataclass
from fractions import Fraction
from typing import Callable

ALLOWED_AST = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.USub: op.neg,
    ast.UAdd: op.pos,
}


@dataclass
class SolveResult:
    topic: str
    question_type: str
    answer_form: str
    final_answer: str
    steps: list[str]
    confidence: float


def normalize(text: str) -> str:
    t = text.strip()
    replacements = {
        '×': '*', '÷': '/', '^': '**', '–': '-', '−': '-', '—': '-', '﹣': '-',
        '＋': '+', '／': '/', '＊': '*', '﹢': '+', '∕': '/', '⁄': '/', '％': '%', '≤': '<=', '≥': '>=',
        '²': '**2', '³': '**3', 'θ': 'theta', '₁': '1', '₂': '2', 'ₙ': 'n'
    }
    for a, b in replacements.items():
        t = t.replace(a, b)
    t = t.replace('multiplied by', '*').replace('divided by', '/').replace('plus', '+').replace('minus', '-')
    t = re.sub(r'(?i)\b(what is|evaluate|calculate|solve|find)\b', '', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t



def simplify_sqrt_int(n: int) -> str:
    if n < 0:
        return f"√({n})"
    if n == 0:
        return '0'
    outside = 1
    inside = n
    f = 2
    while f * f <= inside:
        while inside % (f * f) == 0:
            inside //= f * f
            outside *= f
        f += 1
    if inside == 1:
        return str(outside)
    if outside == 1:
        return f"√{inside}"
    return f"{outside}√{inside}"


def simplify_sqrt_float(x: float) -> str:
    if abs(x - round(x)) < 1e-9:
        return simplify_sqrt_int(int(round(x)))
    return format_num(math.sqrt(x))


def nth_term_from_sequence(nums: list[float]) -> str:
    diffs = [nums[i+1] - nums[i] for i in range(len(nums)-1)]
    if not diffs or not all(abs(d - diffs[0]) < 1e-9 for d in diffs):
        raise ValueError('Sequence is not arithmetic')
    a = nums[0]
    d = diffs[0]
    c = a - d
    d_s = format_num(d)
    if abs(c) < 1e-9:
        return f"a_n = {d_s}n"
    sign = '+' if c > 0 else '-'
    return f"a_n = {d_s}n {sign} {format_num(abs(c))}"

def safe_eval(expr: str) -> float:
    expr = expr.replace('%', '/100')
    node = ast.parse(expr, mode='eval').body
    def _eval(n):
        if isinstance(n, ast.Constant):
            return n.value
        if isinstance(n, ast.Num):
            return n.n
        if isinstance(n, ast.BinOp):
            return ALLOWED_AST[type(n.op)](_eval(n.left), _eval(n.right))
        if isinstance(n, ast.UnaryOp):
            return ALLOWED_AST[type(n.op)](_eval(n.operand))
        raise ValueError('Unsupported expression')
    return float(_eval(node))


def format_num(x: float) -> str:
    if isinstance(x, Fraction):
        return str(x)
    if abs(x - round(x)) < 1e-9:
        return str(int(round(x)))
    return f"{x:.6f}".rstrip('0').rstrip('.')


def parse_coeff(term: str) -> tuple[float, int]:
    term = term.strip()
    if 'x**' in term:
        a, p = term.split('x**')
        coeff = 1.0 if a in ('', '+') else -1.0 if a == '-' else float(a)
        return coeff, int(p)
    if 'x' in term:
        a = term.split('x')[0]
        coeff = 1.0 if a in ('', '+') else -1.0 if a == '-' else float(a)
        return coeff, 1
    return float(term), 0


def parse_polynomial(expr: str) -> dict[int, float]:
    expr = expr.replace(' ', '')
    expr = expr.replace('-', '+-')
    if expr.startswith('+-'):
        expr = expr[1:]
    poly: dict[int, float] = {}
    for term in [t for t in expr.split('+') if t]:
        coeff, power = parse_coeff(term)
        poly[power] = poly.get(power, 0.0) + coeff
    return poly


def poly_to_str(poly: dict[int, float]) -> str:
    parts = []
    for p in sorted(poly.keys(), reverse=True):
        c = poly[p]
        if abs(c) < 1e-9:
            continue
        sign = '-' if c < 0 else '+'
        a = abs(c)
        if p == 0:
            body = format_num(a)
        elif p == 1:
            body = ('x' if abs(a - 1) < 1e-9 else f'{format_num(a)}x')
        else:
            body = (f'x^{p}' if abs(a - 1) < 1e-9 else f'{format_num(a)}x^{p}')
        parts.append((sign, body))
    if not parts:
        return '0'
    first_sign, first_body = parts[0]
    s = ('-' if first_sign == '-' else '') + first_body
    for sign, body in parts[1:]:
        s += f' {sign} {body}'
    return s


def arithmetic_expr(question: str):
    expr = normalize(question).lower().replace('what is', '').replace('evaluate', '').strip()
    ans = safe_eval(expr)
    steps = [f'Interpret the input as an arithmetic expression: {expr}.', 'Apply the operations in order (BODMAS / PEMDAS).', f'Final value = {format_num(ans)}.']
    return format_num(ans), steps


def before_after(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    if not nums:
        raise ValueError('No number found')
    n = nums[0]
    q = question.lower()
    if 'before' in q or 'previous' in q:
        ans = n - 1
        steps = [f'The number before {format_num(n)} is one less than it.', f'{format_num(n)} - 1 = {format_num(ans)}.']
    else:
        ans = n + 1
        steps = [f'The number after {format_num(n)} is one more than it.', f'{format_num(n)} + 1 = {format_num(ans)}.']
    return format_num(ans), steps


def pattern_next(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    if len(nums) < 3:
        raise ValueError('Need at least three terms')
    d = nums[1] - nums[0]
    ans = nums[-1] + d
    steps = [f'Observe consecutive differences: {format_num(nums[1])}-{format_num(nums[0])} = {format_num(d)}.', f'The pattern uses the same difference {format_num(d)}.', f'Next term = {format_num(nums[-1])} + {format_num(d)} = {format_num(ans)}.']
    return format_num(ans), steps


def factors_multiples(question: str):
    nums = list(map(int, re.findall(r'\d+', question)))
    if len(nums) < 2:
        raise ValueError('Need at least two numbers')
    q = question.lower()
    a, b = nums[0], nums[1]
    if 'lcm' in q or 'least common multiple' in q:
        ans = abs(a * b) // math.gcd(a, b)
        steps = [f'Use LCM(a,b) = |ab| / HCF(a,b).', f'HCF({a},{b}) = {math.gcd(a,b)}.', f'LCM = |{a}×{b}| / {math.gcd(a,b)} = {ans}.']
        return str(ans), steps
    ans = math.gcd(a, b)
    steps = [f'Find common factors of {a} and {b}.', f'The greatest common factor is {ans}.']
    return str(ans), steps


def fraction_op(question: str):
    m = re.search(r'(\d+)\/(\d+)\s*([+\-*/])\s*(\d+)\/(\d+)', question.replace(' ', ''))
    if not m:
        raise ValueError('Unsupported fraction format')
    a, b, opn, c, d = m.groups()
    f1 = Fraction(int(a), int(b))
    f2 = Fraction(int(c), int(d))
    ans = {'+': f1 + f2, '-': f1 - f2, '*': f1 * f2, '/': f1 / f2}[opn]
    steps = [f'Write the fractions: {f1} {opn} {f2}.', 'Apply the fraction operation carefully.', f'Result = {ans}.']
    return str(ans), steps


def fraction_to_decimal(question: str):
    m = re.search(r'(\d+)\/(\d+)', question)
    if not m:
        raise ValueError('Unsupported fraction format')
    a, b = map(int, m.groups())
    ans = a / b
    steps = [f'Convert the fraction {a}/{b} into decimal by division.', f'{a} ÷ {b} = {format_num(ans)}.']
    return format_num(ans), steps


def percentage(question: str):
    m = re.search(r'(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)', question.lower())
    if not m:
        raise ValueError('Unsupported percentage format')
    p = float(m.group(1)); n = float(m.group(2)); ans = p * n / 100
    steps = [
        f'We need to find {format_num(p)}% of {format_num(n)}.',
        f'Percentage means "out of 100", so {format_num(p)}% = {format_num(p)}/100.',
        f'Now multiply the fraction by the given number: ({format_num(p)}/100) × {format_num(n)}.',
        f'This becomes {format_num(p*n)} / 100 = {format_num(ans)}.',
        f'Therefore, the required percentage is {format_num(ans)}.'
    ]
    return format_num(ans), steps


def fraction_of(question: str):
    q = normalize(question).lower()
    m = re.search(r'(\d+)\s*/\s*(\d+)\s*of\s*(-?\d+(?:\.\d+)?)', q)
    if not m:
        raise ValueError('Unsupported fraction-of format')
    a, b, n = int(m.group(1)), int(m.group(2)), float(m.group(3))
    ans = Fraction(a, b) * Fraction(str(n))
    steps = [
        f'We need to find the fraction {a}/{b} of {format_num(n)}.',
        f'The word "of" means multiplication, so compute ({a}/{b}) × {format_num(n)}.',
        f'First multiply the numerator by the number: {a} × {format_num(n)} = {format_num(a*n)}.',
        f'Then divide by the denominator {b}.',
        f'Result = {ans}.'
    ]
    return str(ans) if ans.denominator != 1 else str(ans.numerator), steps


def ratio_simple(question: str):
    nums = list(map(int, re.findall(r'-?\d+', question)))
    if len(nums) < 2:
        raise ValueError('Need two numbers for ratio')
    a, b = nums[0], nums[1]
    g = math.gcd(a, b)
    ra, rb = a // g, b // g
    steps = [
        f'Write the given ratio in raw form: {a}:{b}.',
        f'To simplify a ratio, divide both parts by their highest common factor.',
        f'HCF of {a} and {b} is {g}.',
        f'{a} ÷ {g} = {ra} and {b} ÷ {g} = {rb}.',
        f'So the simplified ratio is {ra}:{rb}.'
    ]
    return f'{ra}:{rb}', steps


def evaluate_numeric_power(question: str):
    expr = normalize(question)
    ans = safe_eval(expr)
    steps = [f'Interpret the expression as {expr}.', 'Apply exponent and multiplication rules.', f'Final value = {format_num(ans)}.']
    return format_num(ans), steps


def simple_interest_natural(question: str):
    q = normalize(question).lower()
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', q.replace(',', ''))))
    if len(nums) < 3:
        raise ValueError('Need principal, rate, and time')
    p, r, t = nums[0], nums[1], nums[2]
    si = p * r * t / 100
    steps = [
        f'Principal P = {format_num(p)}, Rate R = {format_num(r)}%, Time T = {format_num(t)} years.',
        'Use the simple interest formula: SI = (P × R × T) / 100.',
        f'Substitute the values: SI = ({format_num(p)} × {format_num(r)} × {format_num(t)}) / 100.',
        f'This gives {format_num(p*r*t)} / 100 = {format_num(si)}.',
        f'Therefore, the simple interest is {format_num(si)}.'
    ]
    return format_num(si), steps

def ratio_proportion(question: str):
    m = re.search(r'(\d+)\s*:\s*(\d+)\s*=\s*(\d+)\s*:\s*x', question.lower()) or re.search(r'(\d+)\s*/\s*(\d+)\s*=\s*(\d+)\s*/\s*x', question.lower())
    if not m:
        raise ValueError('Unsupported proportion format')
    a, b, c = map(float, m.groups())
    x = b * c / a
    steps = [f'Given {format_num(a)}:{format_num(b)} = {format_num(c)}:x.', f'Convert to fractions: {format_num(a)}/{format_num(b)} = {format_num(c)}/x.', f'Cross multiply: {format_num(a)}x = {format_num(b*c)}.', f'x = {format_num(x)}.']
    return format_num(x), steps


def simple_interest(question: str):
    vals = {k: float(v) for k, v in re.findall(r'\b([prt])\s*=\s*(-?\d+(?:\.\d+)?)', question.lower())}
    if not {'p', 'r', 't'}.issubset(vals):
        raise ValueError('Use P=, R=, T= format')
    p, r, t = vals['p'], vals['r'], vals['t']
    si = p * r * t / 100
    steps = [f'Use SI = (P×R×T)/100.', f'SI = ({format_num(p)}×{format_num(r)}×{format_num(t)})/100 = {format_num(si)}.']
    return format_num(si), steps


def parse_linear_side(s: str):
    s = s.replace(' ', '').replace('-', '+-')
    if s.startswith('+-'):
        s = s[1:]
    ax = 0.0
    b = 0.0
    for term in [t for t in s.split('+') if t]:
        if 'x' in term:
            c = term.replace('x', '')
            ax += 1.0 if c in ('', '+') else -1.0 if c == '-' else float(c)
        else:
            b += float(term)
    return ax, b


def solve_linear(expr: str) -> tuple[str, list[str]]:
    left, right = [s.strip() for s in expr.split('=')]
    a1, b1 = parse_linear_side(left)
    a2, b2 = parse_linear_side(right)
    a = a1 - a2
    b = b2 - b1
    xval = b / a
    steps = [
        f'Start with the equation: {left} = {right}.',
        'Our aim is to keep all x-terms on one side and all number terms on the other side.',
        f'After rearranging, we get {format_num(a)}x = {format_num(b)}.',
        f'Now divide both sides by the coefficient of x, which is {format_num(a)}.',
        f'x = {format_num(b)} / {format_num(a)} = {format_num(xval)}.',
        f'Therefore, the solution is x = {format_num(xval)}.'
    ]
    return format_num(xval), steps


def solve_linear_inequality(expr: str):
    m = re.search(r'(.+?)(<=|>=|<|>)(.+)', expr.replace('≤', '<=').replace('≥', '>='))
    if not m:
        raise ValueError('Unsupported inequality format')
    left, sign, right = [x.strip() for x in m.groups()]
    a1, b1 = parse_linear_side(left)
    a2, b2 = parse_linear_side(right)
    a = a1 - a2
    b = b2 - b1
    xval = b / a
    if a < 0:
        sign = {'<': '>', '>': '<', '<=': '>=', '>=': '<='}[sign]
    steps = [f'Start with: {expr}.', f'Bring x-terms to one side and constants to the other: {format_num(a)}x {sign} {format_num(b)}.', 'When dividing by a negative number, the inequality sign flips.' if a < 0 else f'Divide both sides by {format_num(a)}.', f'Solution: x {sign} {format_num(xval)}.']
    return f'x {sign} {format_num(xval)}', steps


def solve_two_variable(text: str) -> tuple[str, list[str]]:
    pieces = [p.strip() for p in re.split(r'[;\n]+', text) if '=' in p]
    if len(pieces) < 2:
        raise ValueError('Need two equations')
    def parse_side(s: str):
        s = s.replace(' ', '').replace('-', '+-')
        if s.startswith('+-'):
            s = s[1:]
        ax = by = const = 0.0
        for term in [t for t in s.split('+') if t]:
            if 'x' in term:
                coef = term.replace('x', '')
                ax += 1.0 if coef in ('', '+') else -1.0 if coef == '-' else float(coef)
            elif 'y' in term:
                coef = term.replace('y', '')
                by += 1.0 if coef in ('', '+') else -1.0 if coef == '-' else float(coef)
            else:
                const += float(term)
        return ax, by, const
    def coeffs(eq: str):
        left, right = [s.strip() for s in eq.split('=')]
        a1, b1, c1 = parse_side(left)
        a2, b2, c2 = parse_side(right)
        return a1 - a2, b1 - b2, c2 - c1
    a1, b1, c1 = coeffs(pieces[0]); a2, b2, c2 = coeffs(pieces[1])
    det = a1 * b2 - a2 * b1
    x = (c1 * b2 - c2 * b1) / det
    y = (a1 * c2 - a2 * c1) / det
    steps = [f'Write the equations clearly:\n1) {pieces[0]}\n2) {pieces[1]}', 'Use elimination / determinant method.', f'Determinant = {format_num(det)}.', f'x = ({format_num(c1)}×{format_num(b2)} - {format_num(c2)}×{format_num(b1)}) / {format_num(det)} = {format_num(x)}.', f'y = ({format_num(a1)}×{format_num(c2)} - {format_num(a2)}×{format_num(c1)}) / {format_num(det)} = {format_num(y)}.']
    return f'x = {format_num(x)}, y = {format_num(y)}', steps


def solve_quadratic(expr: str) -> tuple[str, list[str]]:
    expr = normalize(expr)
    left, right = [s.strip() for s in expr.split('=')]
    poly = parse_polynomial(f'{left}-({right})'.replace('(', '').replace(')', ''))
    a = poly.get(2, 0.0); b = poly.get(1, 0.0); c = poly.get(0, 0.0)
    if abs(a) < 1e-9:
        raise ValueError('This is not a quadratic equation')
    disc = b * b - 4 * a * c
    if disc < 0:
        raise ValueError('Complex roots not supported in this build')
    roots = sorted([(-b + math.sqrt(disc)) / (2 * a), (-b - math.sqrt(disc)) / (2 * a)])
    steps = [
        f'First write the equation in standard form ax² + bx + c = 0.',
        f'Here a = {format_num(a)}, b = {format_num(b)}, c = {format_num(c)}.',
        'Use the quadratic formula: x = (-b ± √(b² - 4ac)) / 2a.',
        f'Find the discriminant: b² - 4ac = ({format_num(b)})² - 4×{format_num(a)}×{format_num(c)} = {format_num(disc)}.',
        f'Substitute into the formula to get the two roots.',
        f'x₁ = {format_num(roots[0])} and x₂ = {format_num(roots[1])}.',
        f'Therefore, the solutions are {format_num(roots[0])} and {format_num(roots[1])}.'
    ]
    return ', '.join(format_num(r) for r in roots), steps


def derivative_poly(expr: str) -> tuple[str, list[str]]:
    poly = parse_polynomial(expr)
    steps = [f'Identify the polynomial: {poly_to_str(poly)}.']
    out: dict[int, float] = {}
    for p, c in sorted(poly.items(), reverse=True):
        if p == 0:
            steps.append(f'The derivative of constant {format_num(c)} is 0.')
            continue
        new_c = c * p
        new_p = p - 1
        out[new_p] = out.get(new_p, 0.0) + new_c
        if new_p == 0:
            steps.append(f'd/dx({format_num(c)}x^{p}) = {format_num(c)}×{p} = {format_num(new_c)}.')
        else:
            steps.append(f'd/dx({format_num(c)}x^{p}) = {format_num(c)}×{p}x^{new_p} = {format_num(new_c)}x^{new_p}.')
    result = poly_to_str(out)
    steps.append(f'Combine all differentiated terms: {result}.')
    return result, steps


def integral_poly(expr: str) -> tuple[str, list[str]]:
    poly = parse_polynomial(expr)
    steps = [f'Identify the polynomial: {poly_to_str(poly)}.']
    pieces = []
    for p, c in sorted(poly.items(), reverse=True):
        new_p = p + 1
        frac = Fraction(c).limit_denominator() / new_p
        coeff_str = '' if frac == 1 and new_p != 0 else ('-' if frac == -1 and new_p != 0 else str(frac))
        if new_p == 0:
            term = str(frac)
        elif new_p == 1:
            term = ('x' if frac == 1 else '-x' if frac == -1 else f'{coeff_str}x')
        else:
            term = (f'x^{new_p}' if frac == 1 else f'-x^{new_p}' if frac == -1 else f'{coeff_str}x^{new_p}')
        pieces.append(term)
        coeff_disp = str(frac) if frac.denominator != 1 else format_num(float(frac))
        steps.append(f'∫ {format_num(c)}x^{p} dx = {coeff_disp}x^{new_p}.')
    result = ' + '.join(pieces).replace('+ -', '- ') + ' + C'
    steps.append(f'Combine all integrated terms and add the constant of integration: {result}.')
    return result, steps


def derivative_from_question(question: str):
    q = normalize(question)
    q = re.sub(r'(?i)^\s*(differentiate|derivative of)\s*', '', q)
    q = re.sub(r'(?i)^\s*d/dx\s*', '', q)
    q = q.strip()
    if q.startswith('(') and q.endswith(')'):
        q = q[1:-1]
    return derivative_poly(q)


def integral_from_question(question: str):
    q = normalize(question)
    q = q.replace('∫', '').replace(' dx', '').replace('dx', '')
    q = re.sub(r'(?i)^\s*(integrate|integral of)\s*', '', q).strip()
    if q.startswith('(') and q.endswith(')'):
        q = q[1:-1]
    return integral_poly(q)


def separable_de(question: str):
    m = re.search(r'dy/dx\s*=\s*(-?\d*(?:\.\d+)?)x', question.replace(' ', '').lower())
    if not m:
        raise ValueError('Use form dy/dx = kx')
    g=m.group(1); k = float(g) if g not in ('', '+', '-') else (-1.0 if g=='-' else 1.0)
    coeff = Fraction(k).limit_denominator() / 2
    coeff_str = '' if coeff == 1 else '-' if coeff == -1 else (str(coeff) if coeff.denominator != 1 else format_num(float(coeff)))
    ans = f'y = {coeff_str}x^2 + C' if coeff_str not in ('','-') else (f'y = x^2 + C' if coeff_str=='' else 'y = -x^2 + C')
    pretty = (str(coeff) if coeff.denominator != 1 else format_num(float(coeff)))
    steps = [f'Given dy/dx = {format_num(k)}x.', f'Integrate both sides with respect to x.', f'y = ∫ {format_num(k)}x dx = {pretty}x^2 + C.']
    return ans, steps


def midpoint(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    x1, y1, x2, y2 = nums[:4]
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
    steps = ['Use midpoint formula ((x1+x2)/2, (y1+y2)/2).', f'(({format_num(x1)}+{format_num(x2)})/2, ({format_num(y1)}+{format_num(y2)})/2)', f'Midpoint = ({format_num(mx)}, {format_num(my)}).']
    return f'({format_num(mx)}, {format_num(my)})', steps


def distance(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    x1, y1, x2, y2 = nums[:4]
    dx, dy = x2 - x1, y2 - y1
    sq = dx * dx + dy * dy
    simplified = simplify_sqrt_float(sq)
    steps = ['Use distance formula √((x2-x1)^2 + (y2-y1)^2).', f'√(({format_num(x2)}-{format_num(x1)})^2 + ({format_num(y2)}-{format_num(y1)})^2)', f'= √({format_num(dx*dx)} + {format_num(dy*dy)}) = √{format_num(sq)}', f'Distance = {simplified}.']
    return simplified, steps


def distance_3d(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    x1, y1, z1, x2, y2, z2 = nums[:6]
    dx, dy, dz = x2-x1, y2-y1, z2-z1
    sq = dx*dx + dy*dy + dz*dz
    simplified = simplify_sqrt_float(sq)
    steps = [
        f'The two points are ({format_num(x1)}, {format_num(y1)}, {format_num(z1)}) and ({format_num(x2)}, {format_num(y2)}, {format_num(z2)}).',
        'Use the 3D distance formula √((x2-x1)² + (y2-y1)² + (z2-z1)²).',
        f'Find the coordinate differences: x-difference = {format_num(dx)}, y-difference = {format_num(dy)}, z-difference = {format_num(dz)}.',
        f'Square each difference: {format_num(dx)}² = {format_num(dx*dx)}, {format_num(dy)}² = {format_num(dy*dy)}, {format_num(dz)}² = {format_num(dz*dz)}.',
        f'Add them: {format_num(dx*dx)} + {format_num(dy*dy)} + {format_num(dz*dz)} = {format_num(sq)}.',
        f'Take the square root: distance = √{format_num(sq)} = {simplified}.',
    ]
    return simplified, steps


def slope(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    x1, y1, x2, y2 = nums[:4]
    m = (y2 - y1) / (x2 - x1)
    steps = ['Use slope formula (y2-y1)/(x2-x1).', f'({format_num(y2)}-{format_num(y1)}) / ({format_num(x2)}-{format_num(x1)})', f'Slope = {format_num(m)}.']
    return format_num(m), steps


def line_equation(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    x1, y1, x2, y2 = nums[:4]
    m = (y2 - y1) / (x2 - x1)
    c = y1 - m * x1
    steps = ['Find slope first using (y2-y1)/(x2-x1).', f'Slope m = {format_num(m)}.', f'Use y = mx + c with point ({format_num(x1)}, {format_num(y1)}).', f'{format_num(y1)} = {format_num(m)}×{format_num(x1)} + c, so c = {format_num(c)}.', f'Equation: y = {format_num(m)}x + {format_num(c)}.']
    return f'y = {format_num(m)}x + {format_num(c)}', steps


def heron_area(question: str):
    a, b, c = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))[:3]
    s = (a+b+c)/2
    under = s*(s-a)*(s-b)*(s-c)
    simplified = simplify_sqrt_float(under)
    steps = [f'Semi-perimeter s = ({format_num(a)}+{format_num(b)}+{format_num(c)})/2 = {format_num(s)}.', "Use Heron's formula √(s(s-a)(s-b)(s-c)).", f'Area = √{format_num(under)} = {simplified}.']
    return simplified, steps


def basic_stats(question: str, mode: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    if not nums:
        raise ValueError('No data found')
    steps = [f'Data set: {", ".join(format_num(n) for n in nums)}.']
    if mode == 'mean':
        s = sum(nums); ans = s / len(nums)
        steps += [f'Sum = {format_num(s)}.', f'Mean = Sum / Count = {format_num(s)} / {len(nums)} = {format_num(ans)}.']
    elif mode == 'median':
        arr = sorted(nums); n = len(arr)
        steps.append(f'Sort the data: {", ".join(format_num(n) for n in arr)}.')
        if n % 2:
            ans = arr[n//2]; steps.append(f'Middle value = {format_num(ans)}.')
        else:
            ans = (arr[n//2-1] + arr[n//2]) / 2; steps.append(f'Median = average of middle two values = {format_num(ans)}.')
    else:
        freq = {n: nums.count(n) for n in set(nums)}; ans = max(freq, key=freq.get)
        steps.append('Count the frequency of each value.')
        steps.append(', '.join(f'{format_num(k)} occurs {v} times' for k, v in sorted(freq.items())))
        steps.append(f'Mode = {format_num(ans)} because it occurs most often.')
    return format_num(ans), steps


def basic_probability(question: str):
    nums = list(map(int, re.findall(r'\d+', question)))
    if len(nums) < 2:
        raise ValueError('Need favorable and total outcomes')
    fav, total = nums[0], nums[1]
    ans = Fraction(fav, total)
    steps = ['Probability = favorable outcomes / total outcomes.', f'= {fav}/{total} = {ans}.']
    return str(ans), steps


def ap(question: str):
    nums = {k: float(v) for k, v in re.findall(r'\b([adn])\s*=\s*(-?\d+(?:\.\d+)?)', question.lower())}
    if {'a', 'd', 'n'}.issubset(nums):
        a, d, n = nums['a'], nums['d'], nums['n']
        nth = a + (n - 1) * d
        s = n / 2 * (2 * a + (n - 1) * d)
        steps = [f'First term a = {format_num(a)}, common difference d = {format_num(d)}, n = {format_num(n)}.', f'nth term = a + (n-1)d = {format_num(nth)}.', f'Sum of first n terms = n/2 [2a + (n-1)d] = {format_num(s)}.']
        return f'nth term = {format_num(nth)}, sum = {format_num(s)}', steps
    seq = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    if len(seq) >= 3:
        diffs = [seq[i+1] - seq[i] for i in range(len(seq)-1)]
        if all(abs(d - diffs[0]) < 1e-9 for d in diffs):
            expr = nth_term_from_sequence(seq)
            d = diffs[0]
            a = seq[0]
            steps = [f'The sequence is {", ".join(format_num(x) for x in seq)}.', f'Common difference d = {format_num(d)}.', f'nth term = a + (n-1)d = {format_num(a)} + (n-1)×{format_num(d)}.', expr + '.']
            return expr, steps
    raise ValueError('Use a=, d=, n= format or provide at least three AP terms')

def gp(question: str):
    vals = {k: float(v) for k, v in re.findall(r'\b([arn])\s*=\s*(-?\d+(?:\.\d+)?)', question.lower())}
    if not {'a', 'r', 'n'}.issubset(vals):
        raise ValueError('Use a=, r=, n= format for GP')
    a, r, n = vals['a'], vals['r'], vals['n']
    nth = a * (r ** (n-1))
    s = a * ((r ** n) - 1) / (r - 1) if abs(r - 1) > 1e-9 else a * n
    steps = [f'First term a = {format_num(a)}, common ratio r = {format_num(r)}, n = {format_num(n)}.', f'nth term = ar^(n-1) = {format_num(nth)}.', f'Sum of first n terms = {format_num(s)}.']
    return f'nth term = {format_num(nth)}, sum = {format_num(s)}', steps


def trig(question: str):
    q = question.lower().replace(' ', '')
    if 'identity' in q or ('sin**2' in q and 'cos**2' in q) or ('sin2' in q and 'cos2' in q):
        return 'sin²θ + cos²θ = 1', ['Use the fundamental trigonometric identity.', 'sin²θ + cos²θ = 1.']
    m = re.search(r'(sin|cos|tan)(\d+)', q)
    if not m:
        raise ValueError('Unsupported trigonometry format')
    fn, ang = m.group(1), int(m.group(2))
    values = {('sin',0):0, ('sin',30):0.5, ('sin',45):math.sqrt(2)/2, ('sin',60):math.sqrt(3)/2, ('sin',90):1, ('cos',0):1, ('cos',30):math.sqrt(3)/2, ('cos',45):math.sqrt(2)/2, ('cos',60):0.5, ('cos',90):0, ('tan',0):0, ('tan',30):1/math.sqrt(3), ('tan',45):1, ('tan',60):math.sqrt(3)}
    ans = values[(fn, ang)]
    steps = ['Use the standard trigonometric value table.', f'{fn} {ang}° = {format_num(ans)}.']
    return format_num(ans), steps


def inverse_trig(question: str):
    q = question.lower().replace(' ', '')
    if 'sininverse1/2' in q or 'sin-11/2' in q or 'sin^-1(1/2)' in q:
        return '30°', ['Use the standard inverse trigonometric value.', 'sin⁻¹(1/2) = 30°.']
    if 'cosinverse1/2' in q or 'cos-11/2' in q or 'cos^-1(1/2)' in q:
        return '60°', ['Use the standard inverse trigonometric value.', 'cos⁻¹(1/2) = 60°.']
    if 'taninverse1' in q or 'tan-11' in q or 'tan^-1(1)' in q:
        return '45°', ['Use the standard inverse trigonometric value.', 'tan⁻¹(1) = 45°.']
    raise ValueError('Unsupported inverse trigonometric format')


def determinant_2x2(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    a, b, c, d = nums[:4]
    ans = a * d - b * c
    steps = ['Determinant of [[a,b],[c,d]] = ad - bc.', f'{format_num(a)}×{format_num(d)} - {format_num(b)}×{format_num(c)} = {format_num(ans)}.']
    return format_num(ans), steps


def inverse_2x2(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    a, b, c, d = nums[:4]
    det = a * d - b * c
    inv = [[d/det, -b/det], [-c/det, a/det]]
    steps = ['For [[a,b],[c,d]], inverse = 1/(ad-bc) × [[d,-b],[-c,a]].', f'Determinant = {format_num(det)}.', f'Inverse = [[{format_num(inv[0][0])}, {format_num(inv[0][1])}], [{format_num(inv[1][0])}, {format_num(inv[1][1])}]].']
    return f'[[{format_num(inv[0][0])}, {format_num(inv[0][1])}], [{format_num(inv[1][0])}, {format_num(inv[1][1])}]]', steps


def ncr(question: str):
    m = re.search(r'n\s*=\s*(\d+)\s*,?\s*r\s*=\s*(\d+)', question.lower()) or re.search(r'(\d+)\s*c\s*(\d+)', question.lower())
    if not m:
        raise ValueError('Use n= and r= or direct form like 5C2')
    n, r = map(int, m.groups())
    ans = math.comb(n, r)
    steps = ['Use nCr = n! / (r!(n-r)!).', f'{n}C{r} = {ans}.']
    return str(ans), steps


def npr(question: str):
    m = re.search(r'n\s*=\s*(\d+)\s*,?\s*r\s*=\s*(\d+)', question.lower()) or re.search(r'(\d+)\s*p\s*(\d+)', question.lower())
    if not m:
        raise ValueError('Use n= and r= or direct form like 5P2')
    n, r = map(int, m.groups())
    ans = math.perm(n, r)
    steps = ['Use nPr = n! / (n-r)!.', f'{n}P{r} = {ans}.']
    return str(ans), steps


def binomial_expand(question: str):
    m = re.search(r'\((x)([+-]\d+)\)\*\*(\d+)', normalize(question).replace(' ', ''))
    if not m:
        raise ValueError('Use format like (x+1)**2')
    signnum, n = int(m.group(2)), int(m.group(3))
    if n > 3:
        raise ValueError('Current build expands power up to 3 in direct mode')
    c = signnum
    if n == 2:
        expr = f'x^2 {"+" if 2*c>=0 else "-"} {abs(2*c)}x {"+" if c*c>=0 else "-"} {abs(c*c)}'
    else:
        expr = f'x^3 {"+" if 3*c>=0 else "-"} {abs(3*c)}x^2 {"+" if 3*c*c>=0 else "-"} {abs(3*c*c)}x {"+" if c**3>=0 else "-"} {abs(c**3)}'
    steps = ['Use the binomial theorem for small powers.', f'Expansion = {expr}.']
    return expr, steps


def vector_angle_2d(question: str):
    q = normalize(question).lower().replace(' ', '')
    if 'i+j' in q and 'i-j' in q:
        return '90°', ['Take vectors a = (1,1) and b = (1,-1).', 'Dot product a·b = 1×1 + 1×(-1) = 0.', 'If dot product is 0, the vectors are perpendicular.', 'Angle = 90°.']
    raise ValueError('Unsupported vector-angle format')


def dot_product(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    a, b, c, d, e, f = nums[:6]
    ans = a * d + b * e + c * f
    steps = ['Dot product = a1a2 + b1b2 + c1c2.', f'= {format_num(a)}×{format_num(d)} + {format_num(b)}×{format_num(e)} + {format_num(c)}×{format_num(f)} = {format_num(ans)}.']
    return format_num(ans), steps


def complex_modulus(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    a, b = nums[:2]
    ans = math.sqrt(a*a + b*b)
    steps = [f'For z = {format_num(a)} + {format_num(b)}i, |z| = √(a²+b²).', f'|z| = √({format_num(a*a)} + {format_num(b*b)}) = {format_num(ans)}.']
    return format_num(ans), steps


def limit_poly(question: str):
    q = normalize(question).lower().replace('→', '->')
    if 'sinx/x' in q.replace(' ', '') and ('x->0' in q.replace(' ', '') or 'x-0' in q.replace(' ', '')):
        return '1', ['Use the standard trigonometric limit.', 'lim (x→0) (sin x / x) = 1.']
    m = re.search(r'limit\s*x\s*[-=]*>\s*(-?\d+(?:\.\d+)?)\s*of\s*(.+)', q)
    if not m:
        m = re.search(r'lim\s*\(?x\s*[-=]*>\s*(-?\d+(?:\.\d+)?)\)?\s*(.+)', q)
    if not m:
        raise ValueError('Use format like limit x->2 of x**2+1')
    a = float(m.group(1))
    expr = normalize(m.group(2))
    expr = expr.replace('x', f'({a})')
    ans = safe_eval(expr)
    steps = [f'For a direct-substitution case, substitute x = {format_num(a)}.', f'Value = {format_num(ans)}.']
    return format_num(ans), steps

def linear_programming_concept(question: str):
    q = normalize(question).lower()
    m = re.search(r'z\s*=\s*([+-]?\d+(?:\.\d+)?)x\s*([+-])\s*(\d+(?:\.\d+)?)y', q)
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', q)))
    if m and len(nums) >= 4 and 'for' in q:
        a = float(m.group(1)); sign = m.group(2); b = float(m.group(3)); b = b if sign == '+' else -b
        x, y = nums[-2], nums[-1]
        z = a*x + b*y
        steps = ['Substitute the given point into the objective function.', f'Z = {format_num(a)}({format_num(x)}) + {format_num(b)}({format_num(y)}) = {format_num(z)}.']
        return format_num(z), steps
    return 'Linear programming optimizes a linear objective function subject to linear constraints.', ['Identify the objective function Z = ax + by.', 'List the constraints and feasible region.', 'Check corner points to find the optimum.']


def concept_answer(question: str):
    q = question.lower()
    mapping = {
        'relation': 'A relation is a set of ordered pairs connecting elements of one set with elements of another set.',
        'function': 'A function is a relation in which each input has exactly one output.',
        'set': 'A set is a well-defined collection of objects.',
        'continuity': 'A function is continuous at a point when the left limit, right limit, and function value are equal there.',
        'conic': 'Conic sections are curves obtained by slicing a cone: circle, parabola, ellipse, and hyperbola.',
        'linear programming': 'Linear programming is a method to maximize or minimize a linear objective under linear constraints.',
        'euclid': 'Euclid geometry studies points, lines, and shapes using axioms and logical deductions.',
    }
    for k, v in mapping.items():
        if k in q:
            return v, [v]
    return 'This is a concept question. The current build answers common definitions and formula-based concepts for the selected topic.', ['Concept-answer mode was triggered from topic routing.']




def measurement_money_time(question: str):
    q = normalize(question).lower()
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', q)))
    if 'hour' in q and 'minute' in q and nums:
        if 'into minutes' in q or 'hours into minutes' in q or ('convert' in q and 'hour' in q):
            ans = nums[0] * 60
            return format_num(ans), ['1 hour = 60 minutes.', f'{format_num(nums[0])} × 60 = {format_num(ans)} minutes.']
    if 'minute' in q and 'hour' in q and nums:
        ans = nums[0] / 60
        return format_num(ans), ['1 hour = 60 minutes.', f'{format_num(nums[0])} ÷ 60 = {format_num(ans)} hours.']
    if 'rupee' in q and ('quantity' in q or 'costs' in q or 'each' in q) and len(nums) >= 2:
        ans = nums[0] * nums[1]
        return format_num(ans), ['Total cost = cost per item × quantity.', f'{format_num(nums[0])} × {format_num(nums[1])} = {format_num(ans)} rupees.']
    if 'cm to m' in q and nums:
        ans = nums[0] / 100
        return format_num(ans), ['1 metre = 100 centimetres.', f'{format_num(nums[0])} ÷ 100 = {format_num(ans)} m.']
    if 'm to cm' in q and nums:
        ans = nums[0] * 100
        return format_num(ans), ['1 metre = 100 centimetres.', f'{format_num(nums[0])} × 100 = {format_num(ans)} cm.']
    raise ValueError('Unsupported time, money, or measurement format')


def integer_rational(question: str):
    q = normalize(question).lower()
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', q)))
    if ('square root' in q or '√' in question or 'sqrt' in q) and nums:
        n = nums[0]
        ans = math.sqrt(n)
        root_str = simplify_sqrt_float(n) if abs(ans-round(ans))>1e-9 else format_num(ans)
        return format_num(ans), [f'Square root means a number whose square is {format_num(n)}.', f'√{format_num(n)} = {root_str}.']
    if 'cube root' in q and nums:
        n = nums[0]
        ans = round(n ** (1/3), 10)
        return format_num(ans), [f'Cube root means a number whose cube is {format_num(n)}.', f'∛{format_num(n)} = {format_num(ans)}.']
    if '/' in q or 'rational' in q:
        return 'A rational number can be written in the form p/q where q ≠ 0.', ['Integers, fractions, and terminating or repeating decimals are rational numbers.']
    raise ValueError('Unsupported integers/rational numbers format')


def identities(question: str):
    q = normalize(question).replace(' ', '').lower()
    if q.startswith('expand(a+b)') or '(a+b)**2' in q or '(a+b)^2' in question.replace(' ', ''):
        return 'a^2 + 2ab + b^2', ['Use identity (a+b)^2 = a^2 + 2ab + b^2.']
    if q.startswith('expand(a-b)') or '(a-b)**2' in q or '(a-b)^2' in question.replace(' ', ''):
        return 'a^2 - 2ab + b^2', ['Use identity (a-b)^2 = a^2 - 2ab + b^2.']
    if '(a+b)(a-b)' in q or '(a+b)*(a-b)' in q:
        return 'a^2 - b^2', ['Use identity (a+b)(a-b) = a^2 - b^2.']
    if 'stateidentity' in q or q == 'stateidentity':
        return 'sin²θ + cos²θ = 1', ['Use the standard trigonometric identity.', 'sin²θ + cos²θ = 1.']
    raise ValueError('Unsupported algebraic identity format')


def circle_triangle_geometry(question: str):
    q = normalize(question).lower()
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', q)))
    if 'area of circle' in q and nums:
        r = nums[0]; ans = math.pi * r * r
        return format_num(ans), ['Area of circle = πr².', f'π × {format_num(r)}² = {format_num(ans)}.']
    if ('circumference' in q or 'perimeter of circle' in q) and nums:
        r = nums[0]; ans = 2 * math.pi * r
        return format_num(ans), ['Circumference = 2πr.', f'2 × π × {format_num(r)} = {format_num(ans)}.']
    if 'pythagoras' in q and len(nums) >= 2:
        a, b = nums[:2]; c = math.sqrt(a*a + b*b)
        return format_num(c), ['Use Pythagoras theorem c² = a² + b².', f'c = √({format_num(a)}² + {format_num(b)}²) = {format_num(c)}.']
    if ('heron' in q or ('area of triangle' in q and len(nums) >= 3)) and len(nums) >= 3:
        return heron_area(q)
    raise ValueError('Unsupported triangle/circle geometry format')


def heights_distances(question: str):
    q = normalize(question).lower()
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', q)))
    if 'tan' in q and len(nums) >= 2:
        angle, base = nums[0], nums[1]
        values = {30: 1/math.sqrt(3), 45: 1, 60: math.sqrt(3)}
        if angle not in values:
            raise ValueError('Supported standard angles are 30, 45, and 60 degrees')
        h = values[angle] * base
        return format_num(h), ['Use tan θ = opposite / adjacent.', f'Height = tan {int(angle)}° × {format_num(base)} = {format_num(h)}.']
    raise ValueError('Unsupported heights and distances format')


def number_systems(question: str):
    q = normalize(question).lower()
    nums = list(map(int, re.findall(r'-?\d+', q)))
    if 'prime' in q and nums:
        n = nums[0]
        if n < 2:
            return 'No', [f'{n} is not prime because prime numbers are greater than 1.']
        for i in range(2, int(math.sqrt(n)) + 1):
            if n % i == 0:
                return 'No', [f'{n} is divisible by {i}, so it is not prime.']
        return 'Yes', [f'No integer from 2 to √{n} divides {n}. So it is prime.']
    if ('hcf' in q or 'lcm' in q) and len(nums) >= 2:
        return factors_multiples(q)
    raise ValueError('Unsupported number systems format')


def polynomial_ops(question: str):
    q = normalize(question).lower()
    m = re.search(r'(.+) for x\s*=\s*(-?\d+(?:\.\d+)?)', q)
    if m:
        expr, xval = m.group(1), float(m.group(2))
        expr = expr.replace('x', f'({xval})')
        ans = safe_eval(expr)
        return format_num(ans), [f'Substitute x = {format_num(xval)} into the expression.', f'Value = {format_num(ans)}.']
    raise ValueError('Unsupported polynomial format')

def infer_topic_from_hint(topic_hint: str | None):
    if not topic_hint:
        return None
    aliases = {
        'school_numbers_counting': 'school_numbers_counting',
        'school_arithmetic': 'school_arithmetic',
        'school_shapes_geometry_basic': 'school_shapes_geometry_basic',
        'school_time_calendar_money_measurement': 'school_time_calendar_money_measurement',
        'school_patterns': 'school_patterns',
        'school_factors_multiples': 'school_factors_multiples',
        'school_fractions_decimals': 'school_fractions_decimals',
        'school_percentage': 'school_percentage',
        'school_ratio_proportion': 'school_ratio_proportion',
        'school_integers_rational': 'school_integers_rational',
        'school_algebraic_expressions_identities': 'school_algebraic_expressions_identities',
        'school_linear_equations': 'school_linear_equations',
        'school_linear_equations_two_variables': 'school_linear_equations_two_variables',
        'school_quadratic_equations': 'school_quadratic_equations',
        'school_ap': 'school_ap',
        'school_coordinate_geometry': 'school_coordinate_geometry',
        'school_triangles_circles_geometry': 'school_triangles_circles_geometry',
        'school_mensuration': 'school_mensuration',
        'school_statistics': 'school_statistics',
        'school_probability': 'school_probability',
        'school_trigonometry': 'school_trigonometry',
        'intermediate_sets_relations_functions': 'intermediate_sets_relations_functions',
        'intermediate_trig_functions_identities': 'intermediate_trig_functions_identities',
        'intermediate_complex_numbers': 'intermediate_complex_numbers',
        'intermediate_quadratic_inequalities': 'intermediate_quadratic_inequalities',
        'intermediate_sequences_series': 'intermediate_sequences_series',
        'intermediate_permutations_combinations': 'intermediate_permutations_combinations',
        'intermediate_binomial': 'intermediate_binomial',
        'intermediate_straight_lines_conics': 'intermediate_straight_lines_conics',
        'intermediate_limits_continuity': 'intermediate_limits_continuity',
        'intermediate_differentiation': 'intermediate_differentiation',
        'intermediate_integration': 'intermediate_integration',
        'intermediate_differential_equations': 'intermediate_differential_equations',
        'intermediate_matrices': 'intermediate_matrices',
        'intermediate_vectors_3d': 'intermediate_vectors_3d',
        'intermediate_linear_programming': 'intermediate_linear_programming',
        'intermediate_probability': 'intermediate_probability',
    }
    return aliases.get(topic_hint, topic_hint)


def classify_by_pattern(question: str, topic_hint: str | None = None) -> tuple[str, str, str, Callable[[str], tuple[str, list[str]]]]:
    q = normalize(question)
    ql = q.lower()
    hint = infer_topic_from_hint(topic_hint)
    # normalize high-priority detections
    if hint == 'intermediate_sequences_series' and ('next term' in ql or 'next number' in ql or 'find next' in ql or len(re.findall(r'-?\d+(?:\.\d+)?', ql)) >= 3):
        return hint, 'sequence_series', 'text', sequences_series_solver
    if hint == 'intermediate_probability' or ('probability' in ql and any(k in ql for k in ['coin','dice','die','card','favorable','total'])):
        return (hint or 'school_probability'), 'probability', 'fraction', probability_extended
    # explicit topic-hint routes first
    if hint == 'school_time_calendar_money_measurement':
        return hint, 'time_money_measurement', 'number', measurement_money_time
    if hint == 'school_integers_rational':
        return hint, 'integers_rational', 'number', integer_rational
    if hint == 'school_algebraic_expressions_identities' and re.search(r'[0-9][*]{0,2}[0-9]', ql):
        return hint, 'numeric_exponent', 'number', evaluate_numeric_power
    if hint == 'school_algebraic_expressions_identities':
        return hint, 'identity', 'expression', identities
    if hint == 'school_triangles_circles_geometry' and 'height' in ql:
        return hint, 'heights_distances', 'number', heights_distances
    if hint == 'school_triangles_circles_geometry':
        return hint, 'circle_triangle_geometry', 'number', circle_triangle_geometry
    if hint == 'school_shapes_geometry_basic':
        return hint, 'concept', 'text', concept_answer
    if hint == 'intermediate_differentiation':
        return hint, 'differentiate', 'expression', derivative_from_question
    if hint == 'intermediate_integration':
        return hint, 'integrate', 'expression', integral_from_question
    if hint == 'school_linear_equations':
        return hint, 'linear_equation', 'number', solve_linear
    if hint == 'school_quadratic_equations':
        return hint, 'quadratic', 'number_pair', solve_quadratic
    if hint == 'school_ap':
        return hint, 'ap', 'text', ap
    if hint == 'school_coordinate_geometry' and any(k in ql for k in ['midpoint','mid point']):
        return hint, 'midpoint', 'point', midpoint
    if hint == 'school_coordinate_geometry' and 'distance' in ql:
        return hint, 'distance', 'number', distance
    if hint == 'school_coordinate_geometry' and 'slope' in ql:
        return hint, 'slope', 'number', slope
    if hint == 'school_statistics' and 'mean' not in ql and 'median' not in ql and 'mode' not in ql:
        return hint, 'mean', 'number', lambda s: basic_stats(s, 'mean')
    if hint == 'school_mensuration':
        return hint, 'mensuration', 'number', mensuration
    if hint == 'school_trigonometry':
        return hint, 'trigonometry', 'number', trig
    if hint == 'intermediate_matrices' and 'inverse' in ql:
        return hint, 'inverse_matrix', 'matrix', inverse_2x2
    if hint == 'intermediate_matrices':
        return hint, 'determinant', 'number', determinant_2x2
    if hint == 'intermediate_vectors_3d' and 'angle' in ql:
        return hint, 'vector_angle', 'text', vector_angle_2d
    if hint == 'intermediate_vectors_3d' and 'dot' in ql:
        return hint, 'dot_product', 'number', dot_product
    if hint == 'intermediate_vectors_3d' and any(k in ql for k in ['magnitude', 'modulus', '|', 'length of vector']):
        return hint, 'vector_magnitude', 'number', vector_magnitude
    if hint == 'intermediate_vectors_3d' and ('distance' in ql and ql.count(',') >= 5):
        return hint, 'distance_3d', 'number', distance_3d
    if hint == 'intermediate_vectors_3d' and ('distance' in ql or ql.count(',') >= 5):
        return hint, 'distance_3d', 'number', distance_3d
    if hint == 'intermediate_probability' and 'ncr' in ql:
        return hint, 'combination', 'number', ncr
    if hint == 'intermediate_permutations_combinations' and 'npr' in ql:
        return hint, 'permutation', 'number', npr
    if hint == 'intermediate_permutations_combinations':
        return hint, 'combination', 'number', ncr
    if hint == 'intermediate_sequences_series' and 'r=' in ql:
        return hint, 'gp', 'text', gp
    if hint == 'intermediate_sequences_series':
        return hint, 'sequence_series', 'text', sequences_series_solver
    if hint == 'intermediate_limits_continuity' and 'limit' in ql:
        return hint, 'limit', 'number', limit_poly
    if hint == 'intermediate_differential_equations':
        return hint, 'differential_equation', 'expression', separable_de
    if hint == 'intermediate_linear_programming':
        return hint, 'concept', 'text', linear_programming_concept
    if hint == 'intermediate_complex_numbers' and ('i' in ql and ('^' in ql or '**' in ql or re.fullmatch(r'i\d+', ql) or ql in {'i','+i'})):
        return hint, 'complex_power', 'text', complex_basic
    if hint == 'intermediate_complex_numbers' and ('|' in ql or 'modulus' in ql):
        return hint, 'modulus', 'number', complex_modulus
    if hint == 'intermediate_binomial':
        return hint, 'binomial_expand', 'expression', binomial_expand
    if hint == 'intermediate_straight_lines_conics' and 'equation of line' in ql:
        return hint, 'line_equation', 'expression', line_equation
    if hint == 'school_numbers_counting' and any(k in ql for k in ['before', 'after', 'previous', 'next']):
        return hint, 'before_after', 'number', before_after
    if hint == 'school_patterns':
        return hint, 'pattern', 'number', pattern_next
    if hint == 'school_factors_multiples':
        return hint, 'hcf_lcm', 'number', factors_multiples
    if hint == 'school_fractions_decimals' and ' of ' in ql and '/' in ql:
        return hint, 'fraction_of', 'number', fraction_of
    if hint == 'school_fractions_decimals' and '/' in ql and any(op in ql for op in ['+', '-', '*', '/']):
        return hint, 'fraction_operation', 'fraction', fraction_op
    if hint == 'school_fractions_decimals':
        return hint, 'fraction_to_decimal', 'number', fraction_to_decimal
    if hint == 'school_percentage' and ('simple interest' in ql or re.search(r'\bsi\b', ql)):
        return hint, 'simple_interest', 'number', simple_interest_natural
    if hint == 'school_percentage':
        return hint, 'percentage', 'number', percentage
    if hint == 'school_ratio_proportion' and 'ratio of' in ql:
        return hint, 'ratio', 'text', ratio_simple
    if hint == 'school_ratio_proportion':
        return hint, 'proportion', 'number', ratio_proportion
    if hint == 'school_probability':
        return hint, 'probability', 'fraction', basic_probability
    if hint == 'school_triangles_circles_geometry' and 'heron' in ql:
        return hint, 'heron', 'number', heron_area

    if hint == 'intermediate_complex_numbers':
        return hint, 'complex_number', 'text', complex_basic
    if hint == 'intermediate_vectors_3d' and 'magnitude' in ql:
        return hint, 'magnitude', 'number', vector_magnitude
    if hint == 'intermediate_vectors_3d' and ('distance between' in ql or '3d distance' in ql):
        return hint, 'distance_3d', 'number', distance_3d
    if hint == 'intermediate_probability':
        return hint, 'probability', 'fraction', probability_extended
    if hint == 'intermediate_sequences_series':
        return hint, 'sequence_series', 'text', sequences_series_solver
    # text-driven detection
    if 'simple interest' in ql or re.search(r'\bsi\b', ql):
        return 'school_percentage', 'simple_interest', 'number', simple_interest_natural
    if any(k in ql for k in ['altogether', 'total number', 'sum of', 'remain', 'left after', 'shared equally', 'each costs', 'cost of', 'in all', 'more', 'gets', 'bought', 'quantity']) and re.search(r'\d', ql):
        return 'school_arithmetic', 'word_problem', 'number', word_problem_solver
    if any(k in ql for k in ['before', 'after', 'previous', 'next']) and re.search(r'\d', ql):
        return 'school_numbers_counting', 'before_after', 'number', before_after
    if 'pattern' in ql and len(re.findall(r'\d+', ql)) >= 3:
        return 'school_patterns', 'pattern', 'number', pattern_next
    if 'hcf' in ql or 'lcm' in ql or 'greatest common factor' in ql or 'least common multiple' in ql:
        return 'school_factors_multiples', 'hcf_lcm', 'number', factors_multiples
    if 'differentiate' in ql or 'derivative' in ql or 'd/dx' in ql:
        return 'intermediate_differentiation', 'differentiate', 'expression', derivative_from_question
    if ql.startswith('integrate') or 'integral of' in ql or '∫' in question:
        return 'intermediate_integration', 'integrate', 'expression', integral_from_question
    if 'dy/dx' in ql:
        return 'intermediate_differential_equations', 'differential_equation', 'expression', separable_de
    if 'determinant' in ql or ('|' in question and ';' in question):
        return 'intermediate_matrices', 'determinant', 'number', determinant_2x2
    if 'inverse matrix' in ql or 'inverse of matrix' in ql:
        return 'intermediate_matrices', 'inverse_matrix', 'matrix', inverse_2x2
    if 'ncr' in ql or re.search(r'\d+\s*c\s*\d+', ql):
        return 'intermediate_permutations_combinations', 'combination', 'number', ncr
    if 'npr' in ql or re.search(r'\d+\s*p\s*\d+', ql):
        return 'intermediate_permutations_combinations', 'permutation', 'number', npr
    if 'angle between' in ql and 'i+j' in ql and 'i-j' in ql:
        return 'intermediate_vectors_3d', 'vector_angle', 'text', vector_angle_2d
    if 'magnitude' in ql:
        return 'intermediate_vectors_3d', 'magnitude', 'number', vector_magnitude
    if 'dot product' in ql:
        return 'intermediate_vectors_3d', 'dot_product', 'number', dot_product
    if ('modulus' in ql and 'i' in ql) or re.fullmatch(r'i(\*\*|\^)?\d+', ql.replace(' ', '')) or ql.strip() in {'i²','i2','i^2','i**2'}:
        return 'intermediate_complex_numbers', 'complex_number', 'text', complex_basic
    if 'inverse' in ql and ('sin' in ql or 'cos' in ql or 'tan' in ql):
        return 'intermediate_trig_functions_identities', 'inverse_trig', 'text', inverse_trig
    if ('maximize z' in ql or 'minimize z' in ql) and 'for' in ql:
        return 'intermediate_linear_programming', 'objective_value', 'number', linear_programming_concept
    if ('limit' in ql or 'lim' in ql) and ('x->' in ql or 'x→' in question or 'sin x / x' in ql):
        return 'intermediate_limits_continuity', 'limit', 'number', limit_poly
    if 'equation of line' in ql:
        return 'intermediate_straight_lines_conics', 'line_equation', 'expression', line_equation
    if 'binomial' in ql or re.search(r'\(x[+-]\d+\)\*\*\d+', ql.replace(' ', '')):
        return 'intermediate_binomial', 'binomial_expand', 'expression', binomial_expand
    if any(w in ql for w in ['midpoint', 'mid point']):
        return 'school_coordinate_geometry', 'midpoint', 'point', midpoint
    if 'distance between' in ql:
        return 'school_coordinate_geometry', 'distance', 'number', distance
    if (('arithmetic progression' in ql or 'ap' in ql or 'nth term' in ql) and len(re.findall(r'-?\d+(?:\.\d+)?', ql)) >= 3):
        return 'school_ap', 'ap', 'text', ap
    if "heron's formula" in ql or ('area of triangle' in ql and len(re.findall(r'-?\d+(?:\.\d+)?', ql)) == 3):
        return 'school_triangles_circles_geometry', 'heron', 'number', heron_area
    if 'surface area' in ql and 'sphere' in ql:
        return 'school_mensuration', 'mensuration', 'number', mensuration
    if 'distance between' in ql and ql.count(',') >= 4:
        return 'intermediate_vectors_3d', 'distance_3d', 'number', distance_3d
    if '3d distance' in ql:
        return 'intermediate_vectors_3d', 'distance_3d', 'number', distance_3d
    if 'slope' in ql:
        return 'school_coordinate_geometry', 'slope', 'number', slope
    if 'heron' in ql:
        return 'school_triangles_circles_geometry', 'heron', 'number', heron_area
    if 'mean' in ql:
        return 'school_statistics', 'mean', 'number', lambda s: basic_stats(s, 'mean')
    if 'median' in ql:
        return 'school_statistics', 'median', 'number', lambda s: basic_stats(s, 'median')
    if 'mode' in ql:
        return 'school_statistics', 'mode', 'number', lambda s: basic_stats(s, 'mode')
    if ' of ' in ql and '/' in ql:
        return 'school_fractions_decimals', 'fraction_of', 'number', fraction_of
    if re.search(r'\d+\/\d+\s*[+\-*/]\s*\d+\/\d+', ql):
        return 'school_fractions_decimals', 'fraction_operation', 'fraction', fraction_op
    if '%' in ql and 'of' in ql:
        return 'school_percentage', 'percentage', 'number', percentage
    if 'ratio of' in ql:
        return 'school_ratio_proportion', 'ratio', 'text', ratio_simple
    if ':' in ql and ('= ' in ql or ':x' in ql):
        return 'school_ratio_proportion', 'proportion', 'number', ratio_proportion
    if all(k in ql for k in ['a=', 'd=', 'n=']):
        return 'school_ap', 'ap', 'text', ap
    if all(k in ql for k in ['a=', 'r=', 'n=']):
        return 'intermediate_sequences_series', 'gp', 'text', gp
    if ('next term' in ql or 'sequence' in ql or 'series' in ql) and len(re.findall(r'-?\d+(?:\.\d+)?', ql)) >= 3:
        return 'intermediate_sequences_series', 'sequence_series', 'text', sequences_series_solver
    if 'probability' in ql:
        return (hint or 'school_probability'), 'probability', 'fraction', probability_extended
    if any(w in ql for w in ['area', 'perimeter', 'volume', 'circumference', 'surface area']):
        return 'school_mensuration', 'mensuration', 'number', mensuration
    if re.search(r'(?<![a-z])(sin|cos|tan)(?![a-z])', ql):
        return 'school_trigonometry', 'trigonometry', 'number', trig
    if any(op in ql for op in ['<', '>', '<=', '>=']) and 'x' in ql:
        return 'intermediate_quadratic_inequalities', 'inequality', 'text', solve_linear_inequality
    if q.count('=') >= 2 or len([p for p in re.split(r'[;\n,]+', q) if '=' in p]) >= 2:
        return 'school_linear_equations_two_variables', 'solve_system', 'text', solve_two_variable
    if 'x' in q and '=' in q and 'x**2' in q:
        return 'school_quadratic_equations', 'quadratic', 'number_pair', solve_quadratic
    if 'x' in q and '=' in q:
        return 'school_linear_equations', 'linear_equation', 'number', solve_linear
    if any(k in ql for k in ['hours into minutes', 'minutes into hours', 'costs', 'rupees', 'cm to m', 'm to cm']):
        return 'school_time_calendar_money_measurement', 'time_money_measurement', 'number', measurement_money_time
    if 'square root' in ql or 'cube root' in ql or '√' in question:
        return 'school_integers_rational', 'roots', 'number', integer_rational
    if 'prime' in ql:
        return 'school_numbers_counting', 'prime_check', 'text', number_systems
    if ql.startswith('expand (a + b)') or ql.startswith('expand (a+b)') or ql.startswith('expand (a - b)') or ql.startswith('expand (a-b)'):
        return 'school_algebraic_expressions_identities', 'identity', 'expression', identities
    if 'identity' in ql or '(a+b)**2' in ql or '(a-b)**2' in ql:
        return 'school_algebraic_expressions_identities', 'identity', 'expression', identities
    if 'height' in ql and 'tan' in ql:
        return 'school_triangles_circles_geometry', 'heights_distances', 'number', heights_distances
    if 'area of circle' in ql or 'circumference' in ql or 'pythagoras' in ql:
        return 'school_triangles_circles_geometry', 'circle_triangle_geometry', 'number', circle_triangle_geometry
    if re.search(r'[0-9]+\*\*[0-9]+', q) and all(ch not in q for ch in 'xy'):
        return 'school_arithmetic', 'arithmetic_power', 'number', evaluate_numeric_power
    if 'for x=' in ql:
        return 'school_quadratic_equations', 'polynomial_evaluate', 'number', polynomial_ops
    if ql in {'i','+i'} or re.fullmatch(r'i(\*\*|\^)?\d+', ql.replace(' ', '')):
        return 'intermediate_complex_numbers', 'complex_power', 'text', complex_basic
    if any(k in ql for k in ['magnitude of', 'modulus of']) and ql.count(',') >= 1:
        return 'intermediate_vectors_3d', 'vector_magnitude', 'number', vector_magnitude
    if ('distance between' in ql and ql.count(',') >= 5):
        return 'intermediate_vectors_3d', 'distance_3d', 'number', distance_3d
    if 'probability' in ql and any(k in ql for k in ['coin', 'dice', 'die', 'card', 'favorable', 'total', 'red', 'black', 'head', 'tail']):
        return 'school_probability', 'probability', 'fraction', probability_extended
    if any(k in ql for k in ['next term', 'next number', 'sequence']) and len(re.findall(r'-?\d+(?:\.\d+)?', ql)) >= 3:
        return 'intermediate_sequences_series', 'sequence_series', 'text', sequences_series_solver
    if re.search(r'^[0-9\s\+\-\*\/\(\)\.\%]+$', ql):
        return 'school_arithmetic', 'arithmetic', 'number', arithmetic_expr
    if any(k in ql for k in ['define', 'what is', 'meaning of', 'explain']):
        return hint or 'intermediate_sets_relations_functions', 'concept', 'text', concept_answer
    raise ValueError('The current custom solver could not match this question to a supported pattern.')



def word_problem_solver(question: str):
    q = normalize(question).lower()
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', q)))
    if not nums:
        raise ValueError('No quantities found in the word problem')
    if any(k in q for k in ['altogether', 'sum of', 'in all', 'total number', 'more', 'gets', 'bought more']) and len(nums) >= 2:
        ans = nums[0] + nums[1]
        return format_num(ans), ['This asks for a total or increase, so add the quantities.', f'{format_num(nums[0])} + {format_num(nums[1])} = {format_num(ans)}.']
    if any(k in q for k in ['left after', 'remain', 'remaining']) and len(nums) >= 2:
        ans = nums[0] - nums[1]
        return format_num(ans), ['This asks how many are left, so subtract the second quantity from the first.', f'{format_num(nums[0])} - {format_num(nums[1])} = {format_num(ans)}.']
    if 'shared equally' in q or 'each gets' in q:
        if len(nums) >= 2:
            ans = nums[0] / nums[1]
            return format_num(ans), ['Equal sharing means division.', f'{format_num(nums[0])} ÷ {format_num(nums[1])} = {format_num(ans)}.']
    if 'each costs' in q or ('cost' in q and ('each' in q or 'quantity' in q)):
        if len(nums) >= 2:
            ans = nums[0] * nums[1]
            return format_num(ans), ['Total cost = cost per item × number of items.', f'{format_num(nums[0])} × {format_num(nums[1])} = {format_num(ans)}.']
    if 'more than' in q and len(nums) >= 2:
        ans = nums[0] + nums[1]
        return format_num(ans), ['"more than" suggests addition here.', f'{format_num(nums[0])} + {format_num(nums[1])} = {format_num(ans)}.']
    raise ValueError('This word problem pattern is not supported yet')

def mensuration(question: str):
    q = question.lower()
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', q)))
    if ('sphere' in q and 'surface area' in q) or ('surface area' in q and 'r' in q and len(nums)>=1):
        r = nums[0]; ans = 4 * (22/7) * r * r if abs(r-round(r))<1e-9 else 4 * math.pi * r * r; steps = ['Surface area of sphere = 4πr².', f'4π×{format_num(r)}² = {format_num(ans)}.']; return format_num(ans), steps
    if 'rectangle' in q and 'perimeter' in q:
        l, b = nums[:2]; ans = 2 * (l + b); steps = ['Perimeter of rectangle = 2(l+b).', f'2({format_num(l)}+{format_num(b)}) = {format_num(ans)}.']; return format_num(ans), steps
    if 'rectangle' in q and 'area' in q:
        l, b = nums[:2]; ans = l * b; steps = ['Area of rectangle = l×b.', f'{format_num(l)}×{format_num(b)} = {format_num(ans)}.']; return format_num(ans), steps
    if 'square' in q and 'perimeter' in q:
        a = nums[0]; ans = 4 * a; steps = ['Perimeter of square = 4a.', f'4×{format_num(a)} = {format_num(ans)}.']; return format_num(ans), steps
    if 'square' in q and 'area' in q:
        a = nums[0]; ans = a * a; steps = ['Area of square = a².', f'{format_num(a)}² = {format_num(ans)}.']; return format_num(ans), steps
    if ('circle' in q and 'area' in q) or ('area' in q and 'r' in q and len(nums)>=1):
        r = nums[0]; ans = (22/7) * r * r if abs(r-round(r))<1e-9 else math.pi * r * r; steps = ['Area of circle = πr².', f'π×{format_num(r)}² = {format_num(ans)}.']; return format_num(ans), steps
    if 'circle' in q and ('circumference' in q or 'perimeter' in q):
        r = nums[0]; ans = 2 * math.pi * r; steps = ['Circumference = 2πr.', f'2π×{format_num(r)} = {format_num(ans)}.']; return format_num(ans), steps
    if 'triangle' in q and 'area' in q and len(nums)>=3:
        if 'heron' in q or len(nums)==3:
            return heron_area(q)
        b, h = nums[:2]; ans = 0.5 * b * h; steps = ['Area of triangle = 1/2 × base × height.', f'1/2 × {format_num(b)} × {format_num(h)} = {format_num(ans)}.']; return format_num(ans), steps
    if 'cube' in q and 'volume' in q:
        a = nums[0]; ans = a ** 3; steps = ['Volume of cube = a³.', f'{format_num(a)}³ = {format_num(ans)}.']; return format_num(ans), steps
    if 'cube' in q and 'surface area' in q:
        a = nums[0]; ans = 6 * a * a; steps = ['Surface area of cube = 6a².', f'6×{format_num(a)}² = {format_num(ans)}.']; return format_num(ans), steps
    if 'cuboid' in q and 'volume' in q:
        l, b, h = nums[:3]; ans = l * b * h; steps = ['Volume of cuboid = l×b×h.', f'{format_num(l)}×{format_num(b)}×{format_num(h)} = {format_num(ans)}.']; return format_num(ans), steps
    if 'cuboid' in q and 'surface area' in q:
        l, b, h = nums[:3]; ans = 2 * (l*b + b*h + h*l); steps = ['Surface area of cuboid = 2(lb+bh+hl).', f'2({format_num(l*b)}+{format_num(b*h)}+{format_num(h*l)}) = {format_num(ans)}.']; return format_num(ans), steps
    raise ValueError('Unsupported mensuration question')



def solve(question: str, topic_hint: str | None = None) -> SolveResult:
    normalized = normalize(question)
    topic, qtype, answer_form, fn = classify_by_pattern(normalized, topic_hint)
    final_answer, steps = fn(normalized)
    return SolveResult(topic=topic, question_type=qtype, answer_form=answer_form, final_answer=final_answer, steps=steps, confidence=0.88)


def next_term_general(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    if len(nums) < 3:
        raise ValueError('Need at least three terms')
    diffs = [nums[i+1]-nums[i] for i in range(len(nums)-1)]
    if all(abs(d-diffs[0]) < 1e-9 for d in diffs):
        ans = nums[-1] + diffs[0]
        return format_num(ans), [f'Terms: {", ".join(format_num(n) for n in nums)}.', f'Common difference = {format_num(diffs[0])}.', f'Next term = {format_num(nums[-1])} + {format_num(diffs[0])} = {format_num(ans)}.']
    ratios = []
    ok = True
    for i in range(len(nums)-1):
        if abs(nums[i]) < 1e-12:
            ok = False; break
        ratios.append(nums[i+1]/nums[i])
    if ok and ratios and all(abs(r-ratios[0]) < 1e-9 for r in ratios):
        ans = nums[-1] * ratios[0]
        return format_num(ans), [f'Terms: {", ".join(format_num(n) for n in nums)}.', f'Common ratio = {format_num(ratios[0])}.', f'Next term = {format_num(nums[-1])} × {format_num(ratios[0])} = {format_num(ans)}.']
    raise ValueError('Could not detect a standard AP or GP pattern.')


def complex_basic(question: str):
    q = normalize(question).lower().replace(' ', '')
    if q in {'i','+i'}:
        return 'i', ['The imaginary unit itself is written as i.']
    m = re.fullmatch(r'i\*\*(\d+)', q) or re.fullmatch(r'i\^(\d+)', q)
    if q in {'i2','i**2','i^2'}:
        m = None
        n = 2
    elif m:
        n = int(m.group(1))
    else:
        mm = re.fullmatch(r'i(\d+)', q)
        if mm:
            n = int(mm.group(1))
        else:
            raise ValueError('Unsupported complex-number power format')
    cycle = {0:'1',1:'i',2:'-1',3:'-i'}
    rem = n % 4
    ans = cycle[rem]
    return ans, [f'The powers of i repeat in a cycle of 4: i, -1, -i, 1.', f'Divide the power {n} by 4 and find the remainder.', f'{n} mod 4 = {rem}.', f'The remainder {rem} corresponds to the value {ans}.', f'Therefore i^{n} = {ans}.']


def vector_magnitude(question: str):
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    if len(nums) == 2:
        x, y = nums; sq = x*x+y*y
        simp = simplify_sqrt_float(sq)
        return simp, [f'Write the vector as ({format_num(x)}, {format_num(y)}).', 'Magnitude of a 2D vector is found using √(x² + y²).', f'Substitute the values: √(({format_num(x)})² + ({format_num(y)})²).', f'This becomes √({format_num(x*x)} + {format_num(y*y)}) = √{format_num(sq)}.', f'So the magnitude is {simp}.']
    if len(nums) >= 3:
        x, y, z = nums[:3]; sq = x*x+y*y+z*z
        simp = simplify_sqrt_float(sq)
        return simp, [f'For vector ({format_num(x)}, {format_num(y)}, {format_num(z)}), magnitude = √(x² + y² + z²).', f'= √({format_num(x*x)} + {format_num(y*y)} + {format_num(z*z)}) = √{format_num(sq)}.', f'Magnitude = {simp}.']
    raise ValueError('Unsupported magnitude format')


def probability_extended(question: str):
    q = normalize(question).lower()
    nums = list(map(int, re.findall(r'\d+', q)))
    if 'coin' in q and ('head' in q or 'tail' in q):
        outcome = 'head' if 'head' in q else 'tail'
        return '1/2', [
            'A fair coin has exactly two equally likely outcomes: Head and Tail.',
            f'Only one of those outcomes is favorable for getting {outcome}.',
            'So favorable outcomes = 1 and total outcomes = 2.',
            'Probability = favorable / total = 1/2.'
        ]
    if 'dice' in q or 'die' in q:
        if nums:
            target = nums[0]
            if 1 <= target <= 6:
                return '1/6', [
                    'A fair die has 6 equally likely outcomes: 1, 2, 3, 4, 5, 6.',
                    f'Only one outcome gives the number {target}.',
                    'So favorable outcomes = 1 and total outcomes = 6.',
                    'Probability = 1/6.'
                ]
        return '1/6', ['A fair die has 6 equally likely outcomes.', 'For any one specified face, favorable outcomes = 1 and total outcomes = 6.', 'Therefore probability = 1/6.']
    if 'card' in q and ('ace' in q or 'king' in q or 'queen' in q or 'jack' in q):
        rank = 'ace' if 'ace' in q else 'king' if 'king' in q else 'queen' if 'queen' in q else 'jack'
        return '1/13', [
            'A standard deck has 52 cards.',
            f'There are 4 {rank} cards in the deck, one in each suit.',
            'Probability = favorable / total = 4/52 = 1/13.'
        ]
    if 'favorable' in q and 'total' in q and len(nums) >= 2:
        return basic_probability(question)
    raise ValueError('Unsupported probability format')


def sequences_series_solver(question: str):
    ql = normalize(question).lower()
    if 'next term' in ql or 'next number' in ql or 'find next' in ql:
        return next_term_general(question)
    nums = list(map(float, re.findall(r'-?\d+(?:\.\d+)?', question)))
    if len(nums) >= 3:
        diffs = [nums[i+1]-nums[i] for i in range(len(nums)-1)]
        if all(abs(d-diffs[0]) < 1e-9 for d in diffs):
            return ap(question)
        ratios = []
        ok = True
        for i in range(len(nums)-1):
            if abs(nums[i]) < 1e-12:
                ok=False; break
            ratios.append(nums[i+1]/nums[i])
        if ok and ratios and all(abs(r-ratios[0]) < 1e-9 for r in ratios):
            r = ratios[0]; nxt = nums[-1]*r
            return format_num(nxt), [
                f'Write the sequence: {", ".join(format_num(n) for n in nums)}.',
                'Check whether each term is obtained by multiplying by the same number.',
                f'{format_num(nums[1])}/{format_num(nums[0])} = {format_num(r)} and the same ratio continues.',
                f'So this is a geometric progression with common ratio {format_num(r)}.',
                f'Next term = last term × ratio = {format_num(nums[-1])} × {format_num(r)} = {format_num(nxt)}.'
            ]
    return ap(question)



def sympy_fallback_json(question: str, topic_hint: str = '') -> dict:
    try:
        import sympy as sp
        from sympy.parsing.sympy_parser import parse_expr
    except Exception as e:
        raise RuntimeError(f'SymPy fallback unavailable: {e}')
    x = sp.symbols('x')
    q = normalize(question).lower()
    q_math = q.replace('equals', '=').replace(' by ', '/').replace('squared', '**2').replace('cubed', '**3')
    steps = []
    final_answer = ''
    topic = topic_hint or 'general_math'
    try:
        if 'determinant' in q or 'matrix' in q:
            nums = [int(n) for n in re.findall(r'-?\d+', q)]
            if len(nums) == 4:
                m = sp.Matrix([[nums[0], nums[1]], [nums[2], nums[3]]])
                if 'inverse' in q:
                    final_answer = str(m.inv())
                    steps = ['Build the 2×2 matrix from the numbers.', 'Compute the inverse using SymPy.']
                elif 'transpose' in q:
                    final_answer = str(m.T)
                    steps = ['Build the 2×2 matrix from the numbers.', 'Transpose rows and columns.']
                else:
                    final_answer = str(m.det())
                    steps = ['Build the 2×2 matrix from the numbers.', 'Compute determinant ad-bc.']
                topic = topic_hint or 'Matrices'
            else:
                raise ValueError('Unsupported matrix size for fallback')
        elif 'differentiate' in q or 'derivative' in q:
            expr_txt = q_math.split('of',1)[-1].strip() if 'of' in q_math else q_math.replace('differentiate','').replace('derivative','').strip()
            expr = parse_expr(expr_txt, local_dict={'x': x})
            final_answer = str(sp.diff(expr, x))
            steps = ['Parse the expression.', 'Apply derivative rules using SymPy.']
            topic = topic_hint or 'Derivatives'
        elif 'integrate' in q or 'integral' in q:
            expr_txt = q_math.replace('integrate','').replace('integral','').strip()
            expr = parse_expr(expr_txt, local_dict={'x': x})
            final_answer = str(sp.integrate(expr, x))
            steps = ['Parse the expression.', 'Apply integration rules using SymPy.']
            topic = topic_hint or 'Integrals'
        elif '=' in q_math or 'solve' in q:
            expr_txt = q_math.replace('solve','').strip()
            if '=' in expr_txt:
                left, right = expr_txt.split('=',1)
                eq = sp.Eq(parse_expr(left, local_dict={'x': x}), parse_expr(right, local_dict={'x': x}))
            else:
                eq = sp.Eq(parse_expr(expr_txt, local_dict={'x': x}), 0)
            sol = sp.solve(eq, x)
            final_answer = str(sol)
            steps = ['Convert the equation into symbolic form.', 'Solve for x using SymPy.']
            topic = topic_hint or 'Algebra Basics'
        elif 'mean' in q or 'median' in q or 'std' in q or 'standard deviation' in q:
            nums = [float(n) for n in re.findall(r'-?\d+(?:\.\d+)?', q)]
            import statistics
            if 'median' in q:
                final_answer = str(statistics.median(nums))
                steps = ['List the data points.', 'Take the middle value after sorting.']
            elif 'std' in q or 'standard deviation' in q:
                final_answer = str(statistics.pstdev(nums))
                steps = ['List the data points.', 'Compute population standard deviation.']
            else:
                final_answer = str(statistics.mean(nums))
                steps = ['List the data points.', 'Add them and divide by the count.']
            topic = topic_hint or 'Statistics'
        else:
            raise ValueError('Fallback topic not supported')
    except Exception as e:
        raise RuntimeError(str(e))
    return {
        'topic': topic,
        'subtopic': '',
        'difficulty': 'intermediate',
        'problem_restatement': question,
        'what_we_know': [question],
        'what_we_find': 'the required answer',
        'approach': 'SymPy fallback symbolic solving.',
        'steps': [
            {'step_number': i+1, 'title': f'Step {i+1}', 'why': 'Symbolic fallback step', 'working': s, 'result': '', 'note': ''}
            for i, s in enumerate(steps)
        ],
        'final_answer': final_answer,
        'unit': '',
        'verification': 'Solved using SymPy fallback.',
        'shortcut': '',
        'formulas_used': [],
        'real_world_use': '',
        'common_mistakes': [],
        'practice_problems': [],
        'solved_by': 'SymPy Fallback'
    }

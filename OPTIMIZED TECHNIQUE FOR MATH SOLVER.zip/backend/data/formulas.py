"""
MathGenius Formula Database
Complete formula reference for all 40+ mathematical topics
YOUR curated knowledge base - a core academic contribution
"""

FORMULA_DATABASE = {
    "Numbers & Arithmetic": {
        "intro": "The foundation of all mathematics — understanding numbers and their operations.",
        "sections": [
            {
                "name": "Number Types",
                "formulas": [
                    {"name": "Natural Numbers", "formula": "N = {1, 2, 3, 4, ...}", "desc": "Counting numbers starting from 1"},
                    {"name": "Whole Numbers", "formula": "W = {0, 1, 2, 3, ...}", "desc": "Natural numbers including 0"},
                    {"name": "Integers", "formula": "Z = {..., -2, -1, 0, 1, 2, ...}", "desc": "Positive, negative numbers and zero"},
                    {"name": "Rational Numbers", "formula": "Q = {p/q : p,q ∈ Z, q≠0}", "desc": "Numbers expressible as fractions"},
                    {"name": "Irrational Numbers", "formula": "√2, √3, π, e", "desc": "Cannot be expressed as p/q"},
                    {"name": "Real Numbers", "formula": "R = Q ∪ Q'", "desc": "All rational and irrational numbers"},
                ]
            },
            {
                "name": "Divisibility Rules",
                "formulas": [
                    {"name": "Divisible by 2", "formula": "Last digit is 0,2,4,6,8", "desc": "Number is even"},
                    {"name": "Divisible by 3", "formula": "Sum of digits divisible by 3", "desc": "e.g., 123: 1+2+3=6 ✓"},
                    {"name": "Divisible by 4", "formula": "Last 2 digits divisible by 4", "desc": "e.g., 1324: 24÷4=6 ✓"},
                    {"name": "Divisible by 5", "formula": "Last digit is 0 or 5", "desc": "e.g., 345, 120"},
                    {"name": "Divisible by 9", "formula": "Sum of digits divisible by 9", "desc": "e.g., 729: 7+2+9=18 ✓"},
                    {"name": "Divisible by 11", "formula": "(Sum of odd pos digits) - (Sum of even pos digits) = 0 or 11", "desc": "Alternating sum rule"},
                ]
            },
            {
                "name": "HCF and LCM",
                "formulas": [
                    {"name": "HCF × LCM", "formula": "HCF(a,b) × LCM(a,b) = a × b", "desc": "Product property"},
                    {"name": "HCF by Euclid", "formula": "HCF(a,b) = HCF(b, a mod b)", "desc": "Euclid's division algorithm"},
                    {"name": "LCM Formula", "formula": "LCM(a,b) = (a × b) / HCF(a,b)", "desc": "Using HCF to find LCM"},
                ]
            },
            {
                "name": "BODMAS / PEMDAS",
                "formulas": [
                    {"name": "Order of Operations", "formula": "B→O→D→M→A→S (Brackets, Orders, Division, Multiplication, Addition, Subtraction)", "desc": "Always follow this order"},
                ]
            }
        ]
    },

    "Fractions": {
        "intro": "Fractions represent parts of a whole. Mastering fractions is key to algebra and beyond.",
        "sections": [
            {
                "name": "Basic Fraction Operations",
                "formulas": [
                    {"name": "Addition (same denominator)", "formula": "a/b + c/b = (a+c)/b", "desc": "Add numerators directly"},
                    {"name": "Addition (different denominator)", "formula": "a/b + c/d = (ad + bc) / bd", "desc": "Cross multiply and add"},
                    {"name": "Subtraction", "formula": "a/b - c/d = (ad - bc) / bd", "desc": "Cross multiply and subtract"},
                    {"name": "Multiplication", "formula": "a/b × c/d = ac / bd", "desc": "Multiply numerators and denominators"},
                    {"name": "Division", "formula": "a/b ÷ c/d = a/b × d/c = ad/bc", "desc": "Multiply by reciprocal"},
                    {"name": "Reciprocal", "formula": "Reciprocal of a/b = b/a", "desc": "Flip the fraction"},
                ]
            },
            {
                "name": "Fraction Conversion",
                "formulas": [
                    {"name": "Fraction to Decimal", "formula": "a/b = a ÷ b", "desc": "Divide numerator by denominator"},
                    {"name": "Fraction to Percent", "formula": "(a/b) × 100%", "desc": "Multiply by 100"},
                    {"name": "Mixed to Improper", "formula": "a b/c = (a×c + b)/c", "desc": "Whole × denominator + numerator"},
                    {"name": "Simplification", "formula": "a/b = (a÷HCF) / (b÷HCF)", "desc": "Divide both by HCF"},
                ]
            }
        ]
    },

    "Algebra Basics": {
        "intro": "Algebra uses letters to represent unknown quantities and find their values.",
        "sections": [
            {
                "name": "Algebraic Identities",
                "formulas": [
                    {"name": "(a+b)²", "formula": "(a+b)² = a² + 2ab + b²", "desc": "Square of sum"},
                    {"name": "(a-b)²", "formula": "(a-b)² = a² - 2ab + b²", "desc": "Square of difference"},
                    {"name": "a²-b²", "formula": "a² - b² = (a+b)(a-b)", "desc": "Difference of squares"},
                    {"name": "(a+b+c)²", "formula": "(a+b+c)² = a²+b²+c²+2ab+2bc+2ca", "desc": "Square of trinomial"},
                    {"name": "(a+b)³", "formula": "(a+b)³ = a³ + 3a²b + 3ab² + b³", "desc": "Cube of sum"},
                    {"name": "(a-b)³", "formula": "(a-b)³ = a³ - 3a²b + 3ab² - b³", "desc": "Cube of difference"},
                    {"name": "a³+b³", "formula": "a³+b³ = (a+b)(a²-ab+b²)", "desc": "Sum of cubes"},
                    {"name": "a³-b³", "formula": "a³-b³ = (a-b)(a²+ab+b²)", "desc": "Difference of cubes"},
                ]
            },
            {
                "name": "Linear Equations",
                "formulas": [
                    {"name": "Standard Form", "formula": "ax + b = c → x = (c-b)/a", "desc": "Isolate variable x"},
                    {"name": "Solution Formula", "formula": "x = (c - b) / a, where a ≠ 0", "desc": "Direct formula for linear equation"},
                ]
            }
        ]
    },

    "Quadratic Equations": {
        "intro": "Quadratic equations are degree-2 polynomial equations with at most two solutions.",
        "sections": [
            {
                "name": "Core Formulas",
                "formulas": [
                    {"name": "Standard Form", "formula": "ax² + bx + c = 0, a ≠ 0", "desc": "General quadratic equation"},
                    {"name": "Quadratic Formula", "formula": "x = (-b ± √(b²-4ac)) / 2a", "desc": "Universal solution formula"},
                    {"name": "Discriminant", "formula": "D = b² - 4ac", "desc": "Determines nature of roots"},
                    {"name": "Nature of Roots", "formula": "D>0: two real roots | D=0: equal roots | D<0: complex roots", "desc": "Based on discriminant value"},
                    {"name": "Sum of Roots", "formula": "α + β = -b/a", "desc": "Sum of both roots"},
                    {"name": "Product of Roots", "formula": "α × β = c/a", "desc": "Product of both roots"},
                    {"name": "Form from Roots", "formula": "x² - (α+β)x + αβ = 0", "desc": "Build equation from known roots"},
                ]
            },
            {
                "name": "Solution Methods",
                "formulas": [
                    {"name": "Factorization", "formula": "ax²+bx+c = a(x-α)(x-β)", "desc": "Factor into two linear terms"},
                    {"name": "Completing the Square", "formula": "(x + b/2a)² = (b²-4ac)/4a²", "desc": "Perfect square method"},
                ]
            }
        ]
    },

    "Trigonometry": {
        "intro": "Trigonometry studies relationships between angles and sides in triangles.",
        "sections": [
            {
                "name": "Basic Ratios",
                "formulas": [
                    {"name": "sin θ", "formula": "sin θ = Opposite / Hypotenuse", "desc": "SOH"},
                    {"name": "cos θ", "formula": "cos θ = Adjacent / Hypotenuse", "desc": "CAH"},
                    {"name": "tan θ", "formula": "tan θ = Opposite / Adjacent = sin θ / cos θ", "desc": "TOA"},
                    {"name": "cosec θ", "formula": "cosec θ = 1/sin θ = H/O", "desc": "Reciprocal of sin"},
                    {"name": "sec θ", "formula": "sec θ = 1/cos θ = H/A", "desc": "Reciprocal of cos"},
                    {"name": "cot θ", "formula": "cot θ = 1/tan θ = cos θ/sin θ", "desc": "Reciprocal of tan"},
                ]
            },
            {
                "name": "Standard Values",
                "formulas": [
                    {"name": "sin values", "formula": "sin 0°=0, sin 30°=½, sin 45°=1/√2, sin 60°=√3/2, sin 90°=1", "desc": "Key sine values"},
                    {"name": "cos values", "formula": "cos 0°=1, cos 30°=√3/2, cos 45°=1/√2, cos 60°=½, cos 90°=0", "desc": "Key cosine values"},
                    {"name": "tan values", "formula": "tan 0°=0, tan 30°=1/√3, tan 45°=1, tan 60°=√3, tan 90°=∞", "desc": "Key tangent values"},
                ]
            },
            {
                "name": "Fundamental Identities",
                "formulas": [
                    {"name": "Pythagorean 1", "formula": "sin²θ + cos²θ = 1", "desc": "Most important identity"},
                    {"name": "Pythagorean 2", "formula": "1 + tan²θ = sec²θ", "desc": "Derived from identity 1"},
                    {"name": "Pythagorean 3", "formula": "1 + cot²θ = cosec²θ", "desc": "Derived from identity 1"},
                ]
            },
            {
                "name": "Compound Angle Formulas",
                "formulas": [
                    {"name": "sin(A+B)", "formula": "sin(A+B) = sinA cosB + cosA sinB", "desc": "Addition formula"},
                    {"name": "sin(A-B)", "formula": "sin(A-B) = sinA cosB - cosA sinB", "desc": "Subtraction formula"},
                    {"name": "cos(A+B)", "formula": "cos(A+B) = cosA cosB - sinA sinB", "desc": "Addition formula"},
                    {"name": "cos(A-B)", "formula": "cos(A-B) = cosA cosB + sinA sinB", "desc": "Subtraction formula"},
                    {"name": "tan(A+B)", "formula": "tan(A+B) = (tanA + tanB)/(1 - tanA tanB)", "desc": "Addition formula"},
                    {"name": "sin 2A", "formula": "sin 2A = 2 sinA cosA", "desc": "Double angle"},
                    {"name": "cos 2A", "formula": "cos 2A = cos²A - sin²A = 1-2sin²A = 2cos²A-1", "desc": "Double angle - 3 forms"},
                    {"name": "tan 2A", "formula": "tan 2A = 2tanA / (1 - tan²A)", "desc": "Double angle"},
                ]
            }
        ]
    },

    "Derivatives": {
        "intro": "Derivatives measure the rate of change of a function — the slope at any point.",
        "sections": [
            {
                "name": "Basic Derivatives",
                "formulas": [
                    {"name": "Constant", "formula": "d/dx(c) = 0", "desc": "Derivative of constant is zero"},
                    {"name": "Power Rule", "formula": "d/dx(xⁿ) = nxⁿ⁻¹", "desc": "Most used rule"},
                    {"name": "sin x", "formula": "d/dx(sin x) = cos x", "desc": ""},
                    {"name": "cos x", "formula": "d/dx(cos x) = -sin x", "desc": "Note negative sign"},
                    {"name": "tan x", "formula": "d/dx(tan x) = sec²x", "desc": ""},
                    {"name": "eˣ", "formula": "d/dx(eˣ) = eˣ", "desc": "Unique — derivative is itself"},
                    {"name": "aˣ", "formula": "d/dx(aˣ) = aˣ ln a", "desc": "Exponential with base a"},
                    {"name": "ln x", "formula": "d/dx(ln x) = 1/x", "desc": "Natural log derivative"},
                    {"name": "log_a x", "formula": "d/dx(log_a x) = 1/(x ln a)", "desc": "Log base a"},
                ]
            },
            {
                "name": "Rules of Differentiation",
                "formulas": [
                    {"name": "Sum Rule", "formula": "d/dx(u+v) = du/dx + dv/dx", "desc": "Differentiate term by term"},
                    {"name": "Product Rule", "formula": "d/dx(uv) = u(dv/dx) + v(du/dx)", "desc": "uv' + vu'"},
                    {"name": "Quotient Rule", "formula": "d/dx(u/v) = (v·du/dx - u·dv/dx) / v²", "desc": "(v·u' - u·v') / v²"},
                    {"name": "Chain Rule", "formula": "d/dx[f(g(x))] = f'(g(x)) · g'(x)", "desc": "Derivative of composite function"},
                ]
            }
        ]
    },

    "Integrals": {
        "intro": "Integration is the reverse of differentiation — finding area under curves.",
        "sections": [
            {
                "name": "Standard Integrals",
                "formulas": [
                    {"name": "Power Rule", "formula": "∫xⁿ dx = xⁿ⁺¹/(n+1) + C, n≠-1", "desc": "Most fundamental integration rule"},
                    {"name": "1/x", "formula": "∫(1/x) dx = ln|x| + C", "desc": "Exception to power rule"},
                    {"name": "eˣ", "formula": "∫eˣ dx = eˣ + C", "desc": ""},
                    {"name": "aˣ", "formula": "∫aˣ dx = aˣ/ln(a) + C", "desc": "Exponential with base a"},
                    {"name": "sin x", "formula": "∫sin x dx = -cos x + C", "desc": "Note negative sign"},
                    {"name": "cos x", "formula": "∫cos x dx = sin x + C", "desc": ""},
                    {"name": "sec²x", "formula": "∫sec²x dx = tan x + C", "desc": "Integral of sec squared"},
                    {"name": "1/(1+x²)", "formula": "∫1/(1+x²) dx = tan⁻¹x + C", "desc": "Inverse trig integral"},
                    {"name": "1/√(1-x²)", "formula": "∫1/√(1-x²) dx = sin⁻¹x + C", "desc": "Inverse trig integral"},
                ]
            },
            {
                "name": "Integration Techniques",
                "formulas": [
                    {"name": "Substitution", "formula": "∫f(g(x))g'(x)dx = ∫f(u)du where u=g(x)", "desc": "Most used technique"},
                    {"name": "By Parts", "formula": "∫u dv = uv - ∫v du", "desc": "ILATE rule for choosing u"},
                    {"name": "ILATE order", "formula": "I=Inverse trig, L=Log, A=Algebraic, T=Trig, E=Exponential", "desc": "Choose u in this order"},
                    {"name": "Definite Integral", "formula": "∫ₐᵇ f(x)dx = F(b) - F(a)", "desc": "Fundamental theorem of calculus"},
                ]
            }
        ]
    },

    "Matrices": {
        "intro": "Matrices are rectangular arrays of numbers used in linear algebra and solving systems of equations.",
        "sections": [
            {
                "name": "Matrix Operations",
                "formulas": [
                    {"name": "Addition", "formula": "[A+B]ᵢⱼ = Aᵢⱼ + Bᵢⱼ", "desc": "Add corresponding elements"},
                    {"name": "Scalar Multiplication", "formula": "[kA]ᵢⱼ = k·Aᵢⱼ", "desc": "Multiply every element by k"},
                    {"name": "Matrix Multiplication", "formula": "[AB]ᵢⱼ = Σₖ AᵢₖBₖⱼ", "desc": "Row × Column"},
                    {"name": "Transpose", "formula": "[Aᵀ]ᵢⱼ = Aⱼᵢ", "desc": "Rows become columns"},
                ]
            },
            {
                "name": "Special Matrices",
                "formulas": [
                    {"name": "Identity Matrix I", "formula": "Iᵢⱼ = 1 if i=j, else 0", "desc": "Diagonal of 1s"},
                    {"name": "Zero Matrix", "formula": "All elements = 0", "desc": "Additive identity"},
                    {"name": "Symmetric Matrix", "formula": "A = Aᵀ", "desc": "Equal to its transpose"},
                    {"name": "Skew-Symmetric", "formula": "A = -Aᵀ", "desc": "Diagonal elements are 0"},
                ]
            },
            {
                "name": "Inverse of Matrix",
                "formulas": [
                    {"name": "2×2 Inverse", "formula": "A⁻¹ = (1/det A) × [[d,-b],[-c,a]] for A=[[a,b],[c,d]]", "desc": "Swap diagonal, negate off-diagonal, divide by det"},
                    {"name": "General Inverse", "formula": "A⁻¹ = adj(A) / det(A)", "desc": "Adjoint divided by determinant"},
                    {"name": "Condition", "formula": "A⁻¹ exists only if det(A) ≠ 0", "desc": "Non-singular matrix condition"},
                ]
            }
        ]
    },

    "Determinants": {
        "intro": "Determinant is a scalar value computed from a square matrix, measuring scaling factor of transformation.",
        "sections": [
            {
                "name": "Determinant Formulas",
                "formulas": [
                    {"name": "2×2 Determinant", "formula": "det[[a,b],[c,d]] = ad - bc", "desc": "Product of diagonals difference"},
                    {"name": "3×3 Determinant", "formula": "det A = a(ei-fh) - b(di-fg) + c(dh-eg)", "desc": "Cofactor expansion along first row"},
                    {"name": "Properties", "formula": "det(AB) = det(A)·det(B)", "desc": "Multiplicative property"},
                    {"name": "Transpose Property", "formula": "det(Aᵀ) = det(A)", "desc": "Same determinant as original"},
                    {"name": "Singular Matrix", "formula": "det(A) = 0 ↔ A is singular (no inverse)", "desc": "Zero determinant condition"},
                ]
            },
            {
                "name": "Applications",
                "formulas": [
                    {"name": "Area of Triangle", "formula": "Area = ½|x₁(y₂-y₃) + x₂(y₃-y₁) + x₃(y₁-y₂)|", "desc": "Using coordinates"},
                    {"name": "Cramer's Rule", "formula": "x = Dₓ/D, y = Dᵧ/D, z = D_z/D", "desc": "Solve system using determinants"},
                ]
            }
        ]
    },

    "Limits": {
        "intro": "A limit describes the value a function approaches as the input approaches a given point.",
        "sections": [
            {
                "name": "Standard Limits",
                "formulas": [
                    {"name": "sin x / x", "formula": "lim(x→0) sin x/x = 1", "desc": "Most important limit"},
                    {"name": "(1-cos x)/x", "formula": "lim(x→0) (1-cos x)/x = 0", "desc": ""},
                    {"name": "Exponential", "formula": "lim(x→0) (eˣ-1)/x = 1", "desc": ""},
                    {"name": "Natural Log", "formula": "lim(x→0) ln(1+x)/x = 1", "desc": ""},
                    {"name": "e definition", "formula": "lim(n→∞) (1 + 1/n)ⁿ = e", "desc": "Definition of Euler's number"},
                    {"name": "Power limit", "formula": "lim(x→a) (xⁿ-aⁿ)/(x-a) = naⁿ⁻¹", "desc": "Polynomial limit formula"},
                ]
            },
            {
                "name": "Limit Rules",
                "formulas": [
                    {"name": "Sum Rule", "formula": "lim(f+g) = lim f + lim g", "desc": ""},
                    {"name": "Product Rule", "formula": "lim(f·g) = lim f · lim g", "desc": ""},
                    {"name": "Quotient Rule", "formula": "lim(f/g) = lim f / lim g, if lim g ≠ 0", "desc": ""},
                    {"name": "L'Hôpital's Rule", "formula": "lim f(x)/g(x) = lim f'(x)/g'(x) for 0/0 or ∞/∞ forms", "desc": "For indeterminate forms"},
                ]
            }
        ]
    },

    "Coordinate Geometry": {
        "intro": "Coordinate geometry combines algebra and geometry using a coordinate plane.",
        "sections": [
            {
                "name": "Distance and Division",
                "formulas": [
                    {"name": "Distance Formula", "formula": "d = √[(x₂-x₁)² + (y₂-y₁)²]", "desc": "Distance between two points"},
                    {"name": "Midpoint Formula", "formula": "M = ((x₁+x₂)/2, (y₁+y₂)/2)", "desc": "Middle point of segment"},
                    {"name": "Section Formula (internal)", "formula": "P = ((mx₂+nx₁)/(m+n), (my₂+ny₁)/(m+n))", "desc": "Point dividing in m:n ratio"},
                    {"name": "Centroid", "formula": "G = ((x₁+x₂+x₃)/3, (y₁+y₂+y₃)/3)", "desc": "Centroid of triangle"},
                ]
            },
            {
                "name": "Straight Lines",
                "formulas": [
                    {"name": "Slope", "formula": "m = (y₂-y₁)/(x₂-x₁) = tan θ", "desc": "Rise over run"},
                    {"name": "Slope-Intercept Form", "formula": "y = mx + c", "desc": "m=slope, c=y-intercept"},
                    {"name": "Point-Slope Form", "formula": "y - y₁ = m(x - x₁)", "desc": "Line through point with slope m"},
                    {"name": "Two-Point Form", "formula": "(y-y₁)/(y₂-y₁) = (x-x₁)/(x₂-x₁)", "desc": "Line through two points"},
                    {"name": "Standard Form", "formula": "ax + by + c = 0", "desc": "General linear equation"},
                    {"name": "Distance from Point to Line", "formula": "d = |ax₁+by₁+c| / √(a²+b²)", "desc": "Perpendicular distance"},
                    {"name": "Parallel lines", "formula": "m₁ = m₂ (same slope)", "desc": "Condition for parallel lines"},
                    {"name": "Perpendicular lines", "formula": "m₁ × m₂ = -1", "desc": "Product of slopes = -1"},
                ]
            },
            {
                "name": "Circle",
                "formulas": [
                    {"name": "Standard Form", "formula": "(x-h)² + (y-k)² = r²", "desc": "Center (h,k), radius r"},
                    {"name": "General Form", "formula": "x² + y² + 2gx + 2fy + c = 0", "desc": "Center (-g,-f), radius = √(g²+f²-c)"},
                    {"name": "Area of Triangle", "formula": "Area = ½|x₁(y₂-y₃)+x₂(y₃-y₁)+x₃(y₁-y₂)|", "desc": "Using vertex coordinates"},
                ]
            }
        ]
    },

    "Complex Numbers": {
        "intro": "Complex numbers extend real numbers with an imaginary unit i where i² = -1.",
        "sections": [
            {
                "name": "Fundamentals",
                "formulas": [
                    {"name": "Definition", "formula": "z = a + bi, where i = √(-1)", "desc": "a=real part, b=imaginary part"},
                    {"name": "Powers of i", "formula": "i¹=i, i²=-1, i³=-i, i⁴=1 (cycle of 4)", "desc": "Repeat every 4 powers"},
                    {"name": "Conjugate", "formula": "z̄ = a - bi (flip sign of imaginary part)", "desc": "Used in division"},
                    {"name": "Modulus", "formula": "|z| = √(a² + b²)", "desc": "Distance from origin"},
                    {"name": "Argument", "formula": "arg(z) = θ = tan⁻¹(b/a)", "desc": "Angle with positive x-axis"},
                ]
            },
            {
                "name": "Operations",
                "formulas": [
                    {"name": "Addition", "formula": "(a+bi) + (c+di) = (a+c) + (b+d)i", "desc": "Add real and imaginary separately"},
                    {"name": "Multiplication", "formula": "(a+bi)(c+di) = (ac-bd) + (ad+bc)i", "desc": "FOIL and use i²=-1"},
                    {"name": "Division", "formula": "(a+bi)/(c+di) = (a+bi)(c-di)/(c²+d²)", "desc": "Multiply by conjugate"},
                    {"name": "Polar Form", "formula": "z = r(cosθ + i sinθ) = re^(iθ)", "desc": "r=|z|, θ=arg(z)"},
                    {"name": "De Moivre's Theorem", "formula": "[r(cosθ+i sinθ)]ⁿ = rⁿ(cos nθ + i sin nθ)", "desc": "Power of complex number"},
                ]
            }
        ]
    },

    "Arithmetic Progression": {
        "intro": "An AP is a sequence where each term differs from previous by a constant value called common difference.",
        "sections": [
            {
                "name": "AP Formulas",
                "formulas": [
                    {"name": "nth Term", "formula": "aₙ = a + (n-1)d", "desc": "a=first term, d=common difference, n=term number"},
                    {"name": "Common Difference", "formula": "d = a₂ - a₁ = a₃ - a₂ (constant)", "desc": ""},
                    {"name": "Sum of n terms", "formula": "Sₙ = n/2 × [2a + (n-1)d]", "desc": "Sum formula 1"},
                    {"name": "Sum (with last term)", "formula": "Sₙ = n/2 × (a + l)", "desc": "l = last term"},
                    {"name": "Sum of natural numbers", "formula": "1+2+3+...+n = n(n+1)/2", "desc": "Special AP"},
                    {"name": "Sum of squares", "formula": "1²+2²+...+n² = n(n+1)(2n+1)/6", "desc": "Special series"},
                    {"name": "Sum of cubes", "formula": "1³+2³+...+n³ = [n(n+1)/2]²", "desc": "Special series"},
                ]
            }
        ]
    },

    "Probability": {
        "intro": "Probability measures the likelihood of an event occurring, ranging from 0 (impossible) to 1 (certain).",
        "sections": [
            {
                "name": "Basic Probability",
                "formulas": [
                    {"name": "Classical Probability", "formula": "P(A) = Favorable outcomes / Total outcomes", "desc": "When outcomes are equally likely"},
                    {"name": "Complement", "formula": "P(A') = 1 - P(A)", "desc": "Probability event does NOT happen"},
                    {"name": "Addition Rule", "formula": "P(A∪B) = P(A) + P(B) - P(A∩B)", "desc": "For any two events"},
                    {"name": "Mutually Exclusive", "formula": "P(A∪B) = P(A) + P(B)", "desc": "When P(A∩B)=0"},
                    {"name": "Conditional Probability", "formula": "P(A|B) = P(A∩B) / P(B)", "desc": "Probability of A given B occurred"},
                    {"name": "Multiplication Rule", "formula": "P(A∩B) = P(A) × P(B|A)", "desc": "For dependent events"},
                    {"name": "Independent Events", "formula": "P(A∩B) = P(A) × P(B)", "desc": "When events don't affect each other"},
                    {"name": "Bayes' Theorem", "formula": "P(A|B) = P(B|A)·P(A) / P(B)", "desc": "Reverses conditional probability"},
                ]
            }
        ]
    },

    "Vector Algebra": {
        "intro": "Vectors have both magnitude and direction, essential in physics and 3D mathematics.",
        "sections": [
            {
                "name": "Vector Operations",
                "formulas": [
                    {"name": "Magnitude", "formula": "|a⃗| = √(a₁²+a₂²+a₃²)", "desc": "Length of vector"},
                    {"name": "Unit Vector", "formula": "â = a⃗/|a⃗|", "desc": "Vector with magnitude 1"},
                    {"name": "Dot Product", "formula": "a⃗·b⃗ = |a||b|cosθ = a₁b₁+a₂b₂+a₃b₃", "desc": "Scalar result"},
                    {"name": "Cross Product magnitude", "formula": "|a⃗×b⃗| = |a||b|sinθ", "desc": "Vector result, perpendicular to both"},
                    {"name": "Cross Product i j k", "formula": "a⃗×b⃗ = |i  j  k; a₁ a₂ a₃; b₁ b₂ b₃|", "desc": "Determinant form"},
                    {"name": "Angle between vectors", "formula": "cosθ = (a⃗·b⃗)/(|a⃗||b⃗|)", "desc": "Using dot product"},
                    {"name": "Parallel condition", "formula": "a⃗×b⃗ = 0⃗ (or a⃗ = λb⃗)", "desc": "Vectors parallel if cross product zero"},
                    {"name": "Perpendicular condition", "formula": "a⃗·b⃗ = 0", "desc": "Dot product = 0"},
                    {"name": "Scalar Triple Product", "formula": "[a b c] = a⃗·(b⃗×c⃗)", "desc": "Volume of parallelepiped"},
                ]
            }
        ]
    },

    "Statistics": {
        "intro": "Statistics involves collecting, analyzing, and interpreting numerical data.",
        "sections": [
            {
                "name": "Measures of Central Tendency",
                "formulas": [
                    {"name": "Mean", "formula": "x̄ = (Σxᵢ)/n = (x₁+x₂+...+xₙ)/n", "desc": "Average of all values"},
                    {"name": "Median (odd n)", "formula": "Middle value of sorted data", "desc": ""},
                    {"name": "Median (even n)", "formula": "Average of two middle values", "desc": ""},
                    {"name": "Mode", "formula": "Most frequently occurring value", "desc": "Can have multiple modes"},
                    {"name": "Weighted Mean", "formula": "x̄ = Σ(wᵢxᵢ)/Σwᵢ", "desc": "When values have different weights"},
                ]
            },
            {
                "name": "Measures of Dispersion",
                "formulas": [
                    {"name": "Range", "formula": "Range = Maximum - Minimum", "desc": "Simplest measure"},
                    {"name": "Variance", "formula": "σ² = Σ(xᵢ-x̄)²/n", "desc": "Average squared deviation"},
                    {"name": "Standard Deviation", "formula": "σ = √[Σ(xᵢ-x̄)²/n]", "desc": "Square root of variance"},
                    {"name": "Coefficient of Variation", "formula": "CV = (σ/x̄) × 100%", "desc": "Relative measure of dispersion"},
                    {"name": "Mean Deviation", "formula": "MD = Σ|xᵢ-x̄|/n", "desc": "Average absolute deviation"},
                ]
            }
        ]
    },

    "Probability Distributions": {
        "intro": "Probability distributions describe how probabilities are distributed over values of a random variable.",
        "sections": [
            {
                "name": "Binomial Distribution",
                "formulas": [
                    {"name": "PMF", "formula": "P(X=r) = C(n,r)·pʳ·qⁿ⁻ʳ, q=1-p", "desc": "Probability of exactly r successes in n trials"},
                    {"name": "Mean", "formula": "μ = np", "desc": "Expected number of successes"},
                    {"name": "Variance", "formula": "σ² = npq", "desc": ""},
                    {"name": "SD", "formula": "σ = √(npq)", "desc": ""},
                ]
            },
            {
                "name": "Poisson Distribution",
                "formulas": [
                    {"name": "PMF", "formula": "P(X=k) = e^(-λ) · λᵏ / k!", "desc": "λ = average rate of occurrence"},
                    {"name": "Mean", "formula": "μ = λ", "desc": ""},
                    {"name": "Variance", "formula": "σ² = λ", "desc": "Mean equals variance in Poisson"},
                ]
            },
            {
                "name": "Normal Distribution",
                "formulas": [
                    {"name": "PDF", "formula": "f(x) = (1/σ√2π) e^[-(x-μ)²/2σ²]", "desc": "Bell curve formula"},
                    {"name": "Standard Normal", "formula": "Z = (X - μ) / σ", "desc": "Standardize any normal distribution"},
                    {"name": "68-95-99.7 Rule", "formula": "68% within 1σ, 95% within 2σ, 99.7% within 3σ", "desc": "Empirical rule"},
                ]
            }
        ]
    },

    "Linear Programming": {
        "intro": "Linear programming optimizes (maximizes or minimizes) a linear objective function subject to linear constraints.",
        "sections": [
            {
                "name": "LP Formulation",
                "formulas": [
                    {"name": "Objective Function", "formula": "Maximize/Minimize Z = c₁x₁ + c₂x₂ + ... + cₙxₙ", "desc": "What we want to optimize"},
                    {"name": "Constraints", "formula": "a₁x₁ + a₂x₂ ≤ b₁ (or ≥ or =)", "desc": "Limitations on variables"},
                    {"name": "Non-negativity", "formula": "x₁ ≥ 0, x₂ ≥ 0", "desc": "Variables cannot be negative"},
                    {"name": "Corner Point Theorem", "formula": "Optimal solution occurs at corner point of feasible region", "desc": "Key theorem for graphical method"},
                ]
            }
        ]
    },

    "Differential Equations": {
        "intro": "Differential equations involve derivatives of unknown functions and model real-world phenomena.",
        "sections": [
            {
                "name": "Classification",
                "formulas": [
                    {"name": "Order", "formula": "Order = highest derivative in the equation", "desc": "e.g., d²y/dx² → order 2"},
                    {"name": "Degree", "formula": "Degree = power of highest order derivative (when rationalized)", "desc": ""},
                    {"name": "Linear DE", "formula": "dy/dx + P(x)y = Q(x)", "desc": "Standard first-order linear form"},
                ]
            },
            {
                "name": "Solution Methods",
                "formulas": [
                    {"name": "Variable Separable", "formula": "f(y)dy = g(x)dx → ∫f(y)dy = ∫g(x)dx", "desc": "Separate variables to each side"},
                    {"name": "Integrating Factor", "formula": "IF = e^∫P(x)dx", "desc": "For linear first-order DE"},
                    {"name": "Solution with IF", "formula": "y × IF = ∫Q(x)×IF dx + C", "desc": "Multiply through by integrating factor"},
                    {"name": "Homogeneous DE", "formula": "Put y = vx, then dy/dx = v + x(dv/dx)", "desc": "Substitution for homogeneous form"},
                ]
            }
        ]
    },

    "Sets, Relations, Functions": {
        "intro": "Sets are collections of objects. Relations and functions describe how elements are connected.",
        "sections": [
            {
                "name": "Set Operations",
                "formulas": [
                    {"name": "Union", "formula": "A∪B = {x : x∈A or x∈B}", "desc": "All elements from both sets"},
                    {"name": "Intersection", "formula": "A∩B = {x : x∈A and x∈B}", "desc": "Common elements only"},
                    {"name": "Complement", "formula": "A' = U - A = {x∈U : x∉A}", "desc": "Elements not in A"},
                    {"name": "Difference", "formula": "A-B = {x : x∈A and x∉B}", "desc": "In A but not in B"},
                    {"name": "Symmetric Difference", "formula": "A△B = (A-B)∪(B-A)", "desc": "Elements in one but not both"},
                ]
            },
            {
                "name": "De Morgan's Laws",
                "formulas": [
                    {"name": "Law 1", "formula": "(A∪B)' = A'∩B'", "desc": "Complement of union"},
                    {"name": "Law 2", "formula": "(A∩B)' = A'∪B'", "desc": "Complement of intersection"},
                    {"name": "Power Set Size", "formula": "|P(A)| = 2ⁿ where n=|A|", "desc": "Number of subsets"},
                ]
            },
            {
                "name": "Functions",
                "formulas": [
                    {"name": "Injective (One-One)", "formula": "f(a)=f(b) → a=b", "desc": "Different inputs give different outputs"},
                    {"name": "Surjective (Onto)", "formula": "Range = Codomain", "desc": "Every element of codomain is mapped"},
                    {"name": "Bijective", "formula": "Both injective and surjective", "desc": "One-to-one correspondence"},
                    {"name": "Inverse Function", "formula": "f⁻¹ exists only if f is bijective", "desc": ""},
                    {"name": "Composition", "formula": "(fog)(x) = f(g(x))", "desc": "Apply g first, then f"},
                ]
            }
        ]
    },

    "Sequences & Series": {
        "intro": "A sequence is an ordered list of numbers; a series is the sum of a sequence.",
        "sections": [
            {
                "name": "Geometric Progression",
                "formulas": [
                    {"name": "nth Term", "formula": "aₙ = a·rⁿ⁻¹", "desc": "a=first term, r=common ratio"},
                    {"name": "Sum of n terms", "formula": "Sₙ = a(rⁿ-1)/(r-1) for r≠1", "desc": ""},
                    {"name": "Infinite GP (|r|<1)", "formula": "S∞ = a/(1-r)", "desc": "Sum to infinity when |r|<1"},
                    {"name": "GM Formula", "formula": "GM = √(a·b) for two numbers", "desc": "Geometric mean"},
                ]
            },
            {
                "name": "Special Means",
                "formulas": [
                    {"name": "AM", "formula": "AM = (a+b)/2", "desc": "Arithmetic mean of two numbers"},
                    {"name": "GM", "formula": "GM = √(ab)", "desc": "Geometric mean"},
                    {"name": "HM", "formula": "HM = 2ab/(a+b)", "desc": "Harmonic mean"},
                    {"name": "AM ≥ GM ≥ HM", "formula": "(a+b)/2 ≥ √(ab) ≥ 2ab/(a+b)", "desc": "Important inequality"},
                ]
            }
        ]
    },

    "Binomial Theorem": {
        "intro": "Binomial theorem gives the expansion of (a+b)ⁿ without repeated multiplication.",
        "sections": [
            {
                "name": "Binomial Expansion",
                "formulas": [
                    {"name": "General Formula", "formula": "(a+b)ⁿ = Σ C(n,r)·aⁿ⁻ʳ·bʳ for r=0 to n", "desc": "Sum of all terms"},
                    {"name": "General Term", "formula": "T_{r+1} = C(n,r)·aⁿ⁻ʳ·bʳ", "desc": "(r+1)th term in expansion"},
                    {"name": "Number of Terms", "formula": "Total terms = n+1", "desc": "Always one more than power"},
                    {"name": "Middle Term (even n)", "formula": "T_{n/2+1} is the middle term", "desc": ""},
                    {"name": "Binomial Coefficient", "formula": "C(n,r) = n! / (r!(n-r)!)", "desc": "Number of ways to choose r from n"},
                    {"name": "Pascal's Triangle", "formula": "C(n,r) = C(n-1,r-1) + C(n-1,r)", "desc": "Recurrence relation"},
                    {"name": "Sum of Coefficients", "formula": "C(n,0)+C(n,1)+...+C(n,n) = 2ⁿ", "desc": "Put a=b=1"},
                ]
            }
        ]
    },

    "Mensuration": {
        "intro": "Mensuration deals with measurement of areas, volumes, and surface areas of geometric shapes.",
        "sections": [
            {
                "name": "2D Shapes",
                "formulas": [
                    {"name": "Circle Area", "formula": "A = πr²", "desc": ""},
                    {"name": "Circle Circumference", "formula": "C = 2πr = πd", "desc": ""},
                    {"name": "Sector Area", "formula": "A = (θ/360°)×πr²", "desc": "θ in degrees"},
                    {"name": "Arc Length", "formula": "L = (θ/360°)×2πr", "desc": ""},
                    {"name": "Triangle Area (base-height)", "formula": "A = ½ × base × height", "desc": ""},
                    {"name": "Triangle Area (Heron's)", "formula": "A = √[s(s-a)(s-b)(s-c)], s=(a+b+c)/2", "desc": "When all sides known"},
                    {"name": "Parallelogram", "formula": "A = base × height", "desc": ""},
                    {"name": "Trapezium", "formula": "A = ½ × (sum of parallel sides) × height", "desc": ""},
                    {"name": "Rhombus", "formula": "A = ½ × d₁ × d₂", "desc": "Product of diagonals ÷ 2"},
                ]
            },
            {
                "name": "3D Solids",
                "formulas": [
                    {"name": "Cube Volume", "formula": "V = a³", "desc": ""},
                    {"name": "Cube Surface Area", "formula": "TSA = 6a²", "desc": ""},
                    {"name": "Cuboid Volume", "formula": "V = l × b × h", "desc": ""},
                    {"name": "Cuboid TSA", "formula": "TSA = 2(lb + bh + hl)", "desc": ""},
                    {"name": "Cylinder Volume", "formula": "V = πr²h", "desc": ""},
                    {"name": "Cylinder CSA", "formula": "CSA = 2πrh", "desc": "Curved surface area"},
                    {"name": "Cylinder TSA", "formula": "TSA = 2πr(r+h)", "desc": ""},
                    {"name": "Cone Volume", "formula": "V = ⅓πr²h", "desc": "One-third of cylinder"},
                    {"name": "Cone CSA", "formula": "CSA = πrl", "desc": "l = slant height = √(r²+h²)"},
                    {"name": "Cone TSA", "formula": "TSA = πr(r+l)", "desc": ""},
                    {"name": "Sphere Volume", "formula": "V = (4/3)πr³", "desc": ""},
                    {"name": "Sphere Surface Area", "formula": "A = 4πr²", "desc": ""},
                    {"name": "Hemisphere Volume", "formula": "V = (2/3)πr³", "desc": "Half of sphere"},
                    {"name": "Hemisphere TSA", "formula": "TSA = 3πr²", "desc": "CSA + base circle"},
                ]
            }
        ]
    },

    "Exponents": {
        "intro": "Exponents represent repeated multiplication. Laws of exponents simplify complex expressions.",
        "sections": [
            {
                "name": "Laws of Exponents",
                "formulas": [
                    {"name": "Product Law", "formula": "aᵐ × aⁿ = aᵐ⁺ⁿ", "desc": "Same base, add powers"},
                    {"name": "Quotient Law", "formula": "aᵐ / aⁿ = aᵐ⁻ⁿ", "desc": "Same base, subtract powers"},
                    {"name": "Power Law", "formula": "(aᵐ)ⁿ = aᵐⁿ", "desc": "Power of a power, multiply"},
                    {"name": "Product Base", "formula": "(ab)ⁿ = aⁿbⁿ", "desc": "Distribute over multiplication"},
                    {"name": "Quotient Base", "formula": "(a/b)ⁿ = aⁿ/bⁿ", "desc": "Distribute over division"},
                    {"name": "Zero Power", "formula": "a⁰ = 1, a ≠ 0", "desc": "Anything to power 0 is 1"},
                    {"name": "Negative Power", "formula": "a⁻ⁿ = 1/aⁿ", "desc": "Negative exponent = reciprocal"},
                    {"name": "Fractional Power", "formula": "a^(m/n) = ⁿ√(aᵐ) = (ⁿ√a)ᵐ", "desc": "Fractional exponent = root"},
                ]
            }
        ]
    },

    "Polynomials": {
        "intro": "Polynomials are expressions with variables and coefficients involving addition, subtraction, multiplication and exponents.",
        "sections": [
            {
                "name": "Polynomial Theorems",
                "formulas": [
                    {"name": "Remainder Theorem", "formula": "When p(x) divided by (x-a), remainder = p(a)", "desc": ""},
                    {"name": "Factor Theorem", "formula": "(x-a) is factor of p(x) ↔ p(a) = 0", "desc": ""},
                    {"name": "Division Algorithm", "formula": "p(x) = g(x)·q(x) + r(x)", "desc": "Dividend = Divisor × Quotient + Remainder"},
                    {"name": "Relation between zeros and coefficients (quadratic)", "formula": "α+β = -b/a, αβ = c/a", "desc": "For ax²+bx+c"},
                    {"name": "Relation between zeros (cubic)", "formula": "α+β+γ = -b/a, αβ+βγ+αγ = c/a, αβγ = -d/a", "desc": "For ax³+bx²+cx+d"},
                ]
            }
        ]
    },

    "Linear Equations in Two Variables": {
        "intro": "Two linear equations in two unknowns can be solved simultaneously using multiple methods.",
        "sections": [
            {
                "name": "Solution Methods",
                "formulas": [
                    {"name": "Substitution", "formula": "Solve one equation for x, substitute into other", "desc": ""},
                    {"name": "Elimination", "formula": "Add/subtract equations to eliminate one variable", "desc": ""},
                    {"name": "Cross Multiplication", "formula": "x/(b₁c₂-b₂c₁) = y/(c₁a₂-c₂a₁) = 1/(a₁b₂-a₂b₁)", "desc": "Direct formula for a₁x+b₁y+c₁=0"},
                    {"name": "Consistency Conditions", "formula": "a₁/a₂ ≠ b₁/b₂: unique solution | a₁/a₂ = b₁/b₂ = c₁/c₂: infinite | a₁/a₂ = b₁/b₂ ≠ c₁/c₂: no solution", "desc": ""},
                ]
            }
        ]
    },

    "Ratio & Proportion": {
        "intro": "Ratio compares two quantities; proportion states two ratios are equal.",
        "sections": [
            {
                "name": "Key Formulas",
                "formulas": [
                    {"name": "Ratio", "formula": "a:b = a/b", "desc": "Comparison of two quantities"},
                    {"name": "Proportion", "formula": "a:b = c:d ↔ ad = bc (cross product)", "desc": ""},
                    {"name": "Mean Proportion", "formula": "b = √(ac) if a:b = b:c", "desc": "b is mean proportional"},
                    {"name": "Third Proportional", "formula": "c = b²/a if a:b = b:c", "desc": ""},
                    {"name": "Direct Proportion", "formula": "x/y = k (constant) → x ∝ y", "desc": ""},
                    {"name": "Inverse Proportion", "formula": "xy = k → x ∝ 1/y", "desc": ""},
                    {"name": "Componendo Dividendo", "formula": "If a/b=c/d then (a+b)/(a-b) = (c+d)/(c-d)", "desc": ""},
                ]
            }
        ]
    },

    "Measurement": {
        "intro": "Measurement involves converting between units and calculating physical quantities.",
        "sections": [
            {
                "name": "Conversion Formulas",
                "formulas": [
                    {"name": "Length", "formula": "1 km = 1000 m = 100000 cm = 1000000 mm", "desc": ""},
                    {"name": "Mass", "formula": "1 kg = 1000 g | 1 tonne = 1000 kg", "desc": ""},
                    {"name": "Volume", "formula": "1 L = 1000 mL = 1000 cm³", "desc": ""},
                    {"name": "Temperature C to F", "formula": "°F = (°C × 9/5) + 32", "desc": ""},
                    {"name": "Temperature F to C", "formula": "°C = (°F - 32) × 5/9", "desc": ""},
                    {"name": "Speed", "formula": "Speed = Distance / Time", "desc": ""},
                    {"name": "km/h to m/s", "formula": "× 5/18", "desc": "Multiply by 5/18"},
                    {"name": "m/s to km/h", "formula": "× 18/5", "desc": "Multiply by 18/5"},
                ]
            }
        ]
    },

    "Money": {
        "intro": "Mathematical concepts applied to financial calculations including interest, profit, and discount.",
        "sections": [
            {
                "name": "Profit & Loss",
                "formulas": [
                    {"name": "Profit", "formula": "Profit = SP - CP (when SP > CP)", "desc": ""},
                    {"name": "Loss", "formula": "Loss = CP - SP (when CP > SP)", "desc": ""},
                    {"name": "Profit %", "formula": "Profit% = (Profit/CP) × 100", "desc": ""},
                    {"name": "Loss %", "formula": "Loss% = (Loss/CP) × 100", "desc": ""},
                    {"name": "SP from profit%", "formula": "SP = CP × (100+P%)/100", "desc": ""},
                    {"name": "SP from loss%", "formula": "SP = CP × (100-L%)/100", "desc": ""},
                    {"name": "CP from SP & profit%", "formula": "CP = SP × 100/(100+P%)", "desc": ""},
                ]
            },
            {
                "name": "Interest",
                "formulas": [
                    {"name": "Simple Interest", "formula": "SI = PRT/100", "desc": "P=principal, R=rate%, T=time(years)"},
                    {"name": "Amount (SI)", "formula": "A = P + SI = P(1 + RT/100)", "desc": ""},
                    {"name": "Compound Interest", "formula": "A = P(1 + R/100)ⁿ", "desc": "n = number of years"},
                    {"name": "CI", "formula": "CI = A - P = P[(1+R/100)ⁿ - 1]", "desc": ""},
                    {"name": "Half-yearly CI", "formula": "A = P(1 + R/200)^(2n)", "desc": "Rate halved, time doubled"},
                    {"name": "Quarterly CI", "formula": "A = P(1 + R/400)^(4n)", "desc": "Rate quartered, time × 4"},
                ]
            },
            {
                "name": "Discount",
                "formulas": [
                    {"name": "Discount", "formula": "Discount = Marked Price - Selling Price", "desc": ""},
                    {"name": "Discount %", "formula": "Discount% = (Discount/MP) × 100", "desc": "On marked price"},
                    {"name": "SP after discount", "formula": "SP = MP × (100-D%)/100", "desc": ""},
                ]
            }
        ]
    },

    "Number System": {
        "intro": "Different bases for representing numbers — binary (2), octal (8), decimal (10), hexadecimal (16).",
        "sections": [
            {
                "name": "Conversion Formulas",
                "formulas": [
                    {"name": "Decimal to Binary", "formula": "Divide by 2 repeatedly, read remainders bottom-up", "desc": ""},
                    {"name": "Binary to Decimal", "formula": "Σ (digit × 2^position), rightmost position = 0", "desc": ""},
                    {"name": "Decimal to Octal", "formula": "Divide by 8 repeatedly, read remainders bottom-up", "desc": ""},
                    {"name": "Decimal to Hex", "formula": "Divide by 16 repeatedly, use A-F for 10-15", "desc": ""},
                    {"name": "Binary to Hex", "formula": "Group 4 binary digits from right, convert each group", "desc": ""},
                    {"name": "Hex to Binary", "formula": "Each hex digit = 4 binary digits", "desc": ""},
                ]
            }
        ]
    },

    "Data Handling": {
        "intro": "Data handling involves collecting, organizing, and representing data using graphs and tables.",
        "sections": [
            {
                "name": "Statistical Measures",
                "formulas": [
                    {"name": "Mean (grouped)", "formula": "x̄ = Σfᵢxᵢ / Σfᵢ", "desc": "f=frequency, x=class midpoint"},
                    {"name": "Median (grouped)", "formula": "M = L + [(n/2 - cf)/f] × h", "desc": "L=lower boundary, cf=cumulative freq, h=class width"},
                    {"name": "Mode (grouped)", "formula": "Mode = L + [(f₁-f₀)/(2f₁-f₀-f₂)] × h", "desc": "f₁=modal freq, f₀=before, f₂=after"},
                ]
            }
        ]
    },

    "3D Geometry": {
        "intro": "3D geometry extends coordinate geometry to three-dimensional space.",
        "sections": [
            {
                "name": "3D Distance and Direction",
                "formulas": [
                    {"name": "Distance Formula", "formula": "d = √[(x₂-x₁)²+(y₂-y₁)²+(z₂-z₁)²]", "desc": ""},
                    {"name": "Direction Cosines", "formula": "l=cosα, m=cosβ, n=cosγ, l²+m²+n²=1", "desc": "α,β,γ angles with x,y,z axes"},
                    {"name": "Direction Ratios", "formula": "l:m:n = a:b:c (proportional to direction cosines)", "desc": ""},
                ]
            },
            {
                "name": "Lines and Planes in 3D",
                "formulas": [
                    {"name": "Line (vector form)", "formula": "r⃗ = a⃗ + λb⃗", "desc": "a⃗=point on line, b⃗=direction"},
                    {"name": "Line (symmetric)", "formula": "(x-x₁)/l = (y-y₁)/m = (z-z₁)/n", "desc": ""},
                    {"name": "Plane (vector form)", "formula": "r⃗·n̂ = d", "desc": "n̂=unit normal, d=distance from origin"},
                    {"name": "Plane (cartesian)", "formula": "ax + by + cz + d = 0", "desc": "(a,b,c) is normal vector"},
                    {"name": "Distance: Point to Plane", "formula": "d = |ax₁+by₁+cz₁+d| / √(a²+b²+c²)", "desc": ""},
                    {"name": "Angle between planes", "formula": "cosθ = |n₁⃗·n₂⃗| / (|n₁||n₂|)", "desc": ""},
                ]
            }
        ]
    },

    "Applications of Derivatives": {
        "intro": "Derivatives have powerful applications in finding maxima, minima, rates of change, and approximations.",
        "sections": [
            {
                "name": "Rate of Change",
                "formulas": [
                    {"name": "Rate of Change", "formula": "dy/dx = rate of change of y w.r.t. x", "desc": ""},
                    {"name": "Related Rates", "formula": "dA/dt = (dA/dr)·(dr/dt)", "desc": "Chain rule for time-dependent problems"},
                ]
            },
            {
                "name": "Maxima and Minima",
                "formulas": [
                    {"name": "Critical Points", "formula": "f'(x) = 0 or f'(x) undefined", "desc": "Find these first"},
                    {"name": "Second Derivative Test", "formula": "f''(x)<0: local max | f''(x)>0: local min | f''(x)=0: inconclusive", "desc": ""},
                    {"name": "First Derivative Test", "formula": "f' changes +→-: max | f' changes -→+: min", "desc": ""},
                ]
            },
            {
                "name": "Tangent and Normal",
                "formulas": [
                    {"name": "Slope of Tangent", "formula": "m_tangent = dy/dx at point (x₁,y₁)", "desc": ""},
                    {"name": "Slope of Normal", "formula": "m_normal = -1/(dy/dx)", "desc": "Perpendicular to tangent"},
                    {"name": "Tangent Equation", "formula": "y-y₁ = m(x-x₁)", "desc": "Point-slope form"},
                ]
            }
        ]
    },

    "Continuity & Differentiability": {
        "intro": "Continuity means no breaks in a function. Differentiability means a smooth, well-defined slope exists.",
        "sections": [
            {
                "name": "Conditions",
                "formulas": [
                    {"name": "Continuity at x=a", "formula": "lim(x→a⁻)f(x) = lim(x→a⁺)f(x) = f(a)", "desc": "Left limit = Right limit = Function value"},
                    {"name": "Differentiability at x=a", "formula": "lim(h→0) [f(a+h)-f(a)]/h exists", "desc": "Derivative exists"},
                    {"name": "Key Theorem", "formula": "Differentiable → Continuous (but not vice versa)", "desc": ""},
                    {"name": "Rolle's Theorem", "formula": "If f continuous on [a,b], differentiable on (a,b), f(a)=f(b) → ∃c: f'(c)=0", "desc": ""},
                    {"name": "Mean Value Theorem", "formula": "∃c ∈ (a,b): f'(c) = [f(b)-f(a)]/(b-a)", "desc": ""},
                ]
            }
        ]
    },

    "Geometry Basics": {
        "intro": "Basic geometry deals with points, lines, angles, and fundamental 2D shapes.",
        "sections": [
            {
                "name": "Angles",
                "formulas": [
                    {"name": "Angles on a line", "formula": "Sum of angles on straight line = 180°", "desc": ""},
                    {"name": "Angles at a point", "formula": "Sum of all angles at a point = 360°", "desc": ""},
                    {"name": "Vertically opposite", "formula": "Vertically opposite angles are equal", "desc": ""},
                    {"name": "Complementary", "formula": "Two angles summing to 90°", "desc": ""},
                    {"name": "Supplementary", "formula": "Two angles summing to 180°", "desc": ""},
                    {"name": "Triangle Angle Sum", "formula": "∠A + ∠B + ∠C = 180°", "desc": ""},
                    {"name": "Exterior Angle", "formula": "Exterior angle = sum of two non-adjacent interior angles", "desc": ""},
                ]
            },
            {
                "name": "Pythagoras Theorem",
                "formulas": [
                    {"name": "Pythagoras", "formula": "c² = a² + b² (hypotenuse² = sum of squares of other sides)", "desc": "Only for right-angled triangles"},
                    {"name": "Pythagorean Triplets", "formula": "(3,4,5), (5,12,13), (8,15,17), (7,24,25)", "desc": "Common right triangle sides"},
                ]
            }
        ]
    },

    "Fractions, Decimals, Percentages": {
        "intro": "These three representations of parts of a whole are interchangeable and fundamental to real-world math.",
        "sections": [
            {
                "name": "Conversion Formulas",
                "formulas": [
                    {"name": "Fraction → Decimal", "formula": "Divide numerator by denominator", "desc": ""},
                    {"name": "Decimal → Fraction", "formula": "Write digits over 10^(decimal places) and simplify", "desc": "e.g., 0.75 = 75/100 = 3/4"},
                    {"name": "Fraction → Percent", "formula": "Multiply by 100%", "desc": "e.g., 3/4 = 75%"},
                    {"name": "Percent → Fraction", "formula": "Divide by 100 and simplify", "desc": "e.g., 35% = 35/100 = 7/20"},
                    {"name": "Decimal → Percent", "formula": "Multiply by 100", "desc": "e.g., 0.75 → 75%"},
                    {"name": "Percentage of a number", "formula": "x% of N = (x/100) × N", "desc": ""},
                    {"name": "What % is A of B", "formula": "(A/B) × 100", "desc": ""},
                    {"name": "Percentage Change", "formula": "((New - Old) / Old) × 100%", "desc": "Positive = increase, Negative = decrease"},
                ]
            }
        ]
    }
}

def get_formulas(topic):
    """Get formulas for a specific topic"""
    return FORMULA_DATABASE.get(topic, None)

def get_all_topics():
    """Get all available topics"""
    return list(FORMULA_DATABASE.keys())

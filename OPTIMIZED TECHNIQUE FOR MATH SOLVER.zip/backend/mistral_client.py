from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Generator

import requests
from dotenv import load_dotenv

MISTRAL_CHAT_API = 'https://api.mistral.ai/v1/chat/completions'
BASE_DIR = Path(__file__).resolve().parent.parent


def _load_runtime_config() -> None:
    candidates = [BASE_DIR / '.env', BASE_DIR / 'backend' / '.env']
    for cand in candidates:
        if cand.exists():
            load_dotenv(cand, override=True)
    for cand in [BASE_DIR / 'secrets.json', BASE_DIR / 'backend' / 'secrets.json']:
        if cand.exists():
            try:
                data = json.loads(cand.read_text(encoding='utf-8'))
                for k, v in data.items():
                    if v is not None and str(v) != '':
                        os.environ.setdefault(str(k), str(v))
                        os.environ[str(k)] = str(v)
            except Exception:
                pass


def config_status() -> dict[str, Any]:
    _load_runtime_config()
    api_key = os.getenv('MISTRAL_API_KEY')
    return {
        'env_loaded': True,
        'mistral_key_present': bool(api_key),
        'model': os.getenv('MISTRAL_MODEL', 'mistral-large-latest'),
        'ocr_model': os.getenv('MISTRAL_OCR_MODEL', 'pixtral-12b-2409'),
    }


def _headers(api_key: str) -> dict[str, str]:
    return {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }


def _extract_json(text: str) -> dict[str, Any]:
    text = (text or '').strip()
    fenced = re.search(r'```json\s*(\{.*\})\s*```', text, flags=re.S)
    if fenced:
        text = fenced.group(1)
    else:
        m = re.search(r'(\{.*\})', text, flags=re.S)
        if m:
            text = m.group(1)
    return json.loads(text)


def _common_payload(
    *,
    question: str,
    topic: str,
    difficulty: str,
    question_type: str,
    formulas: list[dict[str, Any]],
    similar_examples: list[dict[str, Any]],
    doc_chunks: list[dict[str, Any]],
    parser_result: dict[str, Any] | None,
    allow_general: bool = True,
    prompt_style: str = 'detailed',
) -> tuple[str, str]:
    formula_lines = '\n'.join(
        f"- {f.get('name','Formula')}: {f.get('formula','')} | {f.get('meaning', f.get('desc',''))}"
        for f in formulas[:8]
    ) or '- No curated formulas matched.'
    example_lines = '\n'.join(
        f"- Example: {row.get('question','')} | Topic: {row.get('topic','')} | Type: {row.get('question_type','')}"
        for row in similar_examples[:3]
    ) or '- No similar training examples found.'
    doc_lines = '\n'.join(
        f"- Source: {c.get('source','')} | Type: {c.get('doc_type','')} | Topic: {c.get('topic','')} | Text: {c.get('text','')[:500]}"
        for c in doc_chunks[:4]
    ) or '- No document chunks retrieved.'
    parser_text = json.dumps(parser_result, ensure_ascii=False, indent=2) if parser_result else 'null'

    system = (
        'You are the reasoning engine inside a math learning system. '
        'Return ONLY valid JSON with these keys: '
        'topic, subtopic, difficulty, problem_restatement, what_we_know, what_we_find, approach, steps, final_answer, unit, verification, shortcut, formulas_used, real_world_use, common_mistakes, practice_problems. '
        'steps must be an array of objects with step_number, title, why, working, result, note. '
        'formulas_used must be an array of objects with name, formula, why_used. '
        'Do not use markdown fences.'
    )
    user = f"""
Question: {question}
Predicted topic from local ML: {topic}
Predicted difficulty from local ML: {difficulty}
Predicted question type from local ML: {question_type}
Preferred explanation style from RL policy: {prompt_style}
Allow solving unseen problems outside local dataset: {allow_general}

Curated formulas retrieved by local system:
{formula_lines}

Most similar local training examples:
{example_lines}

Classical document-RAG chunks retrieved by local system:
{doc_lines}

Custom parser result from local engine (may be null or partial):
{parser_text}

Use the retrieved document chunks as grounding context when relevant. Use the local formulas and parser result when relevant, but correct them if needed. Explain clearly for a beginner. Return strict JSON only.
"""
    return system, user


def _get_api_key() -> str:
    _load_runtime_config()
    api_key = os.getenv('MISTRAL_API_KEY')
    if not api_key:
        raise RuntimeError('Mistral API key not configured. Set MISTRAL_API_KEY in .env.')
    return api_key


def solve_with_mistral(**kwargs) -> dict[str, Any]:
    api_key = _get_api_key()
    model = os.getenv('MISTRAL_MODEL', 'mistral-large-latest')
    system, user = _common_payload(**kwargs)
    resp = requests.post(
        MISTRAL_CHAT_API,
        headers=_headers(api_key),
        json={
            'model': model,
            'temperature': 0.2,
            'response_format': {'type': 'json_object'},
            'messages': [
                {'role': 'system', 'content': system},
                {'role': 'user', 'content': user},
            ],
        },
        timeout=120,
    )
    if not resp.ok:
        raise RuntimeError(f'Mistral API error {resp.status_code}: {resp.text}')
    data = resp.json()
    text = (((data.get('choices') or [{}])[0].get('message') or {}).get('content') or '').strip()
    return _extract_json(text)


def stream_solve_with_mistral(**kwargs) -> Generator[dict[str, Any], None, dict[str, Any]]:
    parsed = solve_with_mistral(**kwargs)
    for step in parsed.get('steps', []) or []:
        yield {'type': 'step', 'step': step}
    return parsed


def extract_text_with_mistral_vision(image_b64: str, media_type: str = 'image/png') -> str:
    api_key = _get_api_key()
    model = os.getenv('MISTRAL_OCR_MODEL', 'pixtral-12b-2409')
    payload = {
        'model': model,
        'temperature': 0,
        'messages': [{
            'role': 'user',
            'content': [
                {'type': 'text', 'text': 'Extract only the mathematical problem from this image. Return just the text.'},
                {'type': 'image_url', 'image_url': f'data:{media_type};base64,{image_b64}'},
            ],
        }],
    }
    resp = requests.post(MISTRAL_CHAT_API, headers=_headers(api_key), json=payload, timeout=120)
    if not resp.ok:
        raise RuntimeError(f'Mistral vision API error {resp.status_code}: {resp.text}')
    data = resp.json()
    text = (((data.get('choices') or [{}])[0].get('message') or {}).get('content') or '').strip()
    return text

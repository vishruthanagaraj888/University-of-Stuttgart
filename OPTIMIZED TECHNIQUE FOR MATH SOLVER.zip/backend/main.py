from __future__ import annotations

import json
import random
import re
import shutil
import uuid
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .auth_utils import (
    _hash_password,
    change_password_with_otp,
    ensure_default_users,
    login_user,
    send_password_change_otp,
    update_profile,
)
from .mistral_client import solve_with_mistral, stream_solve_with_mistral, config_status
from .db import (
    add_feedback,
    add_history,
    add_practice_result,
    add_video,
    clear_otp,
    compute_user_stats,
    delete_all_history,
    delete_history_item,
    delete_user_account,
    create_user,
    get_history_item,
    get_latest_otp,
    get_prompt_strategy_rows,
    get_user_by_email,
    get_user_by_username,
    init_db,
    list_history as db_list_history,
    list_videos as db_list_videos,
    save_otp,
    set_history_rating,
)
from .jwt_utils import create_token, optional_user, required_user, verify_token
from .ml_training import TRAIN_REPORT, ensure_models, predict_meta, retrieval_novelty, retrieve_doc_chunks, retrieve_similar_examples, train_all
from .ocr_utils import extract_text, extract_text_details
from .rl_policy import choose_prompt_style, policy_snapshot
from .solver_engine import solve as custom_solve, sympy_fallback_json
from .storage import BASE_DIR, UPLOADS_DIR, VIDEOS_DIR
from .smtp_utils import load_smtp_config, send_email

load_dotenv(BASE_DIR / '.env', override=True)

app = FastAPI(title='Math Solver')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

frontend_dir = BASE_DIR / 'frontend'
app.mount('/static', StaticFiles(directory=str(frontend_dir)), name='static')
app.mount('/videos', StaticFiles(directory=str(VIDEOS_DIR)), name='videos')

TOPIC_CATALOG_PATH = BASE_DIR / 'data' / 'topic_catalog.json'
TOPIC_LABELS_PATH = BASE_DIR / 'data' / 'topic_labels.json'
FORMULAS_PATH = BASE_DIR / 'data' / 'formulas.json'
PSEUDO_LABELS_PATH = BASE_DIR / 'artifacts' / 'pseudo_labels.json'

@app.on_event('startup')
def startup():
    init_db()
    ensure_default_users()
    ensure_models()
    _ensure_bundled_videos()


@app.get('/')
def root():
    return FileResponse(frontend_dir / 'index.html')




def _ensure_bundled_videos() -> None:
    bundled = {
        'addition.mp4': 'Addition',
        'subtraction.mp4': 'Subtraction',
        'multiplication.mp4': 'Multiplication',
        'algebra.mp4': 'Algebra',
        'percentage.mp4': 'Percentage',
    }
    existing_urls = {item.get('url') for item in db_list_videos()}
    for filename, topic in bundled.items():
        path = VIDEOS_DIR / filename
        url = f'/videos/{filename}'
        if path.exists() and url not in existing_urls:
            add_video(topic, filename, url)


init_db()
ensure_default_users()
ensure_models()
_ensure_bundled_videos()

def _load_labels() -> dict:
    return json.loads(TOPIC_LABELS_PATH.read_text(encoding='utf-8')) if TOPIC_LABELS_PATH.exists() else {}


def _topics_flat() -> list[dict]:
    raw = json.loads(TOPIC_CATALOG_PATH.read_text(encoding='utf-8'))
    labels = _load_labels()
    out = []
    for stage, items in raw.items():
        for key, aliases in items.items():
            out.append({'stage': stage, 'key': key, 'label': labels.get(key, key.replace('_', ' ').title()), 'aliases': aliases})
    return out



def _rand_non_zero(a: int, b: int) -> int:
    value = 0
    while value == 0:
        value = random.randint(a, b)
    return value


def _practice_question_for_topic(topic: str) -> str:
    t = (topic or '').lower()
    if 'arithmetic' in t or 'numbers' in t or 'counting' in t:
        a, b = random.randint(12, 999), random.randint(12, 999)
        return random.choice([
            f'What is {a} + {b}?',
            f'What is {max(a,b)} - {min(a,b)}?',
            f'Find {random.randint(11,99)} × {random.randint(2,25)}.',
            f'Compute {random.randint(84,999)} ÷ {random.randint(2,12)}.'
        ])
    if 'fraction' in t or 'decimal' in t:
        a,b,c,d = random.randint(1,9), random.randint(2,12), random.randint(1,9), random.randint(2,12)
        return random.choice([
            f'Simplify {a}/{b} + {c}/{d}.',
            f'Simplify {a}/{b} - {c}/{d}.',
            f'Multiply {a}/{b} and {c}/{d}.'
        ])
    if 'percentage' in t:
        p = random.choice([5,10,12,15,20,25,30,40,50,75])
        n = random.randint(80, 1200)
        return random.choice([
            f'Find {p}% of {n}.',
            f'After a {p}% discount, what is the sale price of an item costing {n}?'
        ])
    if 'ratio' in t or 'proportion' in t:
        a,b = random.randint(1,12), random.randint(1,12)
        x = random.randint(2,20)
        return random.choice([
            f'Simplify the ratio {a*x}:{b*x}.',
            f'If {a}/{b} = x/{random.randint(2,20)}, find x.'
        ])
    if 'linear_equations_two_variables' in t:
        x,y = random.randint(1,8), random.randint(1,8)
        a1,b1 = random.randint(1,6), random.randint(1,6)
        a2,b2 = random.randint(1,6), random.randint(1,6)
        c1, c2 = a1*x+b1*y, a2*x+b2*y
        return f'Solve the system: {a1}x + {b1}y = {c1}, {a2}x + {b2}y = {c2}.'
    if 'linear' in t or 'algebra' in t:
        x = random.randint(-12, 12)
        a = _rand_non_zero(2, 12)
        b = random.randint(-20, 20)
        c = a*x + b
        return f'Solve {a}x + ({b}) = {c}.'
    if 'quadratic' in t:
        r1, r2 = random.randint(-9,9), random.randint(-9,9)
        b = -(r1+r2)
        c = r1*r2
        return f'Solve x^2 + ({b})x + ({c}) = 0.'
    if 'ap' in t or 'progression' in t or 'sequence' in t or 'series' in t:
        a,d,n = random.randint(1,20), random.randint(1,10), random.randint(5,25)
        return random.choice([
            f'Find the {n}th term of an AP with first term {a} and common difference {d}.',
            f'Find the sum of the first {n} terms of an AP with first term {a} and common difference {d}.'
        ])
    if 'trig' in t:
        ang = random.choice([0, 30, 45, 60, 90])
        return random.choice([f'Find sin {ang}°.', f'Find cos {ang}°.', f'Find tan {ang}°.'])
    if 'coordinate' in t or 'straight_lines' in t:
        x1,y1,x2,y2 = random.randint(-6,6), random.randint(-6,6), random.randint(-6,6), random.randint(-6,6)
        while x1 == x2 and y1 == y2:
            x2,y2 = random.randint(-6,6), random.randint(-6,6)
        return random.choice([
            f'Find the slope of the line passing through ({x1},{y1}) and ({x2},{y2}).',
            f'Find the distance between ({x1},{y1}) and ({x2},{y2}).'
        ])
    if 'derivative' in t or 'differentiation' in t or 'applications_of_derivatives' in t:
        n = random.randint(2,8)
        c = random.randint(1,12)
        return random.choice([
            f'Differentiate {c}x^{n}.',
            f'Differentiate x^{n} + {c}x.',
            f'Find d/dx of sin x + x^{n}.'
        ])
    if 'integral' in t or 'integration' in t:
        n = random.randint(1,6)
        return random.choice([
            f'Integrate x^{n} with respect to x.',
            f'Evaluate ∫ from 0 to 2 of x^{n} dx.'
        ])
    if 'matrix' in t or 'determinant' in t:
        a,b,c,d = [random.randint(1,8) for _ in range(4)]
        return random.choice([
            f'Find the determinant of [[{a},{b}],[{c},{d}]].',
            f'Find the inverse of matrix [[{a},{b}],[{c},{d}]].'
        ])
    if 'vector' in t or '3d' in t:
        u = [random.randint(1,6) for _ in range(3)]
        v = [random.randint(1,6) for _ in range(3)]
        return random.choice([
            f'Find the dot product of vectors {tuple(u)} and {tuple(v)}.',
            f'Find the magnitude of vector {tuple(u)}.'
        ])
    if 'probability' in t:
        r = random.randint(1,6)
        return random.choice([
            f'A fair die is rolled once. What is the probability of getting {r}?',
            f'A coin is tossed twice. What is the probability of getting exactly one head?'
        ])
    if 'differential_equations' in t:
        a = random.randint(1,5)
        return f'Solve dy/dx = {a}x.'
    if 'complex' in t:
        a,b = random.randint(1,9), random.randint(1,9)
        return f'Find the modulus of {a} + {b}i.'
    if 'limits' in t or 'continuity' in t:
        a = random.randint(1,8)
        return f'Find lim as x approaches {a} of (x^2 - {a*a})/(x - {a}).'
    return f'Generate and solve a practice question from {topic}.'


def _formulas_db() -> dict:
    return json.loads(FORMULAS_PATH.read_text(encoding='utf-8')) if FORMULAS_PATH.exists() else {}


def _topic_formula_items(topic_key: str) -> list[dict]:
    db = _formulas_db()
    topic = db.get(topic_key)
    if not topic:
        return []
    if isinstance(topic, dict) and 'sections' in topic:
        items = []
        for section in topic.get('sections', []):
            for f in section.get('formulas', []):
                items.append({
                    'section': section.get('name', ''),
                    'name': f.get('name', ''),
                    'formula': f.get('formula', ''),
                    'meaning': f.get('desc', ''),
                    'desc': f.get('desc', ''),
                    'example': f.get('example', ''),
                })
        return items
    if isinstance(topic, list):
        return list(topic)
    return []



def _formula_matches(topic_key: str, question: str, limit: int = 8) -> list[dict]:
    items = _topic_formula_items(topic_key)
    q = question.lower()
    scored = []
    for item in items:
        txt = ' '.join([item.get('section',''), item.get('name', ''), item.get('formula', ''), item.get('meaning', ''), item.get('example', '')]).lower()
        score = sum(1 for token in q.split() if token in txt)
        scored.append((score, item))
    scored.sort(key=lambda x: (-x[0], x[1].get('name', '')))
    return [item for score, item in scored[:limit] if score > 0] or items[: min(limit, len(items))]


def _store_pseudo_label(question: str, meta: dict):
    if meta.get('topic_confidence', 0) < 0.85:
        return False
    if retrieval_novelty(question) > 0.92:
        return False
    rows = []
    if PSEUDO_LABELS_PATH.exists():
        try:
            rows = json.loads(PSEUDO_LABELS_PATH.read_text(encoding='utf-8'))
        except Exception:
            rows = []
    rows.append({'question': question, 'topic': meta.get('topic'), 'difficulty': meta.get('difficulty'), 'timestamp': datetime.now(timezone.utc).isoformat()})
    rows = rows[-500:]
    PSEUDO_LABELS_PATH.write_text(json.dumps(rows, indent=2), encoding='utf-8')
    _maybe_retrain_on_pseudo(rows)
    return True


def _maybe_retrain_on_pseudo(rows: list[dict]):
    threshold = 10
    if len(rows) == 0 or len(rows) % threshold != 0:
        return
    try:
        report = json.loads(TRAIN_REPORT.read_text(encoding='utf-8')) if TRAIN_REPORT.exists() else {}
    except Exception:
        report = {}
    last = int(report.get('pseudo_labels_seen', 0) or 0)
    if len(rows) <= last:
        return
    new_report = train_all()
    new_report['pseudo_labels_seen'] = len(rows)
    new_report['admin_badge'] = f"Model updated with {len(rows)-last} new auto-labeled examples"
    TRAIN_REPORT.write_text(json.dumps(new_report, indent=2), encoding='utf-8')




def _validate_password_rules(password: str) -> list[str]:
    errors = []
    pwd = str(password or '')
    if len(pwd) < 8:
        errors.append('Password must be at least 8 characters.')
    if not re.search(r'[A-Z]', pwd):
        errors.append('Add at least one uppercase letter.')
    if not re.search(r'[a-z]', pwd):
        errors.append('Add at least one lowercase letter.')
    if not re.search(r'\d', pwd):
        errors.append('Add at least one number.')
    if not re.search(r'[^A-Za-z0-9]', pwd):
        errors.append('Add at least one special character.')
    if re.search(r'\s', pwd):
        errors.append('No spaces allowed.')
    return errors

def _current_prompt_style() -> str:
    return choose_prompt_style()


def _normalize_answer_text(value: str) -> str:
    return re.sub(r'\s+', ' ', str(value or '').strip()).lower()


def _validation_layers(question: str, final_payload: dict, parser_result: dict | None, selected_topic: str) -> dict:
    pre = {
        'question_non_empty': bool(question.strip()),
        'predicted_topic': selected_topic,
        'parser_available': bool(parser_result),
    }
    final_answer = str((final_payload or {}).get('final_answer', '') or '').strip()
    steps = (final_payload or {}).get('steps') or []
    post = {
        'has_final_answer': bool(final_answer),
        'has_steps': bool(steps),
        'step_count': len(steps),
        'consistency': 'unknown',
        'verified_with_local_engine': False,
    }
    if parser_result and parser_result.get('final_answer'):
        post['verified_with_local_engine'] = True
        post['local_engine_answer'] = parser_result.get('final_answer', '')
        post['consistency'] = 'match' if _normalize_answer_text(parser_result.get('final_answer')) == _normalize_answer_text(final_answer) else 'different'
    elif final_answer:
        post['consistency'] = 'available_without_local_crosscheck'
    return {'pre_validation': pre, 'post_validation': post}


def _step_obj(step_number: int, title: str, why: str, working: str, result: str = '', note: str = '') -> dict:
    return {
        'step_number': step_number,
        'title': title,
        'why': why,
        'working': working,
        'result': result,
        'note': note,
    }


def _normalize_step_objects(steps) -> list[dict]:
    out = []
    for i, step in enumerate(steps or [], start=1):
        if isinstance(step, dict):
            out.append({
                'step_number': step.get('step_number', i),
                'title': step.get('title', f'Step {i}'),
                'why': step.get('why', ''),
                'working': step.get('working', step.get('text', '')),
                'result': step.get('result', ''),
                'note': step.get('note', ''),
            })
        else:
            out.append(_step_obj(i, f'Step {i}', 'Generated from the local solving path.', str(step)))
    return out


def _build_rag_steps(question: str, parser_result: dict | None, formulas_for_prompt: list[dict], similar_examples: list[dict], doc_chunks: list[dict], final_answer: str, selected_topic: str) -> list[dict]:
    steps: list[dict] = []
    steps.append(_step_obj(1, 'Understand the question', 'Start by identifying what is given and what must be found.', question, f'Topic: {selected_topic or "auto-detected"}'))

    if formulas_for_prompt:
        f = formulas_for_prompt[0]
        steps.append(_step_obj(
            len(steps) + 1,
            'Pick the formula or method',
            'The retrieval layer matched a useful formula or solving pattern for this problem.',
            f"{f.get('name','Method')}\nFormula: {f.get('formula','')}\nMeaning: {f.get('meaning', f.get('desc',''))}",
            'Formula grounded from local RAG',
        ))

    if similar_examples:
        s = similar_examples[0]
        steps.append(_step_obj(
            len(steps) + 1,
            'Compare with a similar example',
            'A related solved example helps the explainer keep the reasoning in the correct order.',
            s.get('question',''),
            s.get('topic',''),
            f"Similarity score: {round((s.get('score', 0) or 0) * 100)}%",
        ))

    parser_steps = []
    if parser_result and parser_result.get('steps'):
        parser_steps = parser_result.get('steps') or []
    for raw in parser_steps[:6]:
        steps.append(_step_obj(
            len(steps) + 1,
            f'Work the solution',
            'This step comes from the local math solving engine and is turned into a learner-friendly explanation.',
            str(raw),
        ))

    if doc_chunks:
        chunk = doc_chunks[0]
        chunk_text = (chunk.get('text') or chunk.get('chunk') or '').strip()[:500]
        if chunk_text:
            steps.append(_step_obj(
                len(steps) + 1,
                'Explain with retrieved concept note',
                'RAG adds a short concept reminder so the OCR solution is not just a final answer.',
                chunk_text,
                'Concept support attached',
            ))

    steps.append(_step_obj(
        len(steps) + 1,
        'State the final answer',
        'After finishing the working, write the answer clearly.',
        final_answer or 'No final answer generated',
        final_answer or 'No final answer generated',
    ))
    return steps


def _ensure_rich_steps(final_payload: dict, question: str, parser_result: dict | None, formulas_for_prompt: list[dict], similar_examples: list[dict], doc_chunks: list[dict], selected_topic: str) -> dict:
    payload = dict(final_payload or {})
    steps = _normalize_step_objects(payload.get('steps') or [])
    final_answer = str(payload.get('final_answer') or (parser_result or {}).get('final_answer') or '').strip()

    too_generic = False
    if not steps:
        too_generic = True
    elif len(steps) <= 1:
        too_generic = True
    elif sum(1 for s in steps if len((s.get('working') or '').strip()) < 20) >= len(steps) - 1:
        too_generic = True

    if too_generic:
        steps = _build_rag_steps(question, parser_result, formulas_for_prompt, similar_examples, doc_chunks, final_answer, selected_topic)
    else:
        # Add a final grounding note if OCR/local solver already produced steps.
        if doc_chunks:
            chunk = doc_chunks[0]
            chunk_text = (chunk.get('text') or chunk.get('chunk') or '').strip()[:300]
            steps.append(_step_obj(
                len(steps) + 1,
                'Concept connection',
                'A retrieved note is added to connect the working with the underlying concept.',
                chunk_text,
                'RAG support used',
            ))
    payload['steps'] = steps
    if not payload.get('verification') and parser_result and parser_result.get('final_answer'):
        payload['verification'] = f"Cross-checked with local engine answer: {parser_result.get('final_answer')}"
    return payload


def _solve_pipeline(text_to_solve: str, topic_hint: str = '', username: str = 'guest', ocr_text: str = '') -> dict:
    meta = predict_meta(text_to_solve)
    selected_topic = topic_hint.strip() or meta.get('topic')
    formulas_for_prompt = _formula_matches(selected_topic, text_to_solve)
    similar_examples = retrieve_similar_examples(text_to_solve, top_k=3)
    doc_chunks = retrieve_doc_chunks(text_to_solve, top_k=4)
    novelty = retrieval_novelty(text_to_solve)
    prompt_style = _current_prompt_style()

    parser_result = None
    try:
        local = custom_solve(text_to_solve, selected_topic)
        parser_result = {
            'topic': local.topic,
            'question_type': local.question_type,
            'answer_form': local.answer_form,
            'final_answer': local.final_answer,
            'steps': local.steps,
            'confidence': local.confidence,
        }
    except Exception:
        parser_result = None

    used_solver = 'custom_engine'
    mistral_error = None
    llm = None
    try:
        llm = solve_with_mistral(
            question=text_to_solve,
            topic=selected_topic,
            difficulty=meta.get('difficulty', 'intermediate'),
            question_type=meta.get('question_type', 'conceptual'),
            formulas=formulas_for_prompt,
            similar_examples=similar_examples,
            doc_chunks=doc_chunks,
            parser_result=parser_result,
            allow_general=True,
            prompt_style=prompt_style,
        )
        used_solver = 'Mistral'
    except Exception as e:
        mistral_error = str(e)

    if llm:
        solution_json = llm
        final_answer = llm.get('final_answer') or (parser_result or {}).get('final_answer', 'No answer generated')
        steps = llm.get('steps') or (parser_result or {}).get('steps', [])
        question_type = meta.get('question_type', parser_result.get('question_type') if parser_result else 'conceptual')
        answer_form = (parser_result or {}).get('answer_form', 'worked_solution')
        verification = llm.get('verification', '')
        common_mistakes = llm.get('common_mistakes', [])
        practice_problems = llm.get('practice_problems', [])
    elif parser_result:
        solution_json = {
            'topic': selected_topic,
            'difficulty': meta.get('difficulty', 'intermediate'),
            'problem_restatement': text_to_solve,
            'what_we_know': [text_to_solve],
            'what_we_find': parser_result.get('final_answer', ''),
            'approach': 'Local parser-based solving path.',
            'steps': [{'step_number': i + 1, 'title': f'Step {i + 1}', 'why': 'Local engine step', 'working': s, 'result': '', 'note': ''} for i, s in enumerate(parser_result.get('steps', []))],
            'final_answer': parser_result.get('final_answer', ''),
            'verification': 'Generated by local custom engine.',
            'common_mistakes': [],
            'practice_problems': [],
            'formulas_used': [{'name': f.get('name', ''), 'formula': f.get('formula', ''), 'why_used': f.get('meaning', '')} for f in formulas_for_prompt[:3]],
        }
        final_answer = parser_result.get('final_answer', '')
        steps = solution_json['steps']
        question_type = parser_result.get('question_type', 'conceptual')
        answer_form = parser_result.get('answer_form', 'worked_solution')
        verification = 'Local custom engine verification.'
        common_mistakes = []
        practice_problems = []
    else:
        try:
            solution_json = sympy_fallback_json(text_to_solve, selected_topic)
            final_answer = solution_json.get('final_answer', '')
            steps = solution_json.get('steps', [])
            question_type = meta.get('question_type', 'conceptual')
            answer_form = 'worked_solution'
            verification = solution_json.get('verification', '')
            common_mistakes = solution_json.get('common_mistakes', [])
            practice_problems = solution_json.get('practice_problems', [])
            used_solver = 'SymPy Fallback'
        except Exception:
            solution_json = {
                'topic': selected_topic,
                'difficulty': meta.get('difficulty', 'intermediate'),
                'problem_restatement': text_to_solve,
                'what_we_know': [text_to_solve],
                'what_we_find': 'A solution',
                'approach': 'Formula retrieval only; external solver unavailable.',
                'steps': [],
                'final_answer': 'The system could not solve this question locally and Mistral is unavailable.',
                'verification': '',
                'common_mistakes': [],
                'practice_problems': [],
                'formulas_used': [{'name': f.get('name', ''), 'formula': f.get('formula', ''), 'why_used': f.get('meaning', '')} for f in formulas_for_prompt[:3]],
            }
            final_answer = solution_json['final_answer']
            steps = []
            question_type = meta.get('question_type', 'conceptual')
            answer_form = 'message'
            verification = ''
            common_mistakes = []
            practice_problems = []

    solution_json = _ensure_rich_steps(solution_json, text_to_solve, parser_result, formulas_for_prompt, similar_examples, doc_chunks, selected_topic)
    final_answer = solution_json.get('final_answer', final_answer)
    steps = solution_json.get('steps', steps)
    verification = solution_json.get('verification', verification)

    _store_pseudo_label(text_to_solve, meta)
    history_id = add_history({
        'username': username,
        'question': text_to_solve,
        'ocr_text': ocr_text,
        'predicted_meta': meta,
        'solver_topic': selected_topic,
        'question_type': question_type,
        'answer_form': answer_form,
        'final_answer': final_answer,
        'solution_json': solution_json,
        'solved_by': used_solver,
        'confidence': meta.get('topic_confidence', 0),
        'timestamp': datetime.now().isoformat(timespec='seconds'),
    })
    return {
        'history_id': history_id,
        'question': text_to_solve,
        'ocr_text': ocr_text,
        'solver_topic': selected_topic,
        'predicted_meta': meta,
        'prompt_style': prompt_style,
        'retrieval_similarity': novelty,
        'formula_matches': formulas_for_prompt,
        'similar_examples': similar_examples,
        'doc_chunks': doc_chunks,
        'final_answer': final_answer,
        'steps': steps,
        'verification': verification,
        'common_mistakes': common_mistakes,
        'practice_problems': practice_problems,
        'used_solver': used_solver,
        'solved_by': used_solver,
        'mistral_error': mistral_error,
        'solution_json': solution_json,
    }


@app.get('/api/health')
def api_health():
    report = json.loads(TRAIN_REPORT.read_text(encoding='utf-8')) if TRAIN_REPORT.exists() else {}
    pseudo_count = len(json.loads(PSEUDO_LABELS_PATH.read_text(encoding='utf-8'))) if PSEUDO_LABELS_PATH.exists() else 0
    status = config_status()
    smtp = load_smtp_config()
    return {'ok': True, 'models_ready': TRAIN_REPORT.exists(), 'training_report': report, 'pseudo_labels_count': pseudo_count, 'admin_badge': report.get('admin_badge',''), 'smtp_enabled': bool(smtp.get('enabled')), 'smtp_user_present': bool(smtp.get('username')), **status}
@app.get('/health')
def health_legacy():
    return api_health()

@app.post('/train')
@app.post('/api/train')
def train():
    report = train_all()
    return {'ok': True, 'report': report}


@app.post('/api/auth/send-otp')
def send_otp(email: str = Form(...)):
    try:
        email = email.strip().lower()
        if not email or '@' not in email:
            raise HTTPException(status_code=400, detail='Enter a valid email address')
        username = email.split('@')[0]
        if get_user_by_email(email):
            raise HTTPException(status_code=400, detail='Email already exists. Please login instead.')
        otp = f"{random.randint(0, 999999):06d}"
        save_otp(username, email, otp, 'register_email', (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat())
        status = send_email(email, 'MathGenius OTP', f'Your OTP is {otp}. It expires in 10 minutes.')
        if not status.get('ok'):
            raise HTTPException(status_code=500, detail=status.get('detail', 'Failed to send OTP email'))
        return {'ok': True, 'email': email, 'username': username, 'detail': 'OTP sent successfully'}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f'Send OTP failed: {e}')


@app.post('/api/auth/verify-otp')
def verify_otp(email: str = Form(...), otp: str = Form(...)):
    try:
        email = email.strip().lower()
        if not email or '@' not in email:
            raise HTTPException(status_code=400, detail='Enter a valid email address')
        username = email.split('@')[0]
        row = get_latest_otp(username, 'register_email')
        if not row or row['otp'] != otp.strip():
            raise HTTPException(status_code=400, detail='Invalid OTP')
        if datetime.fromisoformat(row['expires_at']) < datetime.now(timezone.utc):
            clear_otp(username, 'register_email')
            raise HTTPException(status_code=400, detail='OTP expired')
        clear_otp(username, 'register_email_verified')
        save_otp(username, email, 'verified', 'register_email_verified', (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat())
        return {'ok': True, 'verified': True, 'username': username}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f'OTP verification failed: {e}')


@app.post('/api/auth/register')
def register(name: str = Form(...), email: str = Form(...), password: str = Form(...)):
    try:
        email = email.strip().lower()
        username = name.strip().lower()
        if not email or '@' not in email:
            raise HTTPException(status_code=400, detail='Enter a valid email address')
        if not username:
            raise HTTPException(status_code=400, detail='Name is required')
        errors = _validate_password_rules(password)
        if errors:
            raise HTTPException(status_code=400, detail='; '.join(errors))
        verified = get_latest_otp(email.split('@')[0], 'register_email_verified')
        if not verified or verified['otp'] != 'verified':
            raise HTTPException(status_code=400, detail='Verify OTP first')
        if len(username) < 3:
            raise HTTPException(status_code=400, detail='Username must be at least 3 characters long')
        if get_user_by_username(username) or get_user_by_email(email):
            raise HTTPException(status_code=400, detail='User already exists. Please login instead.')
        salt = uuid.uuid4().hex[:16]
        create_user(username, email, salt, _hash_password(password, salt), 'student')
        clear_otp(email.split('@')[0], 'register_email_verified')
        access = create_token(username, 'access')
        refresh = create_token(username, 'refresh')
        return {'ok': True, 'access_token': access, 'refresh_token': refresh, 'user': {'username': username, 'email': email, 'role': 'student'}}
    except HTTPException:
        raise
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail='User already exists. Please login instead.')
    except Exception as e:
        raise HTTPException(status_code=500, detail=f'Registration failed: {e}')


@app.post('/api/auth/login')
def auth_login(email: str = Form(...), password: str = Form(...)):
    try:
        email = email.strip().lower()
        if not email or '@' not in email:
            raise HTTPException(status_code=400, detail='Enter a valid email address')
        user = get_user_by_email(email)
        if not user:
            raise HTTPException(status_code=401, detail='Account not found. Please register first.')
        try:
            u = login_user(user['username'], password)
        except ValueError as e:
            raise HTTPException(status_code=401, detail=str(e))
        return {'ok': True, 'access_token': create_token(u['username'], 'access'), 'refresh_token': create_token(u['username'], 'refresh'), 'user': u}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f'Login failed: {e}')


@app.post('/api/auth/refresh')
def refresh(refresh_token: str = Form(...)):
    username = verify_token(refresh_token, 'refresh')
    user = get_user_by_username(username)
    return {'ok': True, 'access_token': create_token(username, 'access'), 'user': {'username': user['username'], 'email': user['email'], 'role': user['role']}}


@app.get('/api/auth/me')
def me(username: str = Depends(required_user)):
    user = get_user_by_username(username)
    return {'username': user['username'], 'email': user['email'], 'role': user['role']}


@app.get('/api/topics')
def api_topics():
    return _topics_flat()


@app.get('/api/formulas')
def api_formulas():
    labels = _load_labels()
    db = _formulas_db()
    topics=[]
    for k,v in db.items():
        count = len(v) if isinstance(v, list) else sum(len(s.get('formulas', [])) for s in v.get('sections', []))
        topics.append({'key': k, 'label': labels.get(k, k.replace('_', ' ').title()), 'count': count})
    return {'topics': topics}


@app.get('/api/formulas/{topic}')
def api_formula_topic(topic: str):
    labels = _load_labels()
    db = _formulas_db()
    if topic not in db:
        raise HTTPException(status_code=404, detail='Topic not found')
    return {'topic': topic, 'label': labels.get(topic, topic.replace('_', ' ').title()), 'data': db[topic], 'items': _topic_formula_items(topic)}


@app.post('/api/classify')
def api_classify(question: str = Form(...)):
    meta = predict_meta(question)
    return {
        'meta': meta,
        'similar_examples': retrieve_similar_examples(question, top_k=3),
        'doc_chunks': retrieve_doc_chunks(question, top_k=4),
        'retrieval_similarity': retrieval_novelty(question),
    }


@app.post('/api/solve')
async def api_solve(question: str = Form(...), topic_hint: str = Form(''), username: str = Form('guest'), auth_user: str | None = Depends(optional_user)):
    return _solve_pipeline(question.strip(), topic_hint, auth_user or username or 'guest')


@app.post('/api/solve-image')
async def api_solve_image(topic_hint: str = Form(''), username: str = Form('guest'), image: UploadFile = File(...), auth_user: str | None = Depends(optional_user)):
    suffix = Path(image.filename).suffix.lower() or '.png'
    path = UPLOADS_DIR / f'{uuid.uuid4().hex}{suffix}'
    with path.open('wb') as f:
        shutil.copyfileobj(image.file, f)
    ocr_info = extract_text_details(path)
    ocr_text = (ocr_info.get('text') or '').strip()
    if not ocr_text:
        raise HTTPException(status_code=400, detail='Could not extract text from image')
    solved = _solve_pipeline(ocr_text, topic_hint, auth_user or username or 'guest', ocr_text=ocr_text)
    solved['ocr_details'] = ocr_info
    return solved




@app.post('/api/solve-image-stream')
async def api_solve_image_stream(topic_hint: str = Form(''), username: str = Form('guest'), image: UploadFile = File(...), auth_user: str | None = Depends(optional_user)):
    suffix = Path(image.filename).suffix.lower() or '.png'
    path = UPLOADS_DIR / f'{uuid.uuid4().hex}{suffix}'
    with path.open('wb') as f:
        shutil.copyfileobj(image.file, f)
    ocr_info = extract_text_details(path)
    ocr_text = (ocr_info.get('text') or '').strip()
    if not ocr_text:
        raise HTTPException(status_code=400, detail='Could not extract text from image')

    def event(obj: dict) -> str:
        return json.dumps(obj, ensure_ascii=False) + '\n'

    async_username = auth_user or username or 'guest'

    def generate():
        yield event({'type': 'stage', 'stage': 'ocr', 'ocr_details': ocr_info, 'ocr_text': ocr_text})
        solved = _solve_pipeline(ocr_text, topic_hint, async_username, ocr_text=ocr_text)
        yield event({'type': 'stage', 'stage': 'classify', 'meta': solved.get('predicted_meta', {}), 'prompt_style': solved.get('prompt_style', 'detailed')})
        yield event({'type': 'stage', 'stage': 'retrieve', 'formula_matches': solved.get('formula_matches', [])[:3], 'similar_examples': solved.get('similar_examples', [])[:2], 'doc_chunks': solved.get('doc_chunks', [])[:2]})
        yield event({'type': 'stage', 'stage': 'validate_pre', 'validation': {'question_non_empty': bool(ocr_text.strip()), 'parser_available': True, 'topic': solved.get('solver_topic')}})
        for step in solved.get('steps', []):
            yield event({'type': 'step', 'step': step})
        validations = _validation_layers(ocr_text, solved.get('solution_json', {}), {'final_answer': solved.get('final_answer',''), 'steps': solved.get('steps', [])}, solved.get('solver_topic'))
        yield event({'type': 'stage', 'stage': 'validate_post', 'validation': validations['post_validation']})
        yield event({'type': 'done', 'history_id': solved.get('history_id'), 'final': {**(solved.get('solution_json') or {}), 'validations': validations, 'ocr_text': ocr_text, 'ocr_details': ocr_info}, 'solver': solved.get('used_solver')})

    return StreamingResponse(generate(), media_type='application/x-ndjson')


@app.post('/api/solve-stream')
async def api_solve_stream(question: str = Form(...), topic_hint: str = Form(''), username: str = Form('guest'), auth_user: str | None = Depends(optional_user)):
    text_to_solve = question.strip()
    username = auth_user or username or 'guest'
    meta = predict_meta(text_to_solve)
    selected_topic = topic_hint.strip() or meta.get('topic')
    formulas_for_prompt = _formula_matches(selected_topic, text_to_solve)
    similar_examples = retrieve_similar_examples(text_to_solve, top_k=3)
    doc_chunks = retrieve_doc_chunks(text_to_solve, top_k=4)
    prompt_style = _current_prompt_style()
    parser_result = None
    try:
        local = custom_solve(text_to_solve, selected_topic)
        parser_result = {
            'topic': local.topic,
            'question_type': local.question_type,
            'answer_form': local.answer_form,
            'final_answer': local.final_answer,
            'steps': local.steps,
            'confidence': local.confidence,
        }
    except Exception:
        parser_result = None

    def event(obj: dict) -> str:
        return json.dumps(obj, ensure_ascii=False) + '\n'

    def generate():
        yield event({'type': 'stage', 'stage': 'classify', 'meta': meta, 'prompt_style': prompt_style})
        yield event({'type': 'stage', 'stage': 'validate_pre', 'validation': {'question_non_empty': bool(text_to_solve.strip()), 'parser_available': bool(parser_result), 'topic': selected_topic}})
        yield event({'type': 'stage', 'stage': 'retrieve', 'formula_matches': formulas_for_prompt[:3], 'similar_examples': similar_examples[:2], 'doc_chunks': doc_chunks[:2]})
        used_solver = 'Mistral'
        final_payload = None
        try:
            gen = stream_solve_with_mistral(
                question=text_to_solve,
                topic=selected_topic,
                difficulty=meta.get('difficulty', 'intermediate'),
                question_type=meta.get('question_type', 'conceptual'),
                formulas=formulas_for_prompt,
                similar_examples=similar_examples,
                doc_chunks=doc_chunks,
                parser_result=parser_result,
                allow_general=True,
                prompt_style=prompt_style,
            )
            while True:
                try:
                    item = next(gen)
                    yield event(item)
                except StopIteration as stop:
                    final_payload = stop.value
                    break
        except Exception as e:
            used_solver = 'SymPy Fallback'
            try:
                final_payload = sympy_fallback_json(text_to_solve, selected_topic)
                for step in final_payload.get('steps', []):
                    yield event({'type': 'step', 'step': step})
            except Exception:
                used_solver = 'Local ML + Parser'
                if parser_result:
                    final_payload = {
                        'topic': selected_topic,
                        'difficulty': meta.get('difficulty', 'intermediate'),
                        'problem_restatement': text_to_solve,
                        'what_we_know': [text_to_solve],
                        'what_we_find': parser_result.get('final_answer', ''),
                        'approach': 'Local parser-based solving path.',
                        'steps': [{'step_number': i + 1, 'title': f'Step {i + 1}', 'why': 'Local engine step', 'working': s, 'result': '', 'note': ''} for i, s in enumerate(parser_result.get('steps', []))],
                        'final_answer': parser_result.get('final_answer', ''),
                        'verification': 'Generated by local custom engine.',
                        'common_mistakes': [],
                        'practice_problems': [],
                        'formulas_used': [{'name': f.get('name', ''), 'formula': f.get('formula', ''), 'why_used': f.get('meaning', '')} for f in formulas_for_prompt[:3]],
                    }
                    for step in final_payload.get('steps', []):
                        yield event({'type': 'step', 'step': step})
                else:
                    final_payload = {'final_answer': f'Could not solve: {e}', 'steps': []}
        final_payload = _ensure_rich_steps(final_payload, text_to_solve, parser_result, formulas_for_prompt, similar_examples, doc_chunks, selected_topic)
        validations = _validation_layers(text_to_solve, final_payload, parser_result, selected_topic)
        yield event({'type': 'stage', 'stage': 'validate_post', 'validation': validations['post_validation']})
        _store_pseudo_label(text_to_solve, meta)
        history_id = add_history({
            'username': username,
            'question': text_to_solve,
            'ocr_text': '',
            'predicted_meta': meta,
            'solver_topic': selected_topic,
            'question_type': meta.get('question_type', 'conceptual'),
            'answer_form': 'worked_solution',
            'final_answer': final_payload.get('final_answer', ''),
            'solution_json': {**(final_payload or {}), 'validations': validations},
            'solved_by': used_solver,
            'confidence': meta.get('topic_confidence', 0),
            'timestamp': datetime.now().isoformat(timespec='seconds'),
        })
        yield event({'type': 'done', 'history_id': history_id, 'final': {**(final_payload or {}), 'validations': validations}, 'solver': used_solver})

    return StreamingResponse(generate(), media_type='application/x-ndjson')

@app.get('/api/history')
def api_history(page: int = Query(1), per_page: int = Query(10), topic: str = Query(''), difficulty: str = Query(''), username: str = Depends(required_user)):
    return db_list_history(username=username, page=page, per_page=per_page, topic=topic or None, difficulty=difficulty or None)


@app.get('/api/history/{item_id}')
def api_history_detail(item_id: int, username: str = Depends(required_user)):
    row = get_history_item(item_id, username)
    if not row:
        raise HTTPException(status_code=404, detail='History item not found')
    return row


@app.post('/api/feedback')
def api_feedback(history_id: int = Form(...), reward: int = Form(...), prompt_style: str = Form(...), username: str = Depends(required_user)):
    if reward not in (-1, 1):
        raise HTTPException(status_code=400, detail='Reward must be -1 or 1')
    add_feedback(history_id, username, reward, prompt_style)
    set_history_rating(history_id, reward)
    return {'ok': True}


@app.get('/api/stats')
def api_stats(username: str = Depends(required_user)):
    return compute_user_stats(username)


@app.get('/api/admin/model-stats')
def api_admin_model_stats():
    report = json.loads(TRAIN_REPORT.read_text(encoding='utf-8')) if TRAIN_REPORT.exists() else {}
    pseudo_count = len(json.loads(PSEUDO_LABELS_PATH.read_text(encoding='utf-8'))) if PSEUDO_LABELS_PATH.exists() else 0
    return {'training_report': report, 'pseudo_labels_count': pseudo_count, 'prompt_strategies': get_prompt_strategy_rows(), 'policy': policy_snapshot(), 'admin_badge': report.get('admin_badge','')}


# legacy aliases used by the static frontend
@app.get('/topics')
def topics_legacy():
    raw = json.loads(TOPIC_CATALOG_PATH.read_text(encoding='utf-8'))
    labels = _load_labels()
    return {stage: [{'key': key, 'label': labels.get(key, key.replace('_', ' ').title()), 'aliases': aliases} for key, aliases in raw[stage].items()] for stage in raw}


@app.get('/formulas')
def formulas_legacy():
    return _formulas_db()


@app.get('/training-report')
def training_report():
    return JSONResponse(json.loads(TRAIN_REPORT.read_text(encoding='utf-8')) if TRAIN_REPORT.exists() else {})


@app.post('/solve')
async def solve_legacy(question: str = Form(''), topic_hint: str = Form(''), username: str = Form('guest'), image: UploadFile | None = File(None)):
    text_to_solve = question.strip()
    ocr_text = ''
    if image is not None and image.filename:
        suffix = Path(image.filename).suffix.lower() or '.png'
        path = UPLOADS_DIR / f'{uuid.uuid4().hex}{suffix}'
        with path.open('wb') as f:
            shutil.copyfileobj(image.file, f)
        ocr_text = extract_text(path)
        if not text_to_solve:
            text_to_solve = ocr_text
    if not text_to_solve:
        raise HTTPException(status_code=400, detail='Please type a question or upload an image.')
    return _solve_pipeline(text_to_solve, topic_hint, username, ocr_text=ocr_text)


@app.get('/history')
def history_legacy(username: str = Query('guest')):
    return db_list_history(username=username, page=1, per_page=50)


@app.post('/practice/generate')
def practice_generate(topic: str = Form(...), count: int = Form(1)):
    total = max(1, min(20, int(count or 1)))
    questions = []
    seen = set()
    attempts = 0
    while len(questions) < total and attempts < total * 10:
        item = _practice_question_for_topic(topic)
        attempts += 1
        if item not in seen:
            questions.append(item)
            seen.add(item)
    return {'question': questions[0] if questions else '', 'questions': questions}


@app.post('/practice/check')
def practice_check(question: str = Form(...), topic: str = Form(...), user_answer: str = Form(...), username: str = Form('guest')):
    solved = _solve_pipeline(question, topic, username)
    correct = str(solved['final_answer']).strip().lower() == str(user_answer).strip().lower()
    add_practice_result(username, topic, question, user_answer, solved['final_answer'], correct)
    return {'message': 'Correct!' if correct else 'Not quite. Review the steps below.', 'correct_answer': solved['final_answer'], 'steps': [s.get('working', s) if isinstance(s, dict) else s for s in solved['steps']]}


@app.get('/listening')
def listening_list():
    return {'items': db_list_videos()}


@app.post('/listening/upload')
async def listening_upload(topic: str = Form(...), file: UploadFile = File(...)):
    suffix = Path(file.filename).suffix.lower() or '.mp4'
    dest = VIDEOS_DIR / f'{uuid.uuid4().hex}{suffix}'
    with dest.open('wb') as f:
        shutil.copyfileobj(file.file, f)
    row = add_video(topic, file.filename, f'/videos/{dest.name}')
    return {'ok': True, 'item': row}


@app.get('/profile')
def get_profile(username: str = Query(...)):
    user = get_user_by_username(username.strip().lower())
    if not user:
        raise HTTPException(status_code=404, detail='User not found')
    return {'username': user['username'], 'email': user['email'], 'role': user.get('role', 'student')}


@app.post('/profile/update')
def profile_update(username: str = Form(...), email: str = Form(...), new_username: str = Form('')):
    try:
        user = update_profile(username.strip().lower(), email=email, new_username=(new_username or username))
        return {'ok': True, 'user': user}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post('/profile/send-otp')
def profile_send_otp(username: str = Form(...)):
    try:
        info = send_password_change_otp(username)
        return {'ok': True, 'detail': f"OTP sent to {info['email']}"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post('/profile/change-password')
def profile_change_password(username: str = Form(...), otp: str = Form(...), new_password: str = Form(...)):
    try:
        user = change_password_with_otp(username, otp, new_password)
        return {'ok': True, 'user': user}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.delete('/api/history/{item_id}')
def api_delete_history_item(item_id: int, username: str = Depends(required_user)):
    if not delete_history_item(item_id, username):
        raise HTTPException(status_code=404, detail='History item not found')
    return {'ok': True}


@app.delete('/api/profile/history')
def api_delete_all_history(username: str = Depends(required_user)):
    count = delete_all_history(username)
    return {'ok': True, 'deleted': count}


@app.delete('/api/profile/account')
def api_delete_account(username: str = Depends(required_user)):
    delete_user_account(username)
    return {'ok': True}

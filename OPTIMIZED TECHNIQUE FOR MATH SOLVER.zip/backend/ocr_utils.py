from __future__ import annotations
import base64
import re
from pathlib import Path

from PIL import Image, ImageOps, ImageFilter

try:
    import pytesseract
except Exception:  # pragma: no cover
    pytesseract = None

from .mistral_client import extract_text_with_mistral_vision


def _preprocess(img: Image.Image) -> Image.Image:
    img = img.convert('L')
    img = ImageOps.autocontrast(img)
    img = img.resize((img.width * 2, img.height * 2))
    img = img.filter(ImageFilter.MedianFilter(size=3))
    img = img.point(lambda p: 255 if p > 160 else 0)
    return img


def _tesseract_with_confidence(img: Image.Image) -> tuple[str, float]:
    if pytesseract is None:
        return '', 0.0
    try:
        data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT, config='--psm 6')
        words = [w.strip() for w in data.get('text', []) if (w or '').strip()]
        confs = []
        for c in data.get('conf', []):
            try:
                val = float(c)
                if val >= 0:
                    confs.append(val)
            except Exception:
                pass
        text = ' '.join(words).strip()
        avg_conf = round(sum(confs) / len(confs), 2) if confs else 0.0
        return text, avg_conf
    except Exception:
        try:
            return pytesseract.image_to_string(img, config='--psm 6').strip(), 0.0
        except Exception:
            return '', 0.0


def extract_text_details(path: str | Path) -> dict:
    path = Path(path)
    img = Image.open(path)
    processed = _preprocess(img)

    tesseract_text, tesseract_conf = ('', 0.0)
    if pytesseract is not None:
        tesseract_text, tesseract_conf = _tesseract_with_confidence(processed)

    if len(tesseract_text) >= 10:
        return {
            'text': tesseract_text,
            'method': 'tesseract',
            'tesseract_confidence': tesseract_conf,
            'fallback_used': False,
            'structured': {
                'line_count': max(1, tesseract_text.count('\n') + 1),
                'has_equals': '=' in tesseract_text,
                'has_digits': any(ch.isdigit() for ch in tesseract_text),
                'token_count': len(re.findall(r'\S+', tesseract_text)),
            }
        }

    vision_text = ''
    vision_error = ''
    try:
        media_type = 'image/png'
        suffix = path.suffix.lower().lstrip('.')
        if suffix in ('jpg', 'jpeg'):
            media_type = 'image/jpeg'
        elif suffix == 'webp':
            media_type = 'image/webp'
        image_b64 = base64.b64encode(path.read_bytes()).decode('utf-8')
        vision_text = extract_text_with_mistral_vision(image_b64, media_type=media_type).strip()
    except Exception as e:
        vision_error = str(e)

    final_text = vision_text or tesseract_text
    return {
        'text': final_text.strip(),
        'method': 'mistral_vision' if vision_text else 'tesseract',
        'tesseract_confidence': tesseract_conf,
        'fallback_used': bool(vision_text),
        'vision_error': vision_error,
        'structured': {
            'line_count': max(1, final_text.count('\n') + 1) if final_text else 0,
            'has_equals': '=' in final_text,
            'has_digits': any(ch.isdigit() for ch in final_text),
            'token_count': len(re.findall(r'\S+', final_text)),
        }
    }


def extract_text(path: str | Path) -> str:
    return extract_text_details(path).get('text', '').strip()

from __future__ import annotations
import os
from datetime import datetime, timedelta, timezone
import jwt
from fastapi import Header, HTTPException

SECRET = os.getenv('JWT_SECRET', 'change_this_random_string')
ALGO = 'HS256'
ACCESS_HOURS = 24
REFRESH_DAYS = 30


def create_token(username: str, token_type: str = 'access') -> str:
    exp = datetime.now(timezone.utc) + (timedelta(hours=ACCESS_HOURS) if token_type == 'access' else timedelta(days=REFRESH_DAYS))
    return jwt.encode({'sub': username, 'type': token_type, 'exp': exp}, SECRET, algorithm=ALGO)


def verify_token(token: str, expected_type: str = 'access') -> str:
    try:
        payload = jwt.decode(token, SECRET, algorithms=[ALGO])
    except Exception as e:
        raise HTTPException(status_code=401, detail=f'Invalid token: {e}')
    if payload.get('type') != expected_type:
        raise HTTPException(status_code=401, detail='Wrong token type')
    return str(payload.get('sub'))


def optional_user(authorization: str | None = Header(default=None)) -> str | None:
    if not authorization or not authorization.lower().startswith('bearer '):
        return None
    token = authorization.split(' ', 1)[1]
    return verify_token(token, 'access')


def required_user(authorization: str | None = Header(default=None)) -> str:
    if not authorization or not authorization.lower().startswith('bearer '):
        raise HTTPException(status_code=401, detail='Missing bearer token')
    token = authorization.split(' ', 1)[1]
    return verify_token(token, 'access')

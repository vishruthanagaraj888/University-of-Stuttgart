from __future__ import annotations
import json
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
ARTIFACTS_DIR = BASE_DIR / 'artifacts'
UPLOADS_DIR = BASE_DIR / 'uploads'
VIDEOS_DIR = BASE_DIR / 'videos'
HISTORY_PATH = DATA_DIR / 'history.jsonl'
VIDEO_INDEX_PATH = DATA_DIR / 'videos.json'
USERS_PATH = DATA_DIR / 'users.json'

for p in [DATA_DIR, ARTIFACTS_DIR, UPLOADS_DIR, VIDEOS_DIR]:
    p.mkdir(parents=True, exist_ok=True)


def append_jsonl(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')


def read_jsonl(path: Path, limit: int | None = None) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    if limit:
        return rows[-limit:]
    return rows


def load_json(path: Path, default: Any):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding='utf-8'))


def save_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

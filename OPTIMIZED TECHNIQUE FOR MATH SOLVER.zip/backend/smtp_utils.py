
from __future__ import annotations
import json, os, smtplib, ssl
from email.message import EmailMessage
from pathlib import Path

try:
    from dotenv import load_dotenv
except Exception:
    load_dotenv = None

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / 'data' / 'smtp_config.json'

DEFAULT_CONFIG = {
    "enabled": False,
    "host": "smtp.gmail.com",
    "port": 587,
    "username": "",
    "password": "",
    "from_email": "",
    "from_name": "MathGenius"
}


def _load_runtime_config() -> None:
    if load_dotenv is not None:
        for cand in [BASE_DIR / '.env', BASE_DIR / 'backend' / '.env']:
            if cand.exists():
                load_dotenv(cand, override=True)
    for cand in [BASE_DIR / 'secrets.json', BASE_DIR / 'backend' / 'secrets.json']:
        if cand.exists():
            try:
                data = json.loads(cand.read_text(encoding='utf-8'))
                for k, v in data.items():
                    if v is not None and str(v) != '':
                        os.environ[str(k)] = str(v)
            except Exception:
                pass


def load_smtp_config():
    _load_runtime_config()
    if CONFIG_PATH.exists():
        try:
            cfg = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
        except Exception:
            cfg = {}
    else:
        cfg = {}
    env = {
        "enabled": os.getenv('SMTP_ENABLED'),
        "host": os.getenv('SMTP_HOST'),
        "port": os.getenv('SMTP_PORT'),
        "username": os.getenv('SMTP_USERNAME') or os.getenv('SMTP_USER'),
        "password": os.getenv('SMTP_PASSWORD') or os.getenv('SMTP_PASS'),
        "from_email": os.getenv('SMTP_FROM_EMAIL'),
        "from_name": os.getenv('SMTP_FROM_NAME'),
    }
    final = DEFAULT_CONFIG | cfg
    for k, v in env.items():
        if v not in (None, ''):
            if k == 'enabled':
                final[k] = str(v).lower() == 'true'
            elif k == 'port':
                final[k] = int(v)
            else:
                final[k] = v
    if not final.get('from_email'):
        final['from_email'] = final.get('username', '')
    if final.get('password'):
        final['password'] = str(final['password']).replace(' ', '')
    return final


def send_email(to_email: str, subject: str, body: str):
    cfg = load_smtp_config()
    if not cfg.get('enabled'):
        return {"ok": False, "detail": "SMTP is not enabled. Set SMTP_ENABLED=true in .env or secrets.json."}
    required = ['host', 'port', 'username', 'password', 'from_email']
    missing = [k for k in required if not cfg.get(k)]
    if missing:
        return {"ok": False, "detail": f"SMTP config incomplete: missing {', '.join(missing)}"}
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = f"{cfg.get('from_name','MathGenius')} <{cfg['from_email']}>"
    msg['To'] = to_email
    msg.set_content(body)
    try:
        port = int(cfg['port'])
        if port == 465:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(cfg['host'], port, timeout=30, context=context) as server:
                server.login(cfg['username'], cfg['password'])
                server.send_message(msg)
        else:
            with smtplib.SMTP(cfg['host'], port, timeout=30) as server:
                server.ehlo()
                server.starttls(context=ssl.create_default_context())
                server.ehlo()
                server.login(cfg['username'], cfg['password'])
                server.send_message(msg)
        return {"ok": True}
    except smtplib.SMTPAuthenticationError as exc:
        return {"ok": False, "detail": f"SMTP authentication failed. Check Gmail app password and email settings. {exc}"}
    except Exception as exc:
        return {"ok": False, "detail": f"SMTP send failed: {exc}"}

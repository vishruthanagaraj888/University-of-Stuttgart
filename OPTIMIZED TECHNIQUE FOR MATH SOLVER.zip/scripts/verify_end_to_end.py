from __future__ import annotations
import json
from pathlib import Path
from PIL import Image, ImageDraw
from fastapi.testclient import TestClient
from backend.main import app

BASE_DIR = Path(__file__).resolve().parent.parent
ART = BASE_DIR / 'artifacts'
ART.mkdir(exist_ok=True)

client = TestClient(app)
results = []

cases = [
    ('health', lambda: client.get('/health')),
    ('topics', lambda: client.get('/topics')),
    ('solve_arithmetic', lambda: client.post('/solve', data={'question':'12 + 5','topic_hint':'school_arithmetic'})),
    ('solve_linear', lambda: client.post('/solve', data={'question':'2x + 5 = 15','topic_hint':'school_linear_equations'})),
    ('solve_system', lambda: client.post('/solve', data={'question':'2x + 3y = 13; x + y = 5','topic_hint':'school_linear_equations_two_variables'})),
    ('solve_diff', lambda: client.post('/solve', data={'question':'3x**2 + 2x + 1','topic_hint':'differentiation'})),
    ('practice_generate', lambda: client.post('/practice/generate', data={'topic':'school_linear_equations'})),
    ('practice_check', lambda: client.post('/practice/check', data={'question':'2x + 5 = 15','topic':'school_linear_equations','user_answer':'5'})),
]

# OCR case
img_path = ART / 'ocr_test.png'
img = Image.new('RGB', (320, 80), 'white')
ImageDraw.Draw(img).text((10, 20), '12 + 7', fill='black')
img.save(img_path)

def ocr_case():
    with img_path.open('rb') as f:
        return client.post('/solve', files={'image': ('ocr_test.png', f, 'image/png')}, data={'topic_hint':'school_arithmetic'})
cases.append(('solve_ocr_upload', ocr_case))

for name, fn in cases:
    try:
        resp = fn()
        body = resp.json()
        results.append({'name': name, 'status_code': resp.status_code, 'ok': resp.status_code == 200, 'body_preview': str(body)[:500]})
    except Exception as e:
        results.append({'name': name, 'status_code': None, 'ok': False, 'error': str(e)})

report = {'all_passed': all(r['ok'] for r in results), 'results': results}
(ART / 'verification_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))

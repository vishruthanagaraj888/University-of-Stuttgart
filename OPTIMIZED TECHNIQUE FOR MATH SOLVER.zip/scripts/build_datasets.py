from __future__ import annotations
import json
import random
import re
import xml.etree.ElementTree as ET
from pathlib import Path
import fitz

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / 'data'
DATA_DIR.mkdir(exist_ok=True)
random.seed(42)

TOPIC_CATALOG = {
    'school': {
        'school_numbers_counting': 'Numbers, Counting, Before and After',
        'school_arithmetic': 'Addition, Subtraction, Multiplication, Division',
        'school_shapes_geometry_basic': 'Shapes and Basic Geometry',
        'school_time_calendar_money_measurement': 'Time, Calendar, Money, Measurement',
        'school_patterns': 'Patterns',
        'school_factors_multiples': 'Factors and Multiples',
        'school_fractions_decimals': 'Fractions and Decimals',
        'school_percentage': 'Percentage and Simple Interest',
        'school_ratio_proportion': 'Ratio and Proportion',
        'school_integers_rational': 'Integers, Rational Numbers, Roots',
        'school_algebraic_expressions_identities': 'Algebraic Expressions and Identities',
        'school_linear_equations': 'Linear Equations',
        'school_linear_equations_two_variables': 'Linear Equations in Two Variables',
        'school_quadratic_equations': 'Quadratic Equations',
        'school_ap': 'Arithmetic Progression',
        'school_coordinate_geometry': 'Coordinate Geometry',
        'school_triangles_circles_geometry': 'Triangles, Circles, Heron, Heights and Distances',
        'school_mensuration': 'Mensuration',
        'school_statistics': 'Statistics',
        'school_probability': 'Probability',
        'school_trigonometry': 'Trigonometry',
    },
    'intermediate': {
        'intermediate_sets_relations_functions': 'Sets, Relations and Functions',
        'intermediate_trig_functions_identities': 'Trigonometric Functions and Identities',
        'intermediate_complex_numbers': 'Complex Numbers',
        'intermediate_quadratic_inequalities': 'Linear and Quadratic Inequalities',
        'intermediate_sequences_series': 'Sequences and Series',
        'intermediate_permutations_combinations': 'Permutations and Combinations',
        'intermediate_binomial': 'Binomial Theorem',
        'intermediate_straight_lines_conics': 'Straight Lines and Conics',
        'intermediate_limits_continuity': 'Limits and Continuity',
        'intermediate_differentiation': 'Differentiation',
        'intermediate_integration': 'Integration',
        'intermediate_differential_equations': 'Differential Equations',
        'intermediate_matrices': 'Matrices and Determinants',
        'intermediate_vectors_3d': 'Vectors and 3D Geometry',
        'intermediate_linear_programming': 'Linear Programming',
        'intermediate_probability': 'Probability and Random Variables',
    }
}


def write_jsonl(path: Path, rows: list[dict]):
    with path.open('w', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')


def row(stage, topic, question, qtype, answer_form, step_template, source='generated'):
    return {
        'stage': stage,
        'topic': topic,
        'question': question,
        'answer': '',
        'question_type': qtype,
        'answer_form': answer_form,
        'step_template': step_template,
        'source': source,
    }


def school_template_pool() -> dict[str, list[callable]]:
    def arithmetic():
        a, b = random.randint(1, 500), random.randint(1, 500)
        op = random.choice(['+', '-', '*', '/'])
        if op == '/':
            a = b * random.randint(1, 30)
        q = random.choice([
            f'{a} {op} {b}',
            f'What is {a} {op} {b}?',
            f'Calculate {a} {op} {b}',
        ])
        return row('school', 'school_arithmetic', q, 'arithmetic', 'number', 'arithmetic_steps')

    def before_after():
        n = random.randint(1, 1000)
        mode = random.choice(['before', 'after'])
        q = random.choice([f'What comes {mode} {n}?', f'Find the number {mode} {n}', f'{mode.capitalize()} of {n}'])
        return row('school', 'school_numbers_counting', q, 'before_after', 'number', 'counting_steps')

    def patterns():
        a = random.randint(1, 20)
        d = random.randint(1, 10)
        seq = [a + i*d for i in range(4)]
        q = random.choice([
            f'Find the next term in the pattern {seq[0]}, {seq[1]}, {seq[2]}, {seq[3]}',
            f'Pattern question: {seq[0]}, {seq[1]}, {seq[2]}, {seq[3]}, ?',
        ])
        return row('school', 'school_patterns', q, 'pattern', 'number', 'pattern_steps')

    def fractions():
        a, b = random.randint(1, 9), random.randint(2, 12)
        n = random.randint(2, 100)
        if random.random() < 0.5:
            q = random.choice([f'Find {a}/{b} of {n}', f'What is {a}/{b} of {n}?'])
            return row('school', 'school_fractions_decimals', q, 'fraction_of', 'number', 'fraction_of_steps')
        c, d = random.randint(1, 9), random.randint(2, 12)
        op = random.choice(['+', '-', '*', '/'])
        q = f'{a}/{b} {op} {c}/{d}'
        return row('school', 'school_fractions_decimals', q, 'fraction_operation', 'fraction', 'fraction_steps')

    def percentages():
        p = random.choice([5, 10, 12.5, 20, 25, 30, 40, 50, 75])
        n = random.randint(20, 500)
        if random.random() < 0.55:
            q = random.choice([f'What is {p}% of {n}?', f'Find {p}% of {n}', f'Calculate {p}% of {n}'])
            return row('school', 'school_percentage', q, 'percentage', 'number', 'percentage_steps')
        principal = random.choice([500, 1000, 1500, 2000, 5000])
        rate = random.choice([2, 3, 4, 5, 6, 8, 10])
        time = random.randint(1, 5)
        q = random.choice([
            f'Find simple interest on ₹{principal} at {rate}% for {time} years',
            f'Find SI on ₹{principal} at {rate}% for {time} years',
        ])
        return row('school', 'school_percentage', q, 'simple_interest', 'number', 'simple_interest_steps')

    def ratios():
        a, b = random.randint(2, 80), random.randint(2, 80)
        if random.random() < 0.5:
            q = random.choice([f'Find ratio of {a} and {b}', f'What is the ratio of {a} to {b}?'])
            return row('school', 'school_ratio_proportion', q, 'ratio', 'text', 'ratio_steps')
        c = random.randint(2, 50)
        q = random.choice([f'{a}:{b} = {c}:x', f'Solve the proportion {a}:{b} = {c}:x'])
        return row('school', 'school_ratio_proportion', q, 'proportion', 'number', 'proportion_steps')

    def factors_multiples():
        a, b = random.randint(2, 120), random.randint(2, 120)
        mode = random.choice(['HCF', 'LCM'])
        q = random.choice([f'Find {mode} of {a} and {b}', f'Calculate {mode}({a}, {b})'])
        return row('school', 'school_factors_multiples', q, 'hcf_lcm', 'number', 'factors_steps')

    def integers_roots():
        n = random.choice([16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196])
        if random.random() < 0.5:
            return row('school', 'school_integers_rational', f'Find √{n}', 'square_root', 'number', 'root_steps')
        m = random.choice([8, 27, 64, 125, 216, 343, 512, 729])
        return row('school', 'school_integers_rational', f'Find cube root of {m}', 'cube_root', 'number', 'root_steps')

    def identities():
        q = random.choice(['Expand (a + b)^2', 'Expand (a - b)^2', 'Expand (a+b)(a-b)'])
        return row('school', 'school_algebraic_expressions_identities', q, 'identity', 'expression', 'identity_steps')

    def linear_equation():
        a, x, b = random.randint(1, 15), random.randint(-20, 20), random.randint(-15, 15)
        c = a*x + b
        q = random.choice([f'Solve {a}x + {b} = {c}', f'{a}x + {b} = {c}'])
        return row('school', 'school_linear_equations', q, 'linear_equation', 'number', 'linear_steps')

    def system_equation():
        x, y = random.randint(-10, 10), random.randint(-10, 10)
        a1, b1, a2, b2 = [random.randint(1, 9) for _ in range(4)]
        c1, c2 = a1*x+b1*y, a2*x+b2*y
        q = random.choice([
            f'Solve {a1}x + {b1}y = {c1}; {a2}x + {b2}y = {c2}',
            f'{a1}x + {b1}y = {c1}\n{a2}x + {b2}y = {c2}',
        ])
        return row('school', 'school_linear_equations_two_variables', q, 'solve_system', 'number_pair', 'system_steps')

    def quadratic():
        r1, r2 = random.randint(-10, 10), random.randint(-10, 10)
        b, c = -(r1+r2), r1*r2
        q = random.choice([f'Solve x² {"+" if b>=0 else "-"} {abs(b)}x {"+" if c>=0 else "-"} {abs(c)} = 0', f'x^2 + {b}x + {c} = 0'])
        return row('school', 'school_quadratic_equations', q, 'quadratic', 'number_pair', 'quadratic_steps')

    def ap():
        a = random.randint(1, 20); d = random.randint(1, 10)
        seq = [a + i*d for i in range(4)]
        q = random.choice([
            f'Find nth term of {seq[0]}, {seq[1]}, {seq[2]}, {seq[3]}',
            f'a={a}, d={d}, n={random.randint(3, 15)}',
        ])
        return row('school', 'school_ap', q, 'ap', 'text', 'ap_steps')

    def coordinate_geometry():
        x1, y1, x2, y2 = [random.randint(-10, 10) for _ in range(4)]
        mode = random.choice(['distance', 'midpoint', 'slope'])
        q = f'Find {mode} between ({x1},{y1}) and ({x2},{y2})'
        return row('school', 'school_coordinate_geometry', q, mode, 'number' if mode != 'midpoint' else 'point', f'{mode}_steps')

    def geometry():
        kind = random.choice(['heron', 'pythagoras', 'tan_height'])
        if kind == 'heron':
            sides = random.choice([(5,6,7), (13,14,15), (6,8,10)])
            q = random.choice([f'Area of triangle ({sides[0]},{sides[1]},{sides[2]}) using Heron formula', f'Use Heron formula for sides {sides[0]}, {sides[1]}, {sides[2]}'])
            return row('school', 'school_triangles_circles_geometry', q, 'heron', 'number', 'heron_steps')
        if kind == 'pythagoras':
            a, b = random.randint(3, 12), random.randint(4, 15)
            q = f'Use Pythagoras theorem for sides {a} and {b}'
            return row('school', 'school_triangles_circles_geometry', q, 'pythagoras', 'number', 'pythagoras_steps')
        angle = random.choice([30,45,60]); base = random.randint(5, 20)
        q = f'Find height when angle is {angle} and base is {base} using tan'
        return row('school', 'school_triangles_circles_geometry', q, 'heights_distances', 'number', 'heights_steps')

    def mensuration():
        kind = random.choice(['rectangle_perimeter', 'rectangle_area', 'square_area', 'circle_area', 'sphere_surface_area', 'cuboid_volume'])
        if kind == 'rectangle_perimeter':
            l, b = random.randint(2, 25), random.randint(2, 25)
            q = f'Find perimeter of rectangle (l={l}, b={b})'
        elif kind == 'rectangle_area':
            l, b = random.randint(2, 25), random.randint(2, 25)
            q = f'Area of rectangle with length {l} and breadth {b}'
        elif kind == 'square_area':
            a = random.randint(2, 20)
            q = f'Area of square with side {a}'
        elif kind == 'circle_area':
            r = random.randint(2, 14)
            q = f'Find area with r = {r}'
        elif kind == 'sphere_surface_area':
            r = random.randint(2, 14)
            q = f'Surface area (sphere) with r = {r}'
        else:
            l, b, h = random.randint(2, 10), random.randint(2, 10), random.randint(2, 10)
            q = f'Find volume of cuboid with l={l}, b={b}, h={h}'
        return row('school', 'school_mensuration', q, 'mensuration', 'number', 'mensuration_steps')

    def statistics():
        arr = [random.randint(1, 50) for _ in range(random.randint(4, 7))]
        mode = random.choice(['mean', 'median', 'mode'])
        q = f'Find {mode} of {", ".join(map(str, arr))}'
        return row('school', 'school_statistics', q, mode, 'number', f'{mode}_steps')

    def probability():
        fav, total = random.randint(1, 6), random.randint(6, 20)
        total = max(total, fav)
        q = random.choice([
            f'Probability when favorable outcomes are {fav} and total outcomes are {total}',
            f'Find probability if favorable outcomes = {fav} and total outcomes = {total}',
        ])
        return row('school', 'school_probability', q, 'probability', 'fraction', 'probability_steps')

    def trig():
        q = random.choice([
            'State the trigonometric identity',
            'sin^2θ + cos^2θ',
            f'Find {random.choice(["sin", "cos", "tan"])} {random.choice([0,30,45,60,90])}',
        ])
        return row('school', 'school_trigonometry', q, 'trigonometry', 'number', 'trig_steps')

    def money_time_measurement():
        kind = random.choice(['hours_to_minutes', 'cost_word', 'cm_to_m'])
        if kind == 'hours_to_minutes':
            h = random.randint(1, 12)
            q = f'Convert {h} hours into minutes'
        elif kind == 'cost_word':
            price, qty = random.randint(5, 50), random.randint(2, 12)
            q = f'One notebook costs ₹{price} each. Find total cost for {qty} notebooks.'
        else:
            cm = random.randint(100, 500)
            q = f'Convert {cm} cm to m'
        return row('school', 'school_time_calendar_money_measurement', q, 'measurement_money_time', 'number', 'conversion_steps')

    return {
        'school_numbers_counting': [before_after],
        'school_arithmetic': [arithmetic],
        'school_shapes_geometry_basic': [lambda: row('school','school_shapes_geometry_basic', random.choice(['What is a triangle?', 'Define a square', 'What is a circle?']), 'concept', 'text', 'concept_steps')],
        'school_time_calendar_money_measurement': [money_time_measurement],
        'school_patterns': [patterns],
        'school_factors_multiples': [factors_multiples],
        'school_fractions_decimals': [fractions],
        'school_percentage': [percentages],
        'school_ratio_proportion': [ratios],
        'school_integers_rational': [integers_roots],
        'school_algebraic_expressions_identities': [identities],
        'school_linear_equations': [linear_equation],
        'school_linear_equations_two_variables': [system_equation],
        'school_quadratic_equations': [quadratic],
        'school_ap': [ap],
        'school_coordinate_geometry': [coordinate_geometry],
        'school_triangles_circles_geometry': [geometry],
        'school_mensuration': [mensuration],
        'school_statistics': [statistics],
        'school_probability': [probability],
        'school_trigonometry': [trig],
    }


def intermediate_template_pool() -> dict[str, list[callable]]:
    def relation_function():
        q = random.choice(['What is a relation?', 'What is a function?', 'Define domain and range of a function'])
        return row('intermediate', 'intermediate_sets_relations_functions', q, 'concept', 'text', 'concept_steps')

    def trig_func():
        q = random.choice(['State identity', 'Find sin inverse 1/2', 'Find cos inverse 1/2', 'Find tan inverse 1'])
        return row('intermediate', 'intermediate_trig_functions_identities', q, 'inverse_trig', 'text', 'trig_steps')

    def complex_numbers():
        a, b = random.randint(1, 10), random.randint(1, 10)
        q = random.choice([f'Find modulus of {a} + {b}i', f'Find |{a}+{b}i|'])
        return row('intermediate', 'intermediate_complex_numbers', q, 'modulus', 'number', 'complex_steps')

    def inequality():
        a, b, c = random.randint(1, 10), random.randint(-10, 10), random.randint(-10, 20)
        q = f'Solve {a}x + {b} > {c}'
        return row('intermediate', 'intermediate_quadratic_inequalities', q, 'inequality', 'text', 'inequality_steps')

    def sequences_series():
        if random.random() < 0.65:
            a, d, n = random.randint(1, 10), random.randint(1, 6), random.randint(4, 15)
            q = f'Find nth term and sum for a={a}, d={d}, n={n}'
            return row('intermediate', 'intermediate_sequences_series', q, 'ap', 'text', 'ap_steps')
        a, r, n = random.randint(1, 5), random.randint(2, 4), random.randint(4, 10)
        q = f'Find nth term and sum for a={a}, r={r}, n={n}'
        return row('intermediate', 'intermediate_sequences_series', q, 'gp', 'text', 'gp_steps')

    def perm_comb():
        n = random.randint(3, 9); r = random.randint(0, n)
        if random.random() < 0.5:
            q = random.choice([f'Find {n}C{r}', f'Find nCr for n={n}, r={r}'])
            return row('intermediate', 'intermediate_permutations_combinations', q, 'combination', 'number', 'ncr_steps')
        q = random.choice([f'Find {n}P{r}', f'Find nPr for n={n}, r={r}'])
        return row('intermediate', 'intermediate_permutations_combinations', q, 'permutation', 'number', 'npr_steps')

    def binomial():
        c = random.randint(1, 5)
        p = random.choice([2, 3])
        q = random.choice([f'Expand (x + {c})^{p}', f'Expand (x+{c})**{p}'])
        return row('intermediate', 'intermediate_binomial', q, 'binomial_expand', 'expression', 'binomial_steps')

    def lines_conics():
        x1, y1, x2, y2 = [random.randint(-10, 10) for _ in range(4)]
        if random.random() < 0.5:
            q = f'Find slope between ({x1},{y1}) and ({x2},{y2})'
            return row('intermediate', 'intermediate_straight_lines_conics', q, 'slope', 'number', 'slope_steps')
        q = f'Find equation of line through ({x1},{y1}) and ({x2},{y2})'
        return row('intermediate', 'intermediate_straight_lines_conics', q, 'line_equation', 'expression', 'line_steps')

    def limits():
        q = random.choice(['lim (x→0) (sin x / x)', f'limit x->2 of x**2 + {random.randint(1,5)}'])
        return row('intermediate', 'intermediate_limits_continuity', q, 'limit', 'number', 'limit_steps')

    def differentiation():
        coeffs = [random.randint(-5, 5) for _ in range(4)]
        expr = ' + '.join(f'{c}x^{p}' for p, c in zip(range(3, -1, -1), coeffs) if c)
        q = random.choice([f'differentiate {expr}', f'd/dx ({expr})'])
        return row('intermediate', 'intermediate_differentiation', q, 'differentiate', 'expression', 'differentiate_steps')

    def integration():
        coeffs = [random.randint(-5, 5) for _ in range(3)]
        expr = ' + '.join(f'{c}x^{p}' for p, c in zip(range(2, -1, -1), coeffs) if c)
        q = random.choice([f'integrate {expr}', f'∫ {expr} dx'])
        return row('intermediate', 'intermediate_integration', q, 'integrate', 'expression', 'integrate_steps')

    def de():
        k = random.randint(1, 8)
        q = random.choice([f'Solve dy/dx = {k}x', f'dy/dx = {k}x'])
        return row('intermediate', 'intermediate_differential_equations', q, 'differential_equation', 'expression', 'de_steps')

    def matrices():
        a, b, c, d = [random.randint(-5, 8) for _ in range(4)]
        if random.random() < 0.5:
            q = f'Find determinant |{a} {b}; {c} {d}|'
            return row('intermediate', 'intermediate_matrices', q, 'determinant', 'number', 'determinant_steps')
        q = f'Find inverse of matrix [[{a},{b}],[{c},{d}]]'
        return row('intermediate', 'intermediate_matrices', q, 'inverse_matrix', 'matrix', 'inverse_steps')

    def vectors():
        if random.random() < 0.5:
            q = random.choice(['Angle between i+j and i-j', 'Find angle between i+j and i-j'])
            return row('intermediate', 'intermediate_vectors_3d', q, 'vector_angle', 'number', 'vector_angle_steps')
        a, b, c, d, e, f = [random.randint(-4, 4) for _ in range(6)]
        q = f'Find dot product of ({a},{b},{c}) and ({d},{e},{f})'
        return row('intermediate', 'intermediate_vectors_3d', q, 'dot_product', 'number', 'vector_steps')

    def lp():
        x, y = random.randint(1, 5), random.randint(1, 5)
        q = f'Maximize Z = 3x + 2y for ({x},{y})'
        return row('intermediate', 'intermediate_linear_programming', q, 'objective_value', 'number', 'lp_steps')

    def probability():
        q = random.choice(['Find 5C2', 'Find nCr for n=5, r=2'])
        return row('intermediate', 'intermediate_probability', q, 'combination', 'number', 'ncr_steps')

    return {
        'intermediate_sets_relations_functions': [relation_function],
        'intermediate_trig_functions_identities': [trig_func],
        'intermediate_complex_numbers': [complex_numbers],
        'intermediate_quadratic_inequalities': [inequality],
        'intermediate_sequences_series': [sequences_series],
        'intermediate_permutations_combinations': [perm_comb],
        'intermediate_binomial': [binomial],
        'intermediate_straight_lines_conics': [lines_conics],
        'intermediate_limits_continuity': [limits],
        'intermediate_differentiation': [differentiation],
        'intermediate_integration': [integration],
        'intermediate_differential_equations': [de],
        'intermediate_matrices': [matrices],
        'intermediate_vectors_3d': [vectors],
        'intermediate_linear_programming': [lp],
        'intermediate_probability': [probability],
    }


def generate_rows(pool: dict[str, list[callable]], target: int) -> list[dict]:
    topics = list(pool)
    rows = []
    while len(rows) < target:
        topic = random.choice(topics)
        fn = random.choice(pool[topic])
        try:
            rows.append(fn())
        except Exception:
            continue
    return rows


def extract_book_notes(pdf_paths: list[Path]):
    notes=[]
    keywords = re.compile(r'(Relations|Functions|Inverse|Matrices|Determinants|Integrals|Probability|Derivatives|Binomial|Vectors)', re.I)
    for path in pdf_paths:
        try:
            doc=fitz.open(path)
        except Exception:
            continue
        for i in range(min(doc.page_count, 140)):
            text=doc.load_page(i).get_text('text')
            if not text.strip():
                continue
            lines=[ln.strip() for ln in text.splitlines() if ln.strip()]
            hits=[ln for ln in lines if len(ln)<130 and keywords.search(ln)]
            if hits:
                notes.append({'source_file': path.name, 'page': i+1, 'headings': hits[:8], 'sample_text': ' '.join(lines[:14])[:1100]})
    return notes


def import_external_sources():
    sources=[]
    for name in ['internet_gsm8k_train.jsonl', 'internet_svamp_train.csv', 'internet_asdiv.xml']:
        path=DATA_DIR / name
        if not path.exists():
            continue
        if name.endswith('.jsonl'):
            count=sum(1 for _ in path.open('r',encoding='utf-8'))
        elif name.endswith('.csv'):
            count=max(0, sum(1 for _ in path.open('r',encoding='utf-8'))-1)
        else:
            count=len(ET.parse(path).getroot()) if path.exists() else 0
        sources.append({'file':name,'rows_detected':count})
    return sources


def build_all(school_target=250_000, intermediate_target=250_000):
    school = generate_rows(school_template_pool(), school_target)
    intermediate = generate_rows(intermediate_template_pool(), intermediate_target)
    write_jsonl(DATA_DIR / 'school_dataset.jsonl', school)
    write_jsonl(DATA_DIR / 'intermediate_dataset.jsonl', intermediate)
    (DATA_DIR / 'topic_catalog.json').write_text(json.dumps(TOPIC_CATALOG, indent=2), encoding='utf-8')
    notes = extract_book_notes([Path('/mnt/data/book1.pdf'), Path('/mnt/data/book2.pdf'), Path('/mnt/data/book3.pdf')])
    (DATA_DIR / 'book_intermediate_notes.json').write_text(json.dumps(notes, indent=2), encoding='utf-8')
    meta={
        'school_rows': len(school),
        'intermediate_rows': len(intermediate),
        'total_rows': len(school)+len(intermediate),
        'style': 'relatable textbook-style numericals + standard word problems + formula prompts',
        'external_sources': import_external_sources(),
        'book_note_records': len(notes)
    }
    (DATA_DIR / 'dataset_meta.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    print(json.dumps(meta, indent=2))


if __name__ == '__main__':
    build_all()

# Project explanation for examiner

## Is the model being trained?
Yes. This project performs **real supervised training** on a local curated dataset.

### Models trained in this project
- **Topic classifier**: predicts the math topic.
- **Difficulty classifier**: predicts basic / intermediate / advanced.
- **Question-type classifier**: predicts whether the question is numerical computation, equation solving, calculus, probability, conceptual, graph/data, proof/verification, or word-problem style.

All three models are trained locally using:
- **TF-IDF vectorization**
- **Linear Support Vector Machine (LinearSVC)**

## What ML concepts are used?
- supervised learning
- multi-class text classification
- TF-IDF feature engineering
- n-gram modeling
- class balancing
- train-test split for evaluation
- retrieval using sparse vector similarity
- classical document RAG

## How classical doc RAG is used
This is not only example retrieval. The system builds a proper document-retrieval layer:
1. It chunks local explanatory sources such as formula notes and textbook-note passages.
2. It indexes those chunks using TF-IDF.
3. For each incoming math question, it retrieves the most relevant chunks.
4. Those retrieved chunks are fed into the reasoning prompt.
5. The final step-by-step answer is therefore grounded on retrieved document evidence from the local knowledge base.

## How the system answers a question
1. User types or uploads a question.
2. OCR extracts text if needed.
3. The local ML models predict topic, difficulty, and question type.
4. The local retrieval layer finds:
   - relevant formulas
   - similar example questions
   - document chunks from the classical doc-RAG index
5. The custom local parser tries to solve the question directly where possible.
6. Mistral receives the question plus the retrieved evidence and parser output.
7. The app returns a structured step-by-step explanation.

## What happens for questions outside the training dataset?
The trained classifiers may be less confident, but the system still works because:
- the retrieval layer can still find nearby formulas and note chunks
- the parser may still solve standard forms
- Mistral can solve unseen problems using the retrieved grounding context

So the system degrades gracefully rather than failing completely.


## Added AIML positioning

The user interface now includes a dedicated **AI/ML Design** section that explains the project as a final-year AIML system with:
- trained topic, difficulty, and question-type classifiers
- curated school and engineering math datasets
- supervised, sequence-style, and augmentation-based training
- preprocessing, OCR, validation, and feedback loops
- unchanged Mistral API integration in the solving path

## Listening videos are read-only for users

The Listening section is now student-facing only. Lesson videos are intended to be uploaded by the programmer into the project `videos/` folder.

# MathGenius Integrated Project

This package is the **fully integrated version of your current Math Solver project**, upgraded toward the specification you pasted into the conversation. It keeps your existing project structure and UI style, while integrating the major backend ML, retrieval, OTP, feedback, and history features into one runnable app.

## What is integrated

- OTP registration flow with demo OTP return
- Login with JWT access and refresh tokens
- Topic classifier, difficulty classifier, and question-type classifier
- Classical document RAG using TF-IDF retrieval over note chunks and formulas
- Similar-example retrieval from the training dataset
- Semi-supervised pseudo-label collection when confidence is high
- Reinforcement-style feedback loop with epsilon-greedy prompt-style policy
- OCR image solve route
- History persistence with ratings and solved-by tracking
- Weak-topic detection using KMeans over user topic history
- Formula browsing, practice, calculator, listening, profile, and history UI sections
- Double-click Windows runner

## Important honesty note

This integrated build is based on your existing project and **does not replace the frontend with a full multi-file React 18 application**. Instead, it keeps the project’s existing single-page frontend and integrates the requested features into that codebase. The backend remains FastAPI-based because that is the base project you asked to integrate into.

## Run

1. Copy `.env.example` to `.env`
2. Add `MISTRAL_API_KEY`
3. Double-click `run_app.bat`

## Default behavior

- If Mistral is available, the system uses the enriched ML + RAG prompt path.
- If Mistral is unavailable, the local custom engine is used where possible.
- Feedback updates the prompt strategy table.
- High-confidence unseen examples are stored in `artifacts/pseudo_labels.json`.

## Main endpoints

- `GET /api/health`
- `POST /api/auth/send-otp`
- `POST /api/auth/verify-otp`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/refresh`
- `GET /api/auth/me`
- `POST /api/solve`
- `POST /api/solve-image`
- `GET /api/topics`
- `GET /api/formulas`
- `GET /api/formulas/{topic}`
- `POST /api/classify`
- `GET /api/history`
- `GET /api/history/{id}`
- `POST /api/feedback`
- `GET /api/stats`
- `GET /api/admin/model-stats`

## ML architecture

### Supervised learning
- Topic classifier: TF-IDF + LinearSVC
- Difficulty classifier: TF-IDF + LinearSVC
- Question-type classifier: TF-IDF + LinearSVC

### Unsupervised learning
- Similar-example retrieval via TF-IDF vector similarity
- Classical doc RAG retrieval over note chunks
- KMeans weak-topic detection on solve history

### Semi-supervised learning
- Confident new examples are stored as pseudo labels

### Reinforcement-style learning
- Reward from thumbs up / thumbs down feedback updates prompt strategy
- Epsilon-greedy selection chooses detailed / concise / visual styles

## Training

Training is implemented in `train_models.py` and `backend/ml_training.py`.
Saved artifacts live under `artifacts/`.



Patched features:
- OCR preprocessing + confidence + confirm-before-solve flow
- Validation layers (pre and post) with consistency check against local engine
- Practice mode and analytics view in frontend
- Streaming solve now exposes validation stages in the UI


Config order: root .env -> root secrets.json -> backend/.env -> backend/secrets.json.
Auth flow: Login and Register are separate pages. Register requires Send OTP -> Verify OTP -> Create Account.


## AIML project framing

This project is presented as an ML-first mathematical reasoning system. It keeps the existing Mistral API integration unchanged, while also highlighting trained ML classifiers, dataset curation, OCR preprocessing, step-by-step reasoning flow, validation, and future retraining support.

## Listening videos

Students cannot upload videos from the UI. The programmer should place lesson files inside the `videos/` folder and register them in the backend or database. Bundled lesson videos in this package include Addition, Subtraction, Multiplication, Algebra, and Percentage.
